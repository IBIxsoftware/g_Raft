/*
 *
 *      Parser for Graft input
 *
 */

#include <stdio.h>
#include <stdlib.h>

#include <stddef.h>
#include <ctype.h>
#include <string.h>

#include "parser.h"
#include "readinp.h"

#define arr_size 80 
#define MAXLIP 10 
#define CHAINATS 40
// MAXLIP= Maximum number of lipids
FILE* debug;

// SPACE ALLOCATION
int *initvecint(int n)
{
	int i;
	int *v;
	v = calloc(n,sizeof(int));
}

char *initvecchar(int n)
{
        int i;
        char *v;
        v = calloc(n,sizeof(char));
}

int **mat_space_int(int m, int n)
{
	int i;
	int **a;

	a=calloc(m, sizeof(int *));
	for (i=0; i< m; ++i){
	    a[i]= calloc(n, sizeof(int));
	}
	return a;
}

real **mat_space_real(int m, int n)
{
        int i;
        real **a;

        a=calloc(m, sizeof(real *));
        for (i=0; i< m; ++i){
            a[i]= calloc(n, sizeof(real));
        }
        return a;
}

char **mat_space_char(int m, int n)
{
        int i;
        char **a;

        a=calloc(m, sizeof(char *));
        for (i=0; i< m; ++i){
            a[i]= calloc(n, sizeof(char));
        }
        return a;
}

char mat_free_char(char **a, int m)
{
        int i;
	
	for (i=0; i<m; ++i)
		free(++a[i]);
	free(++a);
}
////////////////////////////////

static int search_einp(int ninp, const t_inpfile *inp, const char *name)
{
  int i;

  if (inp==NULL)
    return -1;
  for(i=0; i<ninp; i++)
    if (gmx_strcasecmp_min(name,inp[i].name) == 0)
      return i;
  return -1;
}

static int get_einp(int *ninp,t_inpfile **inp,const char *name)
{
  int    i;
  int    notfound=FALSE;
  char   warn_buf[STRLEN];

/*  if (inp==NULL)
 *      return -1;
 *        for(i=0; (i<(*ninp)); i++)
 *            if (gmx_strcasecmp_min(name,(*inp)[i].name) == 0)
 *                  break;
 *                    if (i == (*ninp)) {*/
  i=search_einp(*ninp, *inp, name);
  if (i == -1)
  {
    notfound=TRUE;
    i=(*ninp)++;
    srenew(*inp,(*ninp));
    (*inp)[i].name=strdup(name);
    (*inp)[i].bSet=TRUE;
  }
  (*inp)[i].count = (*inp)[0].inp_count++;
  (*inp)[i].bSet  = TRUE;
  if (debug)
    fprintf(debug,"Inp %d = %s\n",(*inp)[i].count,(*inp)[i].name);

  /*if (i == (*ninp)-1)*/
  if (notfound)
    return -1;
  else
    return i;
}

int get_eint(int *ninp,t_inpfile **inp,const char *name,int def,
             warninp_t wi)
{
  char buf[32],*ptr,warn_buf[STRLEN];
  int  ii;
  int  ret;

  ii=get_einp(ninp,inp,name);

  if (ii == -1) {
    sprintf(buf,"%d",def);
    (*inp)[(*ninp)-1].value=strdup(buf);

    return def;
  }
  else {
    ret = strtol((*inp)[ii].value,&ptr,10);
    if (ptr == (*inp)[ii].value) {
      sprintf(warn_buf,"Right hand side '%s' for parameter '%s' in parameter file is not an integer value\n",(*inp)[ii].value,(*inp)[ii].name);
      warning_error(wi,warn_buf);
    }

    return ret;
  }
}

// This function parses a line for commands
void get_command(char *linein,char *lineout)
{
fputs ( linein, stdout ); /* write the line */
strcpy(lineout,linein);
printf("Size of line: %i\n", sizeof(linein));
printf("All %s\n",linein);
fputs ( lineout, stdout ); /* write the line */

}

size_t getlin(char **lineptr, size_t *n, FILE *stream) {
    char *bufptr = NULL;
    char *p = bufptr;
    size_t size;
    int c;

    if (lineptr == NULL) {
    	return -1;
    }
    if (stream == NULL) {
    	return -1;
    }
    if (n == NULL) {
    	return -1;
    }
    bufptr = *lineptr;
    size = *n;

    c = fgetc(stream);
    if (c == EOF) {
    	return -1;
    }
    if (bufptr == NULL) {
    	bufptr = malloc(128);
    	if (bufptr == NULL) {
    		return -1;
    	};
    	size = 128;
    }
    p = bufptr;
    while(c != EOF) {
    	if ((p - bufptr) > (size - 1)) {
    		size = size + 128;
    		bufptr = realloc(bufptr, size);
    		if (bufptr == NULL) {
    			return -1;
    		}
    	}
    	*p++ = c;
    	if (c == '\n') {
    		break;
    	}
    	c = fgetc(stream);
    }

    *p++ = '\0';
    *lineptr = bufptr;
    *n = size;

    return p - bufptr - 1;
}

void replaceChar(char *str, char garbage){
      int count;
//     for (count = 0; count < sizeof(str); count++)
      for (count = 0; count < strlen(str); count++)
	{
	  if (str[count] == garbage)
	{
	  str[count] = ' ';
	  break;
	}
	}
}

// Function gets rid of comments after ;
void delintrash(char *str){
	int count;
	int comment;
	comment=strlen(str)+1;
	// printf("\n Adentro papi %i \n",strlen(str));
	// printf("%s\n",str);
	for (count = strlen(str); count > 0 ; count--)
        {
             if (str[count] == ';'){
		// printf("symbol ; at pos=%i \n",count);
		comment=count;
	     }
        }
	// Spit all minus comments
	for (count = comment; count < strlen(str); count++){
	     str[count]=' '; 
	}
}

// Scan a line from text
int scantext(char *line,char *keyword, char *words[])
{
//char *line;
char *p;
int j;
char currentword= '\0';
int test;
int jline;
int nwords=0;
int scanval;
// Replace equals for spaces

// printf("Processing New Line\n");

//    p=line;
    replaceChar(line,'=');
//	printf("IN->\n %s\n",line);
    delintrash(line);
//	printf("OUT->\n %s\n",line);
    p=line;

    test=0; scanval=-1;
    while(test==0)
    {
	if(test==0){
           while(isspace(*p)) p++;
	
           if(*p == '\0') test=1;
	}
	if(test==0){
           words[nwords++] = p;
	
           while(!isspace(*p) && *p != '\0') p++;
	
           if(*p == '\0') test=1;
	}
	if(test==0){
           *p++ = '\0';
           //if(nwords >= maxwords) test=1;
	}
    }
    //  The value of the function is 0 by default
        scanval=-1;
//	printf("words[0]=%s, keyword=%s",words[0],keyword);
	if(strcmp(words[0],keyword)==0){
	   // If success, nwords is size of the words vector
	    scanval=nwords;
	}

     return scanval; // positive return with No of words if found keyword
}

//	###################################################################
//
//			    M A I N    F U N C T I O N
//
//	###################################################################
void get_inputs(const char *mdparin, const char *mdparout, t_gopts *gopts, t_ldat **ldat, t_pdat **pdat)
{
	int j, k, mu, nu, maxi;
	int ch, number_of_lines = 0;
//	int *vecint;
//	real *vecreal;
	char gname[80]="";
	char tmp10b[80];
	int nelem;
	int getval;
	char *keyword;
	int nwant, nhave;

	// Toy variables
	//size_t arr_size = 128;
	char *p=NULL;
	// 
	char linein[ arr_size ];

	FILE *datain = fopen ( mdparin, "r" );
	FILE *dataout = fopen ( mdparout, "w" );

        char *words[40];

	// Input variables
	int tesse;
	int syste;
	int proce;
	int clust;

	// Curvature
	int curv;
	int geom;
	int filty;
	real fild;
	int filn;
	int filto;

	// Lipids
	int nlgrps;
	int nlips;
	char lnames[MAXLIP*3][6];
	char *lnums;
//	int **lmat;
//	real **cmat;
	int *nltails;
	int sumlips;
	int sumchains;
	int kk=0;	
	int lip;
	int lg;

	// Chain Variables
	// space for MAXLIP*3 chains, 40 variables, size 5 each
	int nats;
	char cnames[MAXLIP*2][40][5];
	char anames[CHAINATS][6];
	char vnames[CHAINATS][6];
	int sumats;
	int sumvs;
	int sumtr;
	int lt; // lipid tail	
	int nexcl; 

	// Protein
	int pgrps;

	// Count number of lines
	do {
		ch=fgetc(datain);
		if(ch == '\n') number_of_lines++;
	} while (ch != EOF);
	
        // ==========================================================
	// ==========================================================

	gopts->tes=0;	// Tesselation
	gopts->sys=0;	// System
	gopts->pro=0;	// Procedure
	gopts->clu=0;	// Pz, m6, Pz&m6

	gopts->cur=0;	// Curvature
	gopts->geo=0;	// geo;         // 1=Planar, 2=polar, 3=spherical
	gopts->fty=0;      // 1=Binomial (default), 2=MEX wavelet
	gopts->fde=0.0;    // Grid spacing
	gopts->fbn=0;      // number of bins
	gopts->fop=0;	// Optional flag

// ##################################################################
//
//  	S Y S T E M	 F L A G S
//
// ##################################################################
	// ==========================================================
	//
	fprintf(dataout,"; SYSTEM FLAGS \n");
	fprintf(dataout,"; ========================================== \n");
        // ==========================================================
        rewind(datain);
        keyword="tesselation";
	fprintf(dataout,"%s = ",keyword);
        while ( (fgets ( linein, sizeof linein, datain ) != NULL) | nelem>-1)
        {
           if( strlen(linein)>3){
                nelem=scantext(linein,keyword,words);
                if(nelem>0 & strcmp(keyword,words[0])==0){
                    if(strcmp(words[1],"yes")==0 | strcmp(words[1],"no")==0 ){
                        tesse=atoi(words[1]);
                        fprintf(dataout,"%s ", words[1]);
                    } else {
                        tesse=1;
                        printf("tesselation option set to default value yes \n");
                        fprintf(dataout,"yes ");
                    };
                };
            };
        };
        fprintf(dataout,"       ; yes(default)/no       \n");
	gopts->tes=tesse;

	// ==========================================================
        rewind(datain);
        keyword="system";
	syste=0;
	fprintf(dataout,"%s = ",keyword);
        while ( (fgets ( linein, sizeof linein, datain ) != NULL) | nelem>-1)
        {
           if( strlen(linein)>3){
                nelem=scantext(linein,keyword,words);
                if(nelem>0 & strcmp(keyword,words[0])==0){
                    fprintf(dataout,"%s = ",words[0]);
                    if(strcmp(words[1],"monolayer")==0){
			syste=1; //atoi(words[1]);
			fprintf(dataout,"monolayer "); }
		    else {
			fprintf(dataout,"bilayer ");
		    }
                };
            };
        };
	fprintf(dataout,"        ; monolayer(default)/bilayer \n");
	gopts->sys=syste;

        // ==========================================================
        rewind(datain);
        keyword="procedure";
	proce=2;
	fprintf(dataout,"%s = ",keyword);
        while ( (fgets ( linein, sizeof linein, datain ) != NULL) | nelem>-1)
        {
           if( strlen(linein)>3){
                nelem=scantext(linein,keyword,words);
                if(nelem>0 & strcmp(keyword,words[0])==0){
                    if(strcmp(words[1],"1")==0 | strcmp(words[1],"2") | strcmp(words[1],"3")==0 ){
                        proce=atoi(words[1]);
                    } else {
                        printf("system option set to default value monolayer \n");
                    };
                };
            };
        };
        fprintf(dataout,"%i ", proce);
        fprintf(dataout,"           ; 1=testing,  2=stats (default), 3=line-tension. \n");
	gopts->pro=proce;
	printf("INSIDE gopts->pro = %i \n",gopts->pro);
        // ==========================================================
        rewind(datain);
        keyword="clustering";
	clust=1;
	fprintf(dataout,"%s = ",keyword);
        while ( (fgets ( linein, sizeof linein, datain ) != NULL) | nelem>-1)
        {
           if( strlen(linein)>3){
                nelem=scantext(linein,keyword,words);
                if(nelem>0 & strcmp(keyword,words[0])==0){
                    if(strcmp(words[1],"1")==0 | strcmp(words[1],"2") | strcmp(words[1],"3")==0 ){
                        clust=atoi(words[1]);
                    } else {
                        printf("clustering option set to default value Pz \n");
                    };
                };
            };
        };
        fprintf(dataout,"%i ", clust);
        fprintf(dataout,"          ; 1=Pz (Default),  2=m6,  3=Pz & m6 \n");
	gopts->clu=clust;

// ##################################################################
// 
// 	C U R V A T U R E      F L A G S 
//
// ##################################################################
        // ==========================================================
        // ==========================================================
        fprintf(dataout,"\n; CURVATURE FLAGS \n");
        fprintf(dataout,"; ========================================== \n");
	
        rewind(datain);
        keyword="curvature";
	curv=2;
	fprintf(dataout,"%s = ",keyword);
        while ( (fgets ( linein, sizeof linein, datain ) != NULL) | nelem>-1)
        {
           if( strlen(linein)>3){
                nelem=scantext(linein,keyword,words);
                if(nelem>0 & strcmp(keyword,words[0])==0){
                    if(strcmp(words[1],"yes")==0 | strcmp(words[1],"no")==0 ){
                        curv=atoi(words[1]);
                    } else {
                        printf("curvature option set to default value no \n");
                    };
                };
            };
        };
        fprintf(dataout,"%i ", curv);
        fprintf(dataout,"          ; 1=yes/ 0=no(default)\n");
	gopts->cur=curv;
	// ---------------------------------------------------------
        rewind(datain);
        keyword="geometry";
	geom=1;
	fprintf(dataout,"%s = ",keyword);
        while ( (fgets ( linein, sizeof linein, datain ) != NULL) | nelem>-1)
        {
           if( strlen(linein)>3){
                nelem=scantext(linein,keyword,words);
                if(nelem>0 & strcmp(keyword,words[0])==0){
                    if(strcmp(words[1],"1")==0 | strcmp(words[1],"2") | strcmp(words[1],"3")==0 ){
                        geom=atoi(words[1]);
                    } else {
                        printf("clustering option set to default value Pz \n");
                    };
                };
            };
        };
        fprintf(dataout,"%i ", geom);
        fprintf(dataout,"             ; 1=Planar, 2=Polar, 3=spherical\n");
	gopts->geo=geom;
	// ---------------------------------------------------------
        rewind(datain);
        keyword="filter-type";
	filty=1;
	fprintf(dataout,"%s = ",keyword);
        while ( (fgets ( linein, sizeof linein, datain ) != NULL) | nelem>-1)
        {
           if( strlen(linein)>3){
                nelem=scantext(linein,keyword,words);
                if(nelem>0 & strcmp(keyword,words[0])==0){
                    if(strcmp(words[1],"1")==0 | strcmp(words[1],"2")){
                        filty=atoi(words[1]);
                    } else {
                        printf("filter-type option set to default Binomial \n");
                    };
                };
            };
        };
	fprintf(dataout,"%i ", filty);
        fprintf(dataout,"          ; 1=Binomial filter (default), 2=MEX wavelet\n");
	gopts->fty=filty;
	// ---------------------------------------------------------
        rewind(datain);
        keyword="filter-delta";
	fild=0.6;
	fprintf(dataout,"%s = ",keyword);
        while ( (fgets ( linein, sizeof linein, datain ) != NULL) | nelem>-1)
        {
           if( strlen(linein)>3){
                nelem=scantext(linein,keyword,words);
                if(nelem>0 & strcmp(keyword,words[0])==0){
                    if(atoi(words[1])>0){
                        fild=atof(words[1]);
                    } else {
                        printf("filter-delta option set to default 30 \n");
                    };
                };
            };
        };
	fprintf(dataout,"%2.2f ", fild);
        fprintf(dataout,"        ; grid spacing for binomial filter, typically 0.6 \n");
	gopts->fde=fild;
	// ---------------------------------------------------------
        rewind(datain);
        keyword="filter-nbin";
	filty=30;
	fprintf(dataout,"%s = ",keyword);
        while ( (fgets ( linein, sizeof linein, datain ) != NULL) | nelem>-1)
        {
           if( strlen(linein)>3){
                nelem=scantext(linein,keyword,words);
                if(nelem>0 & strcmp(keyword,words[0])==0){
                    if(atoi(words[1])>0){
                        filty=atoi(words[1]);
                    } else {
                        printf("filter-nbin option set to default 30 \n");
                    };
		    
                };
            };
        };
	fprintf(dataout,"%i ", filty);
        fprintf(dataout,"        ; Number of bins for filttering\n");
	gopts->fbn=filty;
	// ---------------------------------------------------------
        rewind(datain);
        keyword="filter-opt";
	fprintf(dataout,"%s = ",keyword);
        filto=0;
        while ( (fgets ( linein, sizeof linein, datain ) != NULL) | nelem>-1)
        {
           if( strlen(linein)>3){
                nelem=scantext(linein,keyword,words);
                if(nelem>0 & strcmp(keyword,words[0])==0){
                    if(atoi(words[1])>0){
                        filto=atoi(words[1]);
                    } else {
                        printf("filter option set to default 0 \n");
                    };

                };
            };
        };
        fprintf(dataout,"%i ", filto);
        fprintf(dataout,"        ; Extra optional flag\n");
	gopts->fop=filto;
	//printf(" gopts->fop= %i \n",gopts->fop);
	// ---------------------------------------------------------
// ##################################################################
//
//   	L I P I D S
// 
// ##################################################################

        fprintf(dataout,"\n; LIPID GROUPS INFORMATION  \n");
        fprintf(dataout,"; ========================================== \n");
// Number of groups
        rewind(datain);
        keyword="l-ngrps";
	fprintf(dataout,"%s = ",keyword);
	nlgrps=2; // Default
        while ( (fgets ( linein, sizeof linein, datain ) != NULL) | nelem>-1)
        {
           if( strlen(linein)>3){
                nelem=scantext(linein,keyword,words);
                if(nelem>0 & strcmp(keyword,words[0])==0){
                    if(atoi(words[1])>0){
                        nlgrps=atoi(words[1]);
                    } else {
                        nlgrps=2;
                        printf(" number of lipid groups set to default 2 \n");
                    };
                };
            };
        };
	gopts->nlgp = nlgrps;
	fprintf(dataout,"%i ", nlgrps);
        fprintf(dataout,"    	; number of lipid groups, Default=2 \n");

	// Loop to scan all lipid groups
	sumlips=0; // Sum all lipids
	kk=0;	   // Counter for 
	for (lg=1;lg<=nlgrps;lg++){
		maxi=-2;
		rewind(datain);
		strcpy(gname,"l-grp"); sprintf(tmp10b, "%d", lg); strcat(gname,tmp10b); // Group name
		printf("\nParsing lipid group: %s \n", gname);
	  	fprintf(dataout,"%s = ",gname);
		nlips=1; // Default
		while ( (fgets ( linein, sizeof linein, datain ) != NULL) | nelem>-1)
        	{
        	   if( strlen(linein)>3){
        	        nelem=scantext(linein,gname,words);
        	        if(nelem>0 & strcmp(gname,words[0])==0){
			    // printf("The following elements are defined for variable %s :\n", gname);
			    	for(j=1;j<nelem;j++){
        	                	//sumlips = sumlips + nelem;
				        printf("%s ", words[j]);
					fprintf(dataout,"%s ", words[j]);
					// Lipid labels
					strcpy(lnames[kk],words[j]);
					//printf("\nLip.Num=%i, group=%i\n", kk+1, lg);
					gid[kk]=lg;
					kk++;
				};
			};
			maxi=max(maxi,nelem);
			
        	    };
        	};
		if (maxi-1<=0 ){ // maxi-1 is the number of lipids per group
			printf("!!No lipids specified, variable %s needs to be set on file %s \n", gname, mdparin);
			exit(3);
		};
		fprintf(dataout,"\n");
		printf(",%i lipids\n", maxi-1);
		sumlips = sumlips + (maxi-1);
	};
	printf("\n%i lipids defined \n",sumlips);	
	printf("=========== \n");
	//fprintf(dataout,"\n");

//	check, print lipid names
	//printf("Lipids\n");
//	for (lip=0;lip<sumlips;lip++){
	//    printf("%s ",lnames[lip]);
//	}; printf("\n");

	printf("XXXXXXXXXXXX %i %i ", sizeof(char), sizeof(char *));

	gopts->nlip=sumlips;
	ldat = malloc((1+sumlips)*sizeof(t_ldat));
        for(j=0;j<sumlips;j++){

		ldat[j]->lname=malloc(6*sizeof(char *));
		strcpy(ldat[j]->lname,lnames[j]);
		// INITIALIZE
		printf("sumlips = %d ",sumlips);
	//	printf("Eucalyptys %s \n", ldat[j].lname);
		//ldat[j]->gid=gid[j];
        }

	printf("=========== \n");

//	Parse chains per lipid
	nelem=4;
        maxi=-2;
	kk=0;
	sumchains=0;
        rewind(datain);
        keyword="l-ntails";
        printf("\nParsing variable %s defining alkane chains per lipid \n", keyword);
        fprintf(dataout,"%s = ",keyword);
        nlips=1; // Default
        // simple counter
        while ( (fgets ( linein, sizeof linein, datain ) != NULL) | nelem>-1)
        {
		//printf("HOLLA %s",linein);
              if( strlen(linein)>3){
              	    nelem=scantext(linein,keyword,words);
                    if(nelem==sumlips+1 & strcmp(keyword,words[0])==0){
			 printf("%s vector defined:\n", linein);
                         for(j=1;j<nelem;j++){
				 ldat[j-1]->nt=atoi(words[j]);
				 kk++;
                                 fprintf(dataout,"%s ", words[j]);
                                 // sumchains
                                 //printf("copacabana=%s\n",words[j]);
				 sumchains=sumchains+atoi(words[j]);
                          };
                          maxi=max(maxi,nelem);
		    };
              };
        };

	// Evaluate
	if(maxi-1==sumlips){
		// Right number of variables
		// printf("maxi is %i \n", maxi);
	} else {
		printf("\nWrong number of elements for variable %s\n", keyword);
		printf("you need one integer per lipid, with format:\n");
		printf("%s = 2 2 1 ... n \n", keyword);
		exit(3);
	};
	printf("you have %i chains \n",sumchains);

//  INDIVIDUAL LIPID INFORMATION
        printf("\n\n");
	printf("; Individual Lipid Information\n");
	//printf("; chain format \n");
	fprintf(dataout,"\n");
	for (lip=0;lip<sumlips;lip++){
	             printf("\n; Lipid %i (%s) \n", lip+1, lnames[lip]);
	             printf("; ------------------------------------------:) \n");
	             fprintf(dataout,"\n; Lipid %i (%s) \n", lip+1, lnames[lip]);
	             fprintf(dataout,"; ------------------------------------------ \n");

	             // ========================================
	             // VERTEX-ATOM NUMBERS (FOR CURVATURE CALCS)
	                // lip+1 index for lipid number
	                printf("; Processing Lipid %i \n", lip+1);
	        	// Loop to scan all lipid groups
	        	sumvs=0; 
	        	kk=0;      
	        	nelem=3;
	                maxi=-2;
	                rewind(datain);
			
	                strcpy(gname,"l"); sprintf(tmp10b, "%d", lip+1); strcat(gname,tmp10b); 
			strcpy(tmp10b,"_Vatnum"); strcat(gname,tmp10b);
                	printf("\nParsing: %s, ", gname);
                	fprintf(dataout,"%s = ",gname);
		
                	nats=1; 
                	while ( (fgets ( linein, sizeof linein, datain ) != NULL) | nelem>-1)
                	{
                   		if( strlen(linein)>3){
                        		nelem=scantext(linein,gname,words);
                        		if(nelem>0 & strcmp(gname,words[0])==0){
                                		for(j=1;j<nelem;j++){
                                		        strcpy(vnames[kk],words[j]);
                                		        kk++;
                                		};
                        		};
                        		maxi=max(maxi,nelem);

                    		};
                	};
                	if (maxi-1<=0 ){ 
                	        printf("No lipids specified, variable %s needs to be set on file %s \n", gname, mdparin);
                	        exit(3);
                	};
                	sumvs = sumvs + (maxi-1);

			ldat[lip]->nv=sumvs;
			ldat[lip]->val=calloc(sumvs,sizeof(int));
        		printf("vertice particle(s) {");
        		for (k=0;k<sumvs;k++){
			   printf(" %s ", vnames[k]);
			   fprintf(dataout," %s ",vnames[k]);
			   ldat[lip]->val[k]=atoi(vnames[k]);
        		}; 
			printf("}, \n");
			fprintf(dataout,"\n");		       

	   // ================================================= //
	   // ================================================= //
	   //							//
	   // 		READING TAIL INPUT VARIABLES		//
	   //							//
	   // ================================================= //
	   // ================================================= //
			// Allocate space for tal (Tail Atom list)
			ldat[lip]->tal=calloc(1+ldat[lip]->nt, sizeof(int ));
			// Allocate space for PZcut
			ldat[lip]->PZcut=calloc(1+ldat[lip]->nt, sizeof(float ));
			// Allocate space for exclusion
			ldat[lip]->PZexcl=calloc(1+ldat[lip]->nt, sizeof(int ));

			for(lt=0;lt<(ldat[lip]->nt);lt++){

			printf("; lipid %i chain %i \n", lip+1, lt+1);

                     // READING TAIL-PARTICLE NUMBERS  
		     // ====================================================================	
                        nexcl=0;
                        kk=0;
                        nelem=3;
                        maxi=-2;
                        rewind(datain);

                        strcpy(gname,"l"); sprintf(tmp10b, "%d", lip+1); strcat(gname,tmp10b);
                        strcat(gname,"-t"); sprintf(tmp10b, "%d", lt+1); strcat(gname,tmp10b);
                        strcpy(tmp10b,"_num"); strcat(gname,tmp10b);

			nats=1;
                        while ( (fgets ( linein, sizeof linein, datain ) != NULL) | nelem>-1)
			{
                                if( strlen(linein)>3){
                                        nelem=scantext(linein,gname,words);
                                        if(nelem>0 & strcmp(gname,words[0])==0){
                                                for(j=1;j<nelem;j++){
                                                        strcpy(anames[kk],words[j]);
                                                        kk++;
						};
					};
					maxi=max(maxi,nelem);
				};
			};
                        if (maxi-1<=0 ){
                                printf("Variable %s needs to be set on file %s \n", gname, mdparin);
                                exit(3);
                        };
                        nexcl = nexcl + (maxi-1);

                        printf("Parsing: %s,", gname);
                        printf(" %i elements {", nexcl);
                        fprintf(dataout,"%s = ",gname);
                        for (k=0;k<nexcl;k++){
                            printf(" %s ",anames[k]);
                            fprintf(dataout,"%s ",anames[k]);
                        };
			printf("} ");
                        fprintf(dataout,"\n");

			// Allocate space for global variable
			ldat[lip]->naxt=(int *)calloc(ldat[lip]->nt,sizeof(int));

			ldat[lip]->naxt[lt]=nexcl;

			ldat[lip]->tal[lt]=(int *)calloc(nexcl,sizeof(int));

			ldat[lip]->PZcut[lt]=(float *)calloc(nexcl-2,sizeof(float));

			ldat[lip]->PZexcl[lt]=(int *)calloc(nexcl-2,sizeof(int));

			for (nu=0;nu<nexcl;nu++){
			    ldat[lip]->tal[lt][nu]=atoi(anames[nu]);
			    //printf("%i GADelements %i \n",  nexcl, ldat[lip].tal[lt][nu]);
			};

                     // READING GLOBAL PZcut TRESHOLD
		     // ====================================================================	
		
                        sumtr=0;
                        kk=0;
                        nelem=3;
                        maxi=-2;
                        rewind(datain);

                        strcpy(gname,"l"); sprintf(tmp10b, "%d", lip+1); strcat(gname,tmp10b);
                        strcat(gname,"-t"); sprintf(tmp10b, "%d", lt+1); strcat(gname,tmp10b);
                        strcpy(tmp10b,"_PZcut"); strcat(gname,tmp10b);

                        nats=1;
                        while ( (fgets ( linein, sizeof linein, datain ) != NULL) | nelem>-1)
                        {
                                if( strlen(linein)>3){
                                        nelem=scantext(linein,gname,words);
                                        if(nelem>0 & strcmp(gname,words[0])==0){
                                                for(j=1;j<nelem;j++){
                                                        strcpy(anames[kk],words[j]);
                                                        kk++;
                                                };
                                        };
                                        maxi=max(maxi,nelem);

                                };
                        };
                        if (maxi-1<=0 ){
                                printf("No treshold specified, variable %s needs to be set on file %s \n", gname, mdparin);
                                exit(3);
                        };
                        sumtr = sumtr + (maxi-1);
                        if (kk >= sumats-1 & sumats > 2){
                                printf("variable %s on input file  %s needs to define only %i variables \n", gname, mdparin, sumats-2);
                                exit(3);
                        };
			if(sumtr != ldat[lip]->naxt[lt]-2){
			        printf("\nvariable %s needs to include %i angles instead of %i, for %i particles \n", gname, ldat[lip]->naxt[lt]-2, sumtr,ldat[lip]->naxt[lt]);
			        exit(3);
		        };

                        printf("\nParsing: %s, ", gname);
                        printf(" %i elements {", sumtr);
                        fprintf(dataout,"%s = ",gname);

                        for (k=0;k<sumtr;k++){
			        printf("%s ",anames[k]);
                                fprintf(dataout,"%s ",anames[k]);
				ldat[lip]->PZcut[lt][k]=atof(anames[k]);
                        };
                        printf("}\n");
                        fprintf(dataout,"\n");
		
			// READING GLOBAL PZexcl TRESHOLD
			// ====================================================================	
		
                        sumtr=0;
                        kk=0;
                        nelem=3;
                        maxi=-2;
                        rewind(datain);

                        strcpy(gname,"l"); sprintf(tmp10b, "%d", lip+1); strcat(gname,tmp10b);
                        strcat(gname,"-t"); sprintf(tmp10b, "%d", lt+1); strcat(gname,tmp10b);
                        strcpy(tmp10b,"_PZexc"); strcat(gname,tmp10b);

                        nats=1;
                        while ( (fgets ( linein, sizeof linein, datain ) != NULL) | nelem>-1)
                        {
                                if( strlen(linein)>3){
                                        nelem=scantext(linein,gname,words);
                                        if(nelem>0 & strcmp(gname,words[0])==0){
                                                for(j=1;j<nelem;j++){
                                                        strcpy(anames[kk],words[j]);
                                                        kk++;
                                                };
                                        };
                                        maxi=max(maxi,nelem);

                                };
                        };
                        if (maxi-1<=0 ){
                                printf("No treshold specified, variable %s needs to be set on file %s \n", gname, mdparin);
                                exit(3);
                        };
                        sumtr = sumtr + (maxi-1);
                        if (kk >= sumats-1 & sumats > 2){
                                printf("variable %s on input file  %s needs to define only %i variables \n", gname, mdparin, sumats-2);
                                exit(3);
                        };
			if(sumtr != ldat[lip]->naxt[lt]-2){
			        printf("\nvariable %s needs to include %i elements instead of %i, for %i particles \n", gname, ldat[lip]->naxt[lt]-2, sumtr,ldat[lip]->naxt[lt]);
			        exit(3);
		        };

                        printf("Parsing: %s, ", gname);
                        printf(" %i elements { ", sumtr);
                        fprintf(dataout,"%s = ",gname);

                        for (k=0;k<sumtr;k++){
			        printf("%s ",anames[k]);
                                fprintf(dataout,"%s ",anames[k]);
				ldat[lip]->PZexcl[lt][k]=atoi(anames[k]);
                        };
                        printf("}\n");
                        fprintf(dataout,"\n\n");

			// ========================================================================
			//printf("l%i-t%i_PZtresh = \n",lip+1,lt+1);

			//fprintf(dataout,"l%i-t%i_PZtresh = \n",lip+1,lt+1);
			//fprintf(dataout,"l%i-t%i_PZ0 = \n\n",lip+1,lt+1);
	    	};
		rewind(datain);

        }; printf("\n");

//        fprintf(dataout,"%i ", nlgrps);
//        fprintf(dataout,"       ; number of lipid groups, Default=2 \n");


// ################################################################################################
//
// 		 P  R  O  T  E  I  N 
// 
// ################################################################################################

	
	fprintf(dataout,"\n; PROTEINS  \n");
        fprintf(dataout,"; ========================================== \n");
	rewind(datain);
	keyword="p-grps";
	//fprintf(dataout,"%s = ",keyword);
	pgrps=0;
        while ( (fgets ( linein, sizeof linein, datain ) != NULL) | nelem>-1)
        {
           if( strlen(linein)>3){
                nelem=scantext(linein,keyword,words);
                if(nelem>0 & strcmp(keyword,words[0])==0){
		  //fprintf(dataout,"%s = ",words[0]);
                    if(atoi(words[1])>0){
                        pgrps=atoi(words[1]);
			printf("%i groups requested\n", pgrps);
			printf("Remember. Stats are calculated respect to groups, not individual proteins");
                    } else {
                        pgrps=0;
                        printf("p-group default set to 0\n");
			printf("If you want to include protein groups on your analysis, please include\n");
			printf("the p-groups = (number) statement, complete additional options as requested\n\n");
                    };
                };
            };  
        };
	gopts->npgp = pgrps;

        fprintf(dataout,"; Number of protein groups, Default=0  \n");
	fprintf(dataout,"p-grps = %i \n", pgrps);
	// Parse PROTEINS 
	// ==========================================================
	int sumprot;
	int pg, nprots;
	int prot;
	// Loop to scan all protein groups
	sumprot=0; // Sum all lipids
	kk=0;	   // Counter for 
	for (pg=1;pg<=pgrps;pg++){
		maxi=-2;
		rewind(datain);
		strcpy(gname,"p-grp"); sprintf(tmp10b, "%d", pg); strcat(gname,tmp10b); // Group name
		printf("\nParsing: %s,{ ", gname);
	  	fprintf(dataout,"%s = ",gname);
		nprots=1; // Default

		while ( (fgets ( linein, sizeof linein, datain ) != NULL) | nelem>-1)
        	{
        	   if( strlen(linein)>3){
        	        nelem=scantext(linein,gname,words);
        	        if(nelem>0 & strcmp(gname,words[0])==0){
			    // printf("The following elements are defined for variable %s :\n", gname);
			    	for(j=1;j<nelem;j++){
        	                	//sumprots = sumprots + nelem;
				        printf("%s ", words[j]);
					fprintf(dataout,"%s ", words[j]);
					// Lipid labels
					strcpy(lnames[kk],words[j]);
					//printf("Prot.Num=%i, group=%i\n", kk+1, pg);
					gid[kk]=pg;
					kk++;
				};
				//printf("NAMA");
			};
			maxi=max(maxi,nelem);
			
        	    };
        	};

		
		if (maxi-1<=0){
			printf("!!variable %s needs to be properly set on file %s \n", gname, mdparin);
			exit(3);
		};
		
		fprintf(dataout,"\n");
		printf("} ,%i proteins", maxi-1);
		sumprot = sumprot + (maxi-1);
	};
	printf("\n%i proteins required \n",sumprot);	
	fprintf(dataout,"\n");

//	check, print lipid names
	gopts->npro=sumprot;
	//t_pdat *pdat;
	pdat = malloc(sumprot*sizeof(t_pdat));
        for(j=0;j<sumprot;j++){
	        strcpy(pdat[j]->pname,lnames[j]);
		pdat[j]->gid=gid[j];
	        //printf("NAMES SHOULD LOOK FINE %s ",lnames[j]);
        }

	// ==========================================================
	fprintf(dataout,"; Protein definition \n");
	fprintf(dataout,"; ------------------------------------------ \n");
        for (prot=0;prot<sumprot;prot++){ 
	  // nexcl=0;
                kk=0;
                nelem=3;
                maxi=-2;
                rewind(datain);

		strcpy(gname,"p"); sprintf(tmp10b, "%d", prot+1); strcat(tmp10b,"-Calpha"); strcat(gname,tmp10b);
		nats=1;


                while ( (fgets ( linein, sizeof linein, datain ) != NULL) | nelem>-1)
		{
                                if( strlen(linein)>3){
                                        nelem=scantext(linein,gname,words);
					
                                        if(nelem>0 & strcmp(gname,words[0])==0){
                                                for(j=1;j<nelem;j++){
                                                        strcpy(anames[kk],words[j]);
                                                        kk++;
						};
					
					};
					maxi=max(maxi,nelem);
				};
		};
		nelem=maxi-1;
                if (nelem!=3 ){
                                printf("Variable %s needs to be properly set on file %s. \n", gname, mdparin);
				printf("Need to specify alpha-particle name, first, last particle in interval\n");
                                exit(3);
                };
                        //nexcl = nexcl + (maxi-1);
			
                printf("\nParsing %s; %s", gname, pdat[prot]->pname);
                //printf(" %i elements {", nelem);
		printf(" defined for %s on [", anames[0]);
                fprintf(dataout,"%s = ",gname);
		fprintf(dataout,"%s ",anames[0]);
		strcpy(pdat[prot]->bn,anames[0]);
		pdat[prot]->fa=atoi(anames[1]);
		pdat[prot]->la=atoi(anames[2]);
                for (k=1;k<nelem;k++){
                     printf(" %s ",anames[k]);
                     fprintf(dataout,"%s ",anames[k]);
                };
		printf("] interval");
                fprintf(dataout,"\n");
                 
       
        }
	printf("\n");
	;rewind;

// ############### 

	// ==========================================================
	printf("End of parsing \n ");
	// close files
	fclose(dataout);
	fclose(datain);
};

