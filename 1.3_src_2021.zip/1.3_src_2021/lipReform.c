
/*
 *
 * 	This file includes get_cordprot,   get_cordvor and get_cordsurf
 *
 */


#include <stdio.h>
#include <stdlib.h>

#include <stddef.h>
#include <ctype.h>
#include <string.h>
#include "math.h"

#include "parser.h"
#include "readinp.h"


lipReform(int j, int k, int natxl, rvec ***x, matrix box)
{
        rvec vref;
        rvec vtry;
 	int r, mua;

	printf("Hello Kitteh %d %d \n", k, natxl); 

	for (mua=0;mua<3;mua++) vref[mua]=(**x)[j][mua];
	
	printf(" S  %f %f %f \n\n", vref[0], vref[1], vref[2]);

	//for (r=0;r<natxl;r++) printf(" %d %f %f %f \n", k+r, (**x)[k+r][0], (**x)[k+r][1], (**x)[k+r][2]);

	for (r=0;r<natxl;r++){
	    for (mua=0;mua<3;mua++){
	         vtry[mua]=(**x)[k+r][mua];
                 if(vtry[mua] > vref[mua]){
                        while(vtry[mua]-vref[mua]> box[mua][mua]) vtry[mua]=vtry[mua] - box[mua][mua];
                        if(vtry[mua]-vref[mua]> box[mua][mua]/2.0) vtry[mua]=vtry[mua] - box[mua][mua];
                 } else {
                   	while(vref[mua]-vtry[mua]> box[mua][mua]) vtry[mua]=vtry[mua]+box[mua][mua];
                   	if(vref[mua]-vtry[mua]> box[mua][mua]/2.0) vtry[mua]=vtry[mua]+box[mua][mua];
                 }

	//	  printf(" %f %f \n", vtry[mua], vref[mua]);
		 (**x)[k+r][mua]=vtry[mua];
            }
	  //  printf(" %d %f %f %f \n", k+r, (**x)[k+r][0], (**x)[k+r][1], (**x)[k+r][2]);
	}

}

