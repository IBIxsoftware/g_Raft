/*
 *
 *	WRITING STUFF 
 *
 */

#include <stdio.h>
#include <stdlib.h>

#include <stddef.h>
#include <ctype.h>
#include <string.h>
#include <math.h>
#include "parser.h"
#include "readinp.h"

#define arr_size 80 
#define MAXLIP 10 
#define CHAINATS 40



////////////////////////////////////////////////////////////////////////////
//void writedens(char *dataout, t_2Dgrid *memGD, t_gopts *opts, t_ldat **ldat, t_pdat **pdat, t_memb *memb, rvec**x, matrix box)
void writedens(char *dataout, t_3Dstats *stats3DGD, t_pdat **pdat, rvec**x, matrix box){

        int i, j, k;
	int counter;
	int dimX0, dimY0, dimZ0; 
	double delta;
	double value;
	double valueS;

	char filename[20]="";

	// AVERAGES FOR EVERYTHING
	// ==============================================================
	printf("Results for everything:  \n");	
	printf("Average Density for all lipids <dens>=%f \n",stats3DGD->rhoALL_ave);
	printf("STD for all lipids Sigma= %f \n", stats3DGD->rhoALL_sigma);
	printf("SEM for all lipids SEM= %f \n\n", stats3DGD->rhoALL_sem);

        printf("Average Density for lipids group 1:  <dens>_A=%f \n",stats3DGD->rhoALL_Aave);
        printf("STD for lipids group 1, Sigma_A= %f \n", stats3DGD->rhoALL_Asigma);
        printf("SEM for lipids group 1, SEM_A= %f \n\n", stats3DGD->rhoALL_Asem);

        printf("Average Density for protein_Beads <dens>_p=%f \n",stats3DGD->rhoALL_Pave);
        printf("STD for selected protein beads  Sigma= %f \n", stats3DGD->rhoALL_Psigma);
        printf("SEM for selected protein beads SEM= %f \n\n", stats3DGD->rhoALL_Psem);

	// dx FILES FOR 
	// ==============================================================
	strcpy(filename,dataout); strcat(filename,"AB_ave.dx");
	printf("FILENAME=%s\n", filename);

	FILE *out = fopen (filename, "w" );
	counter=0;
	dimX0=stats3DGD->dimX0;
	dimY0=stats3DGD->dimY0;
	dimZ0=stats3DGD->dimZ0;	
	delta=stats3DGD->delta;
	printf("All density files with dimmension: \n");
	printf("=> dimX0=%i dimY0=%i dimz0=%i\n", dimX0, dimY0, dimZ0);
        printf("Writing Average Density for all lipids, file: %s\n", filename);

	fprintf(out,"object 1 class gridpositions counts %i %i %i\n", dimX0, dimY0, dimZ0);
	fprintf(out,"origin 0.0 0.0 0.0\n");
	fprintf(out,"delta %f 0 0\n", delta*10.0);
	fprintf(out,"delta 0 %f 0\n", delta*10.0);
	fprintf(out,"delta 0 0 %f\n", delta*10.0);
	fprintf(out,"object 2 class gridconnections counts %i %i %i\n", dimX0, dimY0, dimZ0);
	fprintf(out,"object 3 class array type double rank 0 items  %d data follows \n",dimX0*dimY0*dimZ0); 
	
        for(i=0; i<dimX0; i++){
        for(j=0; j<dimY0; j++){
        for(k=0; k<dimZ0; k++){
	   	counter++;
		value=stats3DGD->gpt[i][j][k].rhoAVE;
		if(value<0.001){
		  fprintf(out,"0 ");
		} else{
		  fprintf(out,"%f ", value);
		}
	   	if(counter>2){ counter=0; fprintf(out,"\n");}

        }
        }
        }
	fprintf(out,"\nattribute \"dep\" string \"positions\" \n");
	fprintf(out,"object \"regular positions regular connections\" class field \n");
	fprintf(out,"component \"positions\" value 1 \n");
	fprintf(out,"component \"connections\" value 2 \n");
	fprintf(out,"component \"data\" value 3 \n");

	fclose(out);
	// ==============================================================
	strcpy(filename,dataout); strcat(filename,"AB_var.dx");
	printf("Writing Variance Density for all lipids, file: %s\n", filename);
	out = fopen (filename, "w" );
	counter=0;
	dimX0=stats3DGD->dimX0;
	dimY0=stats3DGD->dimY0;
	dimZ0=stats3DGD->dimZ0;	
	delta=stats3DGD->delta;

	fprintf(out,"object 1 class gridpositions counts %i %i %i\n", dimX0, dimY0, dimZ0);
	fprintf(out,"origin 0.0 0.0 0.0\n");
	fprintf(out,"delta %f 0 0\n", delta*10.0);
	fprintf(out,"delta 0 %f 0\n", delta*10.0);
	fprintf(out,"delta 0 0 %f\n", delta*10.0);
	fprintf(out,"object 2 class gridconnections counts %i %i %i\n", dimX0, dimY0, dimZ0);
	fprintf(out,"object 3 class array type double rank 0 items  %d follows \n",dimX0*dimY0*dimZ0); 
	
        for(i=0; i<dimX0; i++){
        for(j=0; j<dimY0; j++){
        for(k=0; k<dimZ0; k++){
	   	counter++;
		value=stats3DGD->gpt[i][j][k].rhoVAR;
		if(value<0.001){
		  fprintf(out,"0 ");
		} else{
		  fprintf(out,"%f ", value);
		}
	   	if(counter>2){ counter=0; fprintf(out,"\n");}

        }
        }
        }
	fprintf(out,"\nattribute \"dep\" string \"positions\" \n");
	fprintf(out,"object \"regular positions regular connections\" class field \n");
	fprintf(out,"component \"positions\" value 1 \n");
	fprintf(out,"component \"connections\" value 2 \n");
	fprintf(out,"component \"data\" value 3 \n");

	fclose(out);

        // ==============================================================
        strcpy(filename,dataout); strcat(filename,"AB_aveplusSig.dx");
        printf("Writing vals > Ave+Variance Density for all lipids, file: %s\n", filename);
        out = fopen (filename, "w" );
        counter=0;
        dimX0=stats3DGD->dimX0;
        dimY0=stats3DGD->dimY0;
        dimZ0=stats3DGD->dimZ0;
        delta=stats3DGD->delta;

        fprintf(out,"object 1 class gridpositions counts %i %i %i\n", dimX0, dimY0, dimZ0);
        fprintf(out,"origin 0.0 0.0 0.0\n");
        fprintf(out,"delta %f 0 0\n", delta*10.0);
        fprintf(out,"delta 0 %f 0\n", delta*10.0);
        fprintf(out,"delta 0 0 %f\n", delta*10.0);
        fprintf(out,"object 2 class gridconnections counts %i %i %i\n", dimX0, dimY0, dimZ0);
        fprintf(out,"object 3 class array type double rank 0 items  %d follows \n",dimX0*dimY0*dimZ0);

        for(i=0; i<dimX0; i++){
        for(j=0; j<dimY0; j++){
        for(k=0; k<dimZ0; k++){
                counter++;
                value=stats3DGD->gpt[i][j][k].rhoAVE;
                if(value < stats3DGD->rhoALL_ave + stats3DGD->rhoALL_sigma ){
                  fprintf(out,"0 ");
                } else{
                  fprintf(out,"%f ", value);
                }
                if(counter>2){ counter=0; fprintf(out,"\n");}

        }
        }
        }
        fprintf(out,"\nattribute \"dep\" string \"positions\" \n");
        fprintf(out,"object \"regular positions regular connections\" class field \n");
        fprintf(out,"component \"positions\" value 1 \n");
        fprintf(out,"component \"connections\" value 2 \n");
        fprintf(out,"component \"data\" value 3 \n");

        fclose(out);

	// ==============================================================
	// Stats for A-Group Only	
	// ==============================================================
	strcpy(filename,dataout); strcat(filename,"A_ave.dx");
	printf("Write density file for lipid species A %s\n", filename);

	FILE *outA = fopen (filename, "w" );
	counter=0;
	dimX0=stats3DGD->dimX0;
	dimY0=stats3DGD->dimY0;
	dimZ0=stats3DGD->dimZ0;	
	delta=stats3DGD->delta;

	fprintf(outA,"object 1 class gridpositions counts %i %i %i\n", dimX0, dimY0, dimZ0);
	fprintf(outA,"origin 0.0 0.0 0.0\n");
	fprintf(outA,"delta %f 0 0\n", delta*10.0);
	fprintf(outA,"delta 0 %f 0\n", delta*10.0);
	fprintf(outA,"delta 0 0 %f\n", delta*10.0);
	fprintf(outA,"object 2 class gridconnections counts %i %i %i\n", dimX0, dimY0, dimZ0);
	fprintf(outA,"object 3 class array type double rank 0 items  %d follows \n",dimX0*dimY0*dimZ0); 
	
        for(i=0; i<dimX0; i++){
        for(j=0; j<dimY0; j++){
        for(k=0; k<dimZ0; k++){
	   	counter++;
		value=stats3DGD->gpt[i][j][k].rhoAAVE;
		if(value<0.001){
		  fprintf(outA,"0 ");
		} else{
		  fprintf(outA,"%f ", value);
		}
	   	if(counter>2){ counter=0; fprintf(outA,"\n");}

        }
        }
        }
	fprintf(outA,"\nattribute \"dep\" string \"positions\" \n");
	fprintf(outA,"object \"regular positions regular connections\" class field \n");
	fprintf(outA,"component \"positions\" value 1 \n");
	fprintf(outA,"component \"connections\" value 2 \n");
	fprintf(outA,"component \"data\" value 3 \n");

	fclose(outA);
	// ==============================================================
	strcpy(filename,dataout); strcat(filename,"A_var.dx");
	printf("Write density file for lipid species A %s\n", filename);

	outA = fopen (filename, "w" );
	counter=0;
	dimX0=stats3DGD->dimX0;
	dimY0=stats3DGD->dimY0;
	dimZ0=stats3DGD->dimZ0;	
	delta=stats3DGD->delta;

	fprintf(outA,"object 1 class gridpositions counts %i %i %i\n", dimX0, dimY0, dimZ0);
	fprintf(outA,"origin 0.0 0.0 0.0\n");
	fprintf(outA,"delta %f 0 0\n", delta*10.0);
	fprintf(outA,"delta 0 %f 0\n", delta*10.0);
	fprintf(outA,"delta 0 0 %f\n", delta*10.0);
	fprintf(outA,"object 2 class gridconnections counts %i %i %i\n", dimX0, dimY0, dimZ0);
	fprintf(outA,"object 3 class array type double rank 0 items  %d follows \n",dimX0*dimY0*dimZ0); 
	
        for(i=0; i<dimX0; i++){
        for(j=0; j<dimY0; j++){
        for(k=0; k<dimZ0; k++){
	   	counter++;
		value=stats3DGD->gpt[i][j][k].rhoAVAR;
		if(value<0.001){
		  fprintf(outA,"0 ");
		} else{
		  fprintf(outA,"%f ", value);
		}
	   	if(counter>2){ counter=0; fprintf(outA,"\n");}

        }
        }
        }
	fprintf(outA,"\nattribute \"dep\" string \"positions\" \n");
	fprintf(outA,"object \"regular positions regular connections\" class field \n");
	fprintf(outA,"component \"positions\" value 1 \n");
	fprintf(outA,"component \"connections\" value 2 \n");
	fprintf(outA,"component \"data\" value 3 \n");

	fclose(outA);
	// ==============================================================
	strcpy(filename,dataout); strcat(filename,"A_varplusSigma.dx");
	printf("Write density file for lipid species A %s\n", filename);

	outA = fopen (filename, "w" );
	counter=0;
	dimX0=stats3DGD->dimX0;
	dimY0=stats3DGD->dimY0;
	dimZ0=stats3DGD->dimZ0;	
	delta=stats3DGD->delta;

	fprintf(outA,"object 1 class gridpositions counts %i %i %i\n", dimX0, dimY0, dimZ0);
	fprintf(outA,"origin 0.0 0.0 0.0\n");
	fprintf(outA,"delta %f 0 0\n", delta*10.0);
	fprintf(outA,"delta 0 %f 0\n", delta*10.0);
	fprintf(outA,"delta 0 0 %f\n", delta*10.0);
	fprintf(outA,"object 2 class gridconnections counts %i %i %i\n", dimX0, dimY0, dimZ0);
	fprintf(outA,"object 3 class array type double rank 0 items  %d follows \n",dimX0*dimY0*dimZ0); 
	
        for(i=0; i<dimX0; i++){
        for(j=0; j<dimY0; j++){
        for(k=0; k<dimZ0; k++){
	   	counter++;
		value=stats3DGD->gpt[i][j][k].rhoAVAR;
		if(value < stats3DGD->rhoALL_Aave + stats3DGD->rhoALL_Asigma ){
		  fprintf(outA,"0 ");
		} else{
		  fprintf(outA,"%f ", value);
		}
	   	if(counter>2){ counter=0; fprintf(outA,"\n");}

        }
        }
        }
	fprintf(outA,"\nattribute \"dep\" string \"positions\" \n");
	fprintf(outA,"object \"regular positions regular connections\" class field \n");
	fprintf(outA,"component \"positions\" value 1 \n");
	fprintf(outA,"component \"connections\" value 2 \n");
	fprintf(outA,"component \"data\" value 3 \n");

	fclose(outA);
	// ==============================================================
	// Stats for Proteins Only	
	// ==============================================================
	strcpy(filename,dataout); strcat(filename,"Prot_ave.dx");
	printf("Write density file for lipid species A %s\n", filename);

	outA = fopen (filename, "w" );
	counter=0;
 

	fprintf(outA,"object 1 class gridpositions counts %i %i %i\n", dimX0, dimY0, dimZ0);
	fprintf(outA,"origin 0.0 0.0 0.0\n");
	fprintf(outA,"delta %f 0 0\n", delta*10.0);
	fprintf(outA,"delta 0 %f 0\n", delta*10.0);
	fprintf(outA,"delta 0 0 %f\n", delta*10.0);
	fprintf(outA,"object 2 class gridconnections counts %i %i %i\n", dimX0, dimY0, dimZ0);
	fprintf(outA,"object 3 class array type double rank 0 items  %d follows \n",dimX0*dimY0*dimZ0); 
	
        for(i=0; i<dimX0; i++){
        for(j=0; j<dimY0; j++){
        for(k=0; k<dimZ0; k++){
	   	counter++;
		value=stats3DGD->gpt[i][j][k].rhoPave;
		if(value<0.001){
		  fprintf(outA,"0 ");
		} else{
		  fprintf(outA,"%f ", value);
		}
	   	if(counter>2){ counter=0; fprintf(outA,"\n");}

        }
        }
        }
	fprintf(outA,"\nattribute \"dep\" string \"positions\" \n");
	fprintf(outA,"object \"regular positions regular connections\" class field \n");
	fprintf(outA,"component \"positions\" value 1 \n");
	fprintf(outA,"component \"connections\" value 2 \n");
	fprintf(outA,"component \"data\" value 3 \n");

	fclose(outA);
	// ==============================================================
	strcpy(filename,dataout); strcat(filename,"Prot_var.dx");
	printf("Write density file for lipid species A %s\n", filename);

	outA = fopen (filename, "w" );
	counter=0;
  
	fprintf(outA,"object 1 class gridpositions counts %i %i %i\n", dimX0, dimY0, dimZ0);
	fprintf(outA,"origin 0.0 0.0 0.0\n");
	fprintf(outA,"delta %f 0 0\n", delta*10.0);
	fprintf(outA,"delta 0 %f 0\n", delta*10.0);
	fprintf(outA,"delta 0 0 %f\n", delta*10.0);
	fprintf(outA,"object 2 class gridconnections counts %i %i %i\n", dimX0, dimY0, dimZ0);
	fprintf(outA,"object 3 class array type double rank 0 items  %d follows \n",dimX0*dimY0*dimZ0); 
	
        for(i=0; i<dimX0; i++){
        for(j=0; j<dimY0; j++){
        for(k=0; k<dimZ0; k++){
	   	counter++;
		value=stats3DGD->gpt[i][j][k].rhoPvar;
		if(value<0.001){
		  fprintf(outA,"0 ");
		} else{
		  fprintf(outA,"%f ", value);
		}
	   	if(counter>2){ counter=0; fprintf(outA,"\n");}

        }
        }
        }
	fprintf(outA,"\nattribute \"dep\" string \"positions\" \n");
	fprintf(outA,"object \"regular positions regular connections\" class field \n");
	fprintf(outA,"component \"positions\" value 1 \n");
	fprintf(outA,"component \"connections\" value 2 \n");
	fprintf(outA,"component \"data\" value 3 \n");

	fclose(outA);
	// ==============================================================
	strcpy(filename,dataout); strcat(filename,"Prot_varplusSig.dx");
	printf("Write density file for lipid species A %s\n", filename);

	outA = fopen (filename, "w" );
	counter=0;
  
	fprintf(outA,"object 1 class gridpositions counts %i %i %i\n", dimX0, dimY0, dimZ0);
	fprintf(outA,"origin 0.0 0.0 0.0\n");
	fprintf(outA,"delta %f 0 0\n", delta*10.0);
	fprintf(outA,"delta 0 %f 0\n", delta*10.0);
	fprintf(outA,"delta 0 0 %f\n", delta*10.0);
	fprintf(outA,"object 2 class gridconnections counts %i %i %i\n", dimX0, dimY0, dimZ0);
	fprintf(outA,"object 3 class array type double rank 0 items  %d follows \n",dimX0*dimY0*dimZ0); 
	
        for(i=0; i<dimX0; i++){
        for(j=0; j<dimY0; j++){
        for(k=0; k<dimZ0; k++){
	   	counter++;
		value=stats3DGD->gpt[i][j][k].rhoPvar;
		if(value < stats3DGD->rhoALL_Pave +  stats3DGD->rhoALL_Psigma){
		  fprintf(outA,"0 ");
		} else{
		  fprintf(outA,"%f ", value);
		}
	   	if(counter>2){ counter=0; fprintf(outA,"\n");}

        }
        }
        }
	fprintf(outA,"\nattribute \"dep\" string \"positions\" \n");
	fprintf(outA,"object \"regular positions regular connections\" class field \n");
	fprintf(outA,"component \"positions\" value 1 \n");
	fprintf(outA,"component \"connections\" value 2 \n");
	fprintf(outA,"component \"data\" value 3 \n");

	fclose(outA);
	// ==============================================================
	// ==============================================================
}

