
//      ###################################################################
//
//                          M A I N    F U N C T I O N
//
//      ###################################################################
#include <stdio.h>
#include <stdlib.h>

#include <stddef.h>
#include <ctype.h>
#include <string.h>
#include <math.h>

#include "parser.h"
#include "readinp.h"

#include "parser.h"

double costeta(rvec *v1, rvec *v2);
void calc_P2(t_gopts *opts, t_ldat **ldat, t_memb *memb, t_atoms *atoms, rvec **x, matrix box)
{
	int natoms;
	int j, jl, jt, k, mu, nu , lt;
	int bd1, bd2, bd3;
	int jp, slips;
	int ltype;
	int nt, naxt;
	rvec rA, rB;
	char *jlname, *atnam;
	double P2;
	double countP2;

	slips = memb->slips;

 	for(jl=0; jl<slips; jl++){
                j=(*memb).lidx[jl]; 
		ltype=(*memb).ltype[jl];
		jlname=(*ldat)[ltype].lname;
		atnam = *(atoms->atomname[j]);
		nt=(*ldat)[ltype].nt;
		// printf("lname=%s, %d%s :\n", jlname, j,*(atoms->atomname[j]));
		for(jt=0;jt<nt;jt++){
			P2=0.0;
			countP2=0.0; 	
			naxt=(*ldat)[ltype].naxt[jt];
			for(mu=0;mu<naxt-2;mu++){	// naxt-2 because we define angles

				bd1=(*ldat)[ltype].tal[jt][mu]  + j-1;  // bead 1
				bd2=(*ldat)[ltype].tal[jt][mu+1] + j-1; // bead 2
				bd3=(*ldat)[ltype].tal[jt][mu+2] + j-1; // bead 3
					
				atnam = *(atoms->atomname[nu]);
				//printf("ang=%d, %d%s %d%s %d%s \n", mu, bd1, *(atoms->atomname[bd1]), bd2, *(atoms->atomname[bd2]), bd3, *(atoms->atomname[bd3]));

				rA[0]=(*x)[bd1][0]-(*x)[bd2][0]; 
				rA[1]=(*x)[bd1][1]-(*x)[bd2][1]; 
				rA[2]=(*x)[bd1][2]-(*x)[bd2][2];
 				rB[0]=(*x)[bd3][0]-(*x)[bd2][0]; 
				rB[1]=(*x)[bd3][1]-(*x)[bd2][1]; 
				rB[2]=(*x)[bd3][2]-(*x)[bd2][2];
 				// printf("rA=[%f %f %f]\n",rA[0],rA[1],rA[2]);
 				// printf("rB=[%f %f %f]\n",rB[0],rB[1],rB[2]);

				//printf("PZexcl=%d \n",(*ldat)[ltype].PZexcl[jt][mu]==1);
				if((*ldat)[ltype].PZexcl[jt][nu]==1){ // Only valid for 2-chain lipids

				   P2 = P2 + (1.0/2.0)*(3.0*costeta(&rA,&rB)*costeta(&rA,&rB)-1);
				   countP2=countP2+1.0;
	//			   printf("     costeta=%f, P2=%f \n",costeta(&rA,&rB), P2);
				}

			}
			if (countP2>0.0) (*ldat)[ltype].Pztail[jt]=P2/countP2;

		};
		
		
	};


}


