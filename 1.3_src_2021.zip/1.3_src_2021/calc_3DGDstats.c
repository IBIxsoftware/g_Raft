/*
 *
 *      Parser for Graft input
 *
 */

#include <stdio.h>
#include <stdlib.h>

#include <stddef.h>
#include <ctype.h>
#include <string.h>
#include <math.h>

#include "parser.h"

//double costeta(rvec *v1, rvec *v2);
//double filter(int type, int w, int mu, double shift);


void calc_3DGDstats(t_3Dstats *stats3DGD,t_3Dsums *sums3DGD,t_memb *memb,t_ldat **ldat,t_pdat **pdat,t_atoms *atoms,rvec **x,t_gopts *opts, matrix box)
{
	int i, j, k, jp;	
	int slips;
	int Nlip;
//	char *jlname, *atnam;

	//int natxl;
        //int jresindx;
        //char *jresnam, *janame;
	//char *jresnamn;
	//rvec x_j; 
	//rvec vecB;
	rvec vecZ;
	double ctheta;

	double boxX, boxY, boxZ;
	int dimX0, dimY0, dimZ0;
	double delta;
	double ave, var, sem;

	printf("Density Statistics.  \n");
	// ##############################################################
	//
	//	TEMPORARY GRID	
	//	This grid contains raw data prior to averaging
	// ##############################################################
	dimX0=sums3DGD->dimX0;
	dimY0=sums3DGD->dimY0;
	dimZ0=sums3DGD->dimZ0;	

	printf("=> dimX0=%d dimY0=%d dimz0=%d\n", dimX0, dimY0, dimZ0);

	// ##############################################################
	//
	//	
	//
	// ##############################################################

	slips = memb->slips;
	Nlip = opts->nltypes; // Number of types
	delta = opts->delta;
	vecZ[0]=0.0; 	vecZ[1]=0.0;	vecZ[2]=1.0;
	boxX=box[0][0];	boxY=box[1][1]; boxZ=box[2][2];
	
  	// ##############################################################
	//
	// 	GET SURFACE FRAME
	//
	// ##############################################################

	int w;		// width of filter
	//int mu, nu, ou; 	// Variables for filter function
	//int iref, jref, kref; // Reference indices that match filter to tmpGD
	//int dimXmax, dimYmax, dimZmax;	

	double dave, dvar, dsem;
	double dsum, dsum2, Nd;
	int nframes;

	//dimXmax=dimX0-1;  dimYmax=dimY0-1; dimZmax=dimZ0-1;	

	nframes=sums3DGD->nframes; 	// Number of frames
	stats3DGD->nframes = nframes;
	Nd= (double) nframes;
	printf("Number of frames stated %i \n", nframes);
	printf("Nd=%f\n", Nd);

	printf("%i %i %i \n", dimX0, dimY0, dimZ0);


        stats3DGD->rhoALL_ave=0.0;
        stats3DGD->rhoALL_Aave=0.0;
        stats3DGD->rhoALL_Pave=0.0;
        stats3DGD->rhoALL_sigma=0.0;
        stats3DGD->rhoALL_Asigma=0.0;
        stats3DGD->rhoALL_Psigma=0.0;
        stats3DGD->rhoALL_sem=0.0;
        stats3DGD->rhoALL_Asem=0.0;
        stats3DGD->rhoALL_Psem=0.0;
	
	double ALL_sum, ALL_sum2;
	double ALL_sumA, ALL_sumA2;
	double ALL_sumP, ALL_sumP2;
	double ALLl, ALLa, ALLp;

	ALLl=0.0; ALLa=0.0; ALLp=0.0;
	ALL_sum=0.0;  ALL_sum2=0.0;
	ALL_sumA=0.0; ALL_sumA2=0.0;
	ALL_sumP=0.0; ALL_sumP2=0.0;

	for(i=0; i<dimX0; i++){
	for(j=0; j<dimY0; j++){
	for(k=0; k<dimZ0; k++){
		// ALL LIPID GROUPS
		// ======================================================= 
		if( sums3DGD->gpt[i][j][k].N > 0){

			dsum = sums3DGD->gpt[i][j][k].sumRho;
			dsum2 = sums3DGD->gpt[i][j][k].sumRho2;

			// Notice I divide by Nd the number of frames
			// and not N, the number of times particles were in
	                dave=dsum/Nd;
                        dvar=(1/Nd)*(dsum2-pow(dsum,2)/Nd);
                        dsem=sqrtf(dvar/Nd);
		//	printf("Hello i,j,k=%i %i %i ; dave=%f, dvar=%f, dsem=%f Nd=%f, N=%d\n", i, j, k, dave, dvar, dsem, Nd,sums3DGD->gpt[i][j][k].N);
			stats3DGD->gpt[i][j][k].rhoAVE = dave;
			stats3DGD->gpt[i][j][k].rhoVAR = dvar;
			stats3DGD->gpt[i][j][k].rhoSEM = dsem;

			ALLl=ALLl+1.0;
			ALL_sum  = ALL_sum + dave;
			ALL_sum2 = ALL_sum2 + dave*dave;
		}

		// LIPID GROUP A
		// =======================================================
		// Print the value of each sum
		// printf("ftype=%d, sumFt=%f sumFm=%f sumFd=%f \n", ftype, sumFt, sumFm, sumFd);
		if( sums3DGD->gpt[i][j][k].NA > 0){
			dsum = sums3DGD->gpt[i][j][k].sumRhoA;
                        dsum2 = sums3DGD->gpt[i][j][k].sumRhoA2;

			dave=dsum/Nd;
                        dvar=(1/Nd)*(dsum2-pow(dsum,2)/Nd);
                        dsem=sqrtf(dvar/Nd);

			stats3DGD->gpt[i][j][k].rhoAAVE = dave;
                        stats3DGD->gpt[i][j][k].rhoAVAR = dvar;
                        stats3DGD->gpt[i][j][k].rhoASEM = dsem;
	
			ALLa=ALLa+1.0;
			ALL_sumA = ALL_sumA + dave;
			ALL_sumA2 = ALL_sumA2 + dave;
			
		}
		// PROTEIN
		// =======================================================
		if( sums3DGD->gpt[i][j][k].NP > 0){
			dsum = sums3DGD->gpt[i][j][k].sumRhoP;
                        dsum2 = sums3DGD->gpt[i][j][k].sumRhoP2;

			dave=dsum/Nd;
                        dvar=(1/Nd)*(dsum2-pow(dsum,2)/Nd);
                        dsem=sqrtf(dvar/Nd);

			stats3DGD->gpt[i][j][k].rhoPave = dave;
                        stats3DGD->gpt[i][j][k].rhoPvar = dvar;
                        //stats3DGD->gpt[i][j][k].rhoPsem = dsem;

			ALLp=ALLp+1.0;
			ALL_sumP = ALL_sumP + dave;
			ALL_sumP2 = ALL_sumP2 + dave;
			printf("ALL_sumP = %f \n", ALL_sumP);
		}
		// =======================================================
	}
	}
	}
 


	// AVERAGE AND STD FOR EVERYTHING




	// AVERAGES FOR EVERYTHING
	// ==============================================================
	ave = ALL_sum/ALLl;
	var = fabs(ALL_sum2/ALLl - ave*ave);	
        stats3DGD->rhoALL_ave=ave;
        stats3DGD->rhoALL_sigma=sqrtf(var);
        stats3DGD->rhoALL_sem=sqrtf(var)/sqrtf(ALLl);

	printf("Results for everything:  \n");	
	printf("Number of data in sample %i\n", (int) ALLl);
	printf("Average Density for all lipids <dens>=%f \n",stats3DGD->rhoALL_ave);
	printf("STD for all lipids Sigma= %f \n", stats3DGD->rhoALL_sigma);
	printf("SEM for all lipids SEM= %f \n\n", stats3DGD->rhoALL_sem);

	ave = ALL_sumA/ALLa;
	var = fabs(ALL_sumA2/ALLa - ave*ave);	
        stats3DGD->rhoALL_Aave=ave;
        stats3DGD->rhoALL_Asigma=sqrtf(var);				 
        stats3DGD->rhoALL_Asem=sqrtf(var)/sqrt(ALLa);
	printf("Number of data in sample %i\n", (int) ALLa);
        printf("Average Density for lipids group 1:  <dens>_A=%f \n",stats3DGD->rhoALL_Aave);
        printf("VAR for lipids group 1  Var_A=%f \n",var);
        printf("STD for lipids group 1, Sigma_A= %f\n", sqrtf(var));
        printf("SEM for lipids group 1, SEM_A= %f \n\n", stats3DGD->rhoALL_Asem);

	ave = ALL_sumP/ALLp;
	var = fabs(ALL_sumP2/ALLp - ave*ave);
        stats3DGD->rhoALL_Pave=ave;
        stats3DGD->rhoALL_Psigma=sqrtf(var);
        stats3DGD->rhoALL_Psem=sqrt(var)/sqrtf(ALLa);
	printf("Number of data in sample %i\n", (int) ALLp);
        printf("Average Density for protein_Beads <dens>_p=%f \n",stats3DGD->rhoALL_Pave);
        printf("VAR for selected protein beads  VAR= %f \n", sqrt(var));
        printf("STD for selected protein beads  Sigma= %f \n", stats3DGD->rhoALL_Psigma);
        printf("SEM for selected protein beads SEM= %f \n\n", stats3DGD->rhoALL_Psem);


	// ##############################################################
	printf("\n");
}
