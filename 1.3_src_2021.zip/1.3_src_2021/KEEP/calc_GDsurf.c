/*
 *
 *      Parser for Graft input
 *
 */

#include <stdio.h>
#include <stdlib.h>

#include <stddef.h>
#include <ctype.h>
#include <string.h>
#include <math.h>

#include "parser.h"

double costeta(rvec *v1, rvec *v2);

void calc_GDsurf(t_2Dgrid *memGD, t_2Dsums *sumsGD,  t_memb *memb, t_ldat **ldat, t_pdat **pdat, t_atoms *atoms, rvec **x, t_gopts *opts, matrix box)
{
	int j, k, jp;	
	int jh, jt; // jhead, jtail counter	
	int slips;
	int Nlip;
	char *jlname, *atnam;
 	t_gsml **tmpGD;

        int jresindx;
        char *jresnam, *janame;
	char *jresnamn;
	rvec x_j; 
	rvec vecB;
	double ctheta;
	int jnhats, jntats;
	int valhead, valtail;
	int jlip;

	rvec try;
	double boxX, boxY;
	int dimX0, dimY0;
	int jtindx, jhindx;
	int gpx, gpy; double gpz;
	// ##############################################################
	//
	//	TEMPORARY GRID	
	//
	// ##############################################################
	dimX0=sumsGD->dimX0;
	dimY0=sumsGD->dimY0;

	slips = memb->slips;
	Nlip = opts->nltypes; // Number of types
	vecB[0]=0.0; 	vecB[1]=0.0;	vecB[2]=1.0;
	boxX=box[0][0];	boxY=box[1][1];


	// ##############################################################
	//
	// 	GET SURFACE FRAME
	//
	// ##############################################################

	int w;		// width of filter
	int mu, nu; 	// Variables for filter function
	int jref, kref; // Reference indices that match filter to tmpGD
	double sumfZval_m, sumf_m; // Midplane sums factor*Zval and sum of factors
	int Xmax, Ymax;	
	int px, py;

	int Nt;
	double tsum, tsum2;
	double tave, tvar, tsem;
	int Nm; 
	double msum, msum2;
	double mave, mvar, msem; 
	int Nd;
	double dsum, dsum2;
	double dave, dvar, dsem;	

	Xmax=dimX0-1;  Ymax=dimY0-1;

	for(j=0; j<=Xmax; j++){
	for(k=0; k<=Ymax; k++){
		// Nottice I do not initialize the variable, I simple add to it.
		// ===========================
		// TOP PLANE SUMS 
		// ===========================  
		Nt=sumsGD->gpt[j][k].Nt;
		if(Nt>0){
			tsum=sumsGD->gpt[j][k].ts;
			tsum2=sumsGD->gpt[j][k].ts2;

			tave=tsum/((double) Nt);		
			tvar=(1/Nt)*(tsum2 - pow(tsum,2)/Nt);
			tsem=sqrtf(tvar/Nt);
//			printf("tsum = %f\n", tsum);
		} else {
			tave=0.0;
			tvar=0.0;
			tsem=0.0;
		};

		//printf("TOP %i %i %f \n", j, k, tave);

		memGD->gpt[j][k].tAVE=tave;
		memGD->gpt[j][k].tVAR=tvar;
		memGD->gpt[j][k].tSEM=tsem;

		// MIDPLANE SUMS 
		// ===========================  
		Nm=sumsGD->gpt[j][k].Nm;
		if(Nm>0){
			msum=sumsGD->gpt[j][k].ms;
			msum2=sumsGD->gpt[j][k].ms2;

			mave=msum/Nm;
			mvar=(1/Nm)*(msum2-pow(msum,2)/Nm);
			msem=sqrtf(mvar/Nm);
		} else {
			mave=0.0;
			mvar=0.0;
			msem=0.0;
		};
		//printf("MIDPLANE %i %i %f \n", j, k, mave);
		memGD->gpt[j][k].mAVE=mave;
		memGD->gpt[j][k].mVAR=mvar;
		memGD->gpt[j][k].mSEM=msem;

		// DOWN PLANE SUMS 
		// ===========================  
		Nd=sumsGD->gpt[j][k].Nd;
		if(Nd>0){
			dsum=sumsGD->gpt[j][k].ds ;
			dsum2=sumsGD->gpt[j][k].ds2;
		
			dave=dsum/Nd;
			dvar=(1/Nd)*(dsum2-pow(dsum,2)/Nd);
			dsem=sqrtf(dvar/Nd);
		} else {
			dave=0.0;
			dvar=0.0;		
		};
		//printf("DOWNPLANE %i %i %f \n", j, k, dave);
		memGD->gpt[j][k].dAVE=dave;
		memGD->gpt[j][k].dVAR=dvar;
		memGD->gpt[j][k].dVAR=dsem;
		// ===========================  
	}
	}


	// ##############################################################
	//
	//	TICKNESS CALCULATIONS
	//
	// ##############################################################
	int tickmethod;
	tickmethod=0;
	if (tickmethod==0){

		for(j=0; j<=Xmax; j++){
		for(k=0; k<=Ymax; k++){
			// Monolayer 1
			memGD->gpt[j][k].m1tickAVE=fabs(memGD->gpt[j][k].tAVE - memGD->gpt[j][k].mAVE);
			//printf("memGD->gpt[j][k].m1tickAVE = %f\n",memGD->gpt[j][k].m1tickAVE);
	
			// Monolayer 2
			memGD->gpt[j][k].m2tickAVE=fabs(memGD->gpt[j][k].mAVE - memGD->gpt[j][k].dAVE);
			
		}
		}
			
		
	} else {
			
		
	}

        // ##############################################################
        //
        // AVERAGE LIPID TYPE-1 OCCUPANCY (Lipids per area)
        //
        // ##############################################################
        for(j=0; j<=Xmax; j++){
        for(k=0; k<=Ymax; k++){
                // ===========================
                // TOP PLANE SUMS 
                // ===========================  
                
                if(sumsGD->gpt[j][k].sNt_Alip >0){
                        tsum=sumsGD->gpt[j][k].st_Alip;
                        tsum2=sumsGD->gpt[j][k].st2_Alip;
			Nt=sumsGD->gpt[j][k].sNt_Alip;

                        tave=tsum/((double) Nt);
                        tvar=(1/Nt)*(tsum2 - pow(tsum,2)/Nt);
                        tsem=sqrtf(tvar/Nt);
                        printf("=============================>>>>>>> TOP tsum = %f\n", tsum);
			 
                } else {
                        tave=0.0;
                        tvar=0.0;
                        tsem=0.0;
                };
		//printf("TOP %i %i %f \n", j, k, tave);

		memGD->gpt[j][k].m1lA_AVE=tave;
		memGD->gpt[j][k].m1lA_VAR=tvar;
		memGD->gpt[j][k].m1lA_AVE=tsem;

		// DOWN PLANE SUMS 
		// ===========================  
                
                if(sumsGD->gpt[j][k].sNd_Alip>0){
                        tsum=sumsGD->gpt[j][k].sd_Alip;
                        tsum2=sumsGD->gpt[j][k].sd2_Alip;
			Nd=sumsGD->gpt[j][k].sNd_Alip;
                        tave=tsum/((double) Nd);
                        tvar=(1/Nd)*(tsum2 - pow(tsum,2)/Nd);
                        tsem=sqrtf(tvar/Nd);
                        printf("=============================>>>>>>> DOWN tsum = %f\n", tsum);
                } else {
                        tave=0.0;
                        tvar=0.0;
                        tsem=0.0;
                };
		//printf("TOP %i %i %f \n", j, k, tave);

		memGD->gpt[j][k].m2lA_AVE=tave;
		memGD->gpt[j][k].m2lA_VAR=tvar;
		memGD->gpt[j][k].m2lA_AVE=tsem;
		 
		if(tave > 0.0 ) printf("ALELUYA %f \n", &memGD->gpt[j][k].m2lA_AVE );

	}
	}
	 
	// ##############################################################
	printf("\n");
}
