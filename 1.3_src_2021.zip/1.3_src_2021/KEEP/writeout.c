/*
 *
 *	WRITING STUFF 
 *
 */

#include <stdio.h>
#include <stdlib.h>

#include <stddef.h>
#include <ctype.h>
#include <string.h>
#include <math.h>
#include "parser.h"
#include "readinp.h"

#define arr_size 80 
#define MAXLIP 10 
#define CHAINATS 40
////////////////////////////////////////////////////////////////////////////
void writejvx(t_2Dgrid *memGD, t_pdat **pdat, rvec**x, t_gopts *opts, matrix box)
{
	int i, j, jp, flag, k;
	int prot, sumprot;
	double xi, yi, zi;
	double dimX0, dimY0,delta;

	dimX0=memGD->dimX0;
	dimY0=memGD->dimY0;
	delta=opts->delta;


	////////////////////////////////////////////////////////////////////////////
	//	THICKNESS 
	////////////////////////////////////////////////////////////////////////////
	FILE *out_t21= fopen("thickness12.dat","w");
	fprintf(out_t21," 0.00");
	for (j=0;j<dimX0;j++){ xi=j*delta; fprintf(out_t21," %5.2f", xi); };
	fprintf(out_t21,"\n");
	 
	flag=0;
	for(k=0;k<dimY0;k++){
	 
           for (j=0;j<dimX0;j++){ 	

                xi = j*delta;
                yi = k*delta;
 
		zi = fabs(memGD->gpt[j][k].tAVE) - fabs(memGD->gpt[j][k].dAVE);
		if(flag==0) { fprintf(out_t21,"%5.2f ", yi); flag=1;}; // Only print Y value at beginning of row
		fprintf(out_t21," %5.2f",zi);
           }
	   flag=0;
	   fprintf(out_t21,"\n");
        }
	fclose(out_t21);
	////////////////////////////////////////////////////////////////////////////
	FILE *out_t1= fopen("thickness1.dat","w");
	fprintf(out_t1," 0.00");
	for (j=0;j<dimX0;j++){ xi=j*delta; fprintf(out_t1," %5.2f", xi); };
	fprintf(out_t1,"\n");
 
	flag=0;
	for(k=0;k<dimY0;k++){
	 
           for (j=0;j<dimX0;j++){ 	

                xi = j*delta;
                yi = k*delta;
 
		zi = fabs(memGD->gpt[j][k].tAVE) - fabs(memGD->gpt[j][k].mAVE);
		if(flag==0) { fprintf(out_t1,"%5.2f ", yi); flag=1;}; // Only print Y value at beginning of row
		fprintf(out_t1," %5.2f",zi);
           }
	   flag=0;
	   fprintf(out_t1,"\n");
        }
	fclose(out_t1);
	////////////////////////////////////////////////////////////////////////////
	FILE *out_t2= fopen("thickness2.dat","w");
	fprintf(out_t2," 0.00");
	for (j=0;j<dimX0;j++){ xi=j*delta; fprintf(out_t2," %5.2f", xi); };
	fprintf(out_t2,"\n");
 
	flag=0;
	for(k=0;k<dimY0;k++){
	 
           for (j=0;j<dimX0;j++){ 	

                xi = j*delta;
                yi = k*delta;
 
		zi = fabs(memGD->gpt[j][k].mAVE) - fabs(memGD->gpt[j][k].dAVE);
		if(flag==0) { fprintf(out_t2,"%5.2f ", yi); flag=1;}; // Only print Y value at beginning of row
		fprintf(out_t2," %5.2f",zi);
           }
	   flag=0;
	   fprintf(out_t2,"\n");
        }
	fclose(out_t2);
	// ################################################################################################

	FILE *out_lAt = fopen("lAt.dat","w");
	fprintf(out_lAt," 0.00");
	for (j=0;j<dimX0;j++){ xi=j*delta; fprintf(out_lAt," %5.2f", xi); };
	fprintf(out_lAt,"\n");

	flag=0;
	for(k=0;k<dimY0;k++){ 
           for (j=0;j<dimX0;j++){ 	

                xi = j*delta;
                yi = k*delta;
		zi = memGD->gpt[j][k].lAm1AVE; 
		 if(zi>0) printf("%f =====> \n", zi);
		if(flag==0) { fprintf(out_lAt,"%5.2f ", yi); flag=1;}; // Only print Y value at beginning of row
		fprintf(out_lAt," %5.2f", zi);
		//if(zi>0.0) printf(" ====================>  %f ", zi) ;
		 
           }
	   flag=0;
	   fprintf(out_lAt,"\n");
        }
	fclose(out_lAt);

	// ################################################################################################
	FILE *out_lAd = fopen("lAd.dat","w");
        fprintf(out_lAd," 0.00");
        for (j=0;j<dimX0;j++){ xi=j*delta; fprintf(out_lAd," %5.2f", xi); };
        fprintf(out_lAd,"\n");

        flag=0;
        for(k=0;k<dimY0;k++){
           for (j=0;j<dimX0;j++){

                xi = j*delta;
                yi = k*delta;
                zi =  memGD->gpt[j][k].lAm2AVE;
		if(zi>0) printf("%f =====> \n", zi);
                if(flag==0) { fprintf(out_lAt,"%7.4f ", yi); flag=1;}; // Only print Y value at beginning of row
                fprintf(out_lAt," %7.4f",  memGD->gpt[j][k].lAm2AVE);
		 
           }
           flag=0;
           fprintf(out_lAt,"\n");
        }
        fclose(out_lAt);

	////////////////////////////////////////////////////////////////////////////
	// PROTEIN
	/////////////////////////////////////////////////////////////////////////////
	FILE *out_prot = fopen("proteinbeads.dat","w");
	 
        for (prot=0;prot<sumprot;prot++){
             printf("prot= %d\n", prot);
              for(jp=0;jp<(*pdat)[prot].npts ;jp++){
                i=(*pdat)[prot].idx[jp];
                xi=(*x)[i][0];
                yi=(*x)[i][1];
                zi=(*x)[i][2];
		fprintf(out_prot,"  %f %f %f  \n",xi,yi,zi);
	     }
	}
	fclose(out_prot);
	////////////////////////////////////////////////////////////////////////////
 
}

 
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

void writejvxtick(char *dataout, t_2Dgrid *memGD, t_gopts *opts, t_ldat **ldat, t_pdat **pdat, t_memb *memb, rvec**x, matrix box)
{
        int i, jp, jat, lip, prot;
	int j, k;
	int nats;
	int slips;
	int sumprot;
	double xi, yi, zi;
	int uno, dos, tres, cuatro;
	double dimX0, dimY0,delta;



        nats = opts->np;
        //slips = opts->nlip;     
        slips = memb->slips;
	sumprot = opts->npro;

	FILE *out_m1 = fopen ("t1.jvx","w");
	FILE *out_m2 = fopen ("t2.jvx","w");
	FILE *out_m2m1=fopen("t12.jvx","w");
 
	FILE *out_t1 = fopen ("t1.dat","w");
	FILE *out_t2 = fopen ("t2.dat","w");
	FILE *out_t21= fopen("t12.dat","w");
	


	// HEADER
	fprintf(out_m1,"<?xml version=\"1.0\" encoding=\"ISO-8859-1\" standalone=\"no\"?>\n");
	fprintf(out_m1,"<jvx-model>\n");
	fprintf(out_m1,"   <title>monotichness 1</title>\n");
   	fprintf(out_m1,"<description>\n");
      	fprintf(out_m1,"<abstract>Very difficult 2.5 dimensional surface.</abstract>\n");
	fprintf(out_m1,"       <software>Flux Modeling Package, version 2.0</software>\n");
	fprintf(out_m1,"   </description>\n");
	fprintf(out_m1,"	<geometries>\n");
	// PROTEIN
	/////////////////////////////////////////////////////////////////////////////
        for (prot=0;prot<sumprot;prot++){
             printf("prot= %d\n", prot);

	     fprintf(out_m1,"      <geometry name=\"protein%d\">\n",prot);
	     fprintf(out_m1,"         <pointSet dim=\"5\" point=\"show\">\n");
	     fprintf(out_m1,"            <points>       \n");
             for(jp=0;jp<(*pdat)[prot].npts ;jp++){
                i=(*pdat)[prot].idx[jp];
                xi=(*x)[i][0];
                yi=(*x)[i][1];
                zi=(*x)[i][2];
		fprintf(out_m1,"               <p> %f %f %f </p>\n",xi,yi,zi);
	     }
		fprintf(out_m1,"               <thickness>5</thickness>\n");
	        fprintf(out_m1,"               <color>%d %d  %d</color>\n",200+10*prot, 250-10*prot, prot);
             fprintf(out_m1,"            </points>      \n");
             fprintf(out_m1,"         </pointSet>       \n");
	     fprintf(out_m1,"      </geometry>          \n");
	}



	// GRID
        // /////////////////////////////////////////////////////////////////////////
	// Top plane tickness
        

	dimX0=memGD->dimX0;
	dimY0=memGD->dimY0;
	delta=opts->delta;
        //

	// ======================================================================
	// ======================================================================
	// 	TOP LEAFLET TICKNESS
	// ======================================================================
	// ======================================================================

        fprintf(out_m1,"      <geometry name=\"grid points top-plane tickness\">\n");
        fprintf(out_m1,"         <pointSet dim=\"3\" point=\"show\">\n");
        fprintf(out_m1,"            <points>       \n");
        for (j=0;j<dimX0;j++){
            for(k=0;k<dimY0;k++){
                xi=j*delta;
                yi=k*delta;
                //zi=memGD->gpt[j][k].dAVE;
		zi=memGD->gpt[j][k].m1tickAVE;
                fprintf(out_m1,"               <p> %f %f %f </p>\n", xi, yi, zi);
            }
        }
	fprintf(out_m1,"		    <color>0 200 0</color>\n");
        fprintf(out_m1,"               <thickness>1</thickness>\n");
        fprintf(out_m1,"            </points>      \n");
        fprintf(out_m1,"         </pointSet>       \n");
        fprintf(out_m1,"          <faceSet face=\"show\" edge=\"show\">\n");
        fprintf(out_m1,"           <faces>\n");
        for (j=0;j<=dimX0-2;j++){
            for(k=0;k<=dimY0-2;k++){
                uno=j+k*dimX0;
                dos=j+1+k*dimX0;
                tres=j+1+(k+1)*dimX0;
                cuatro=j+(k+1)*dimX0;
                fprintf(out_m1,"               <f> %d %d %d %d </f>\n", uno ,dos, tres, cuatro);
            }
        }
//        fprintf(out_m1,"               <color>0 255 0</color>\n");
        fprintf(out_m1,"           </faces>\n");
        fprintf(out_m1,"           </faceSet>\n");
	fprintf(out_m1,"      <material>      	\n");
        fprintf(out_m1,"         <specular> \n");
        fprintf(out_m1,"            <color type=\"rgb\">255 255 255</color> \n");
        fprintf(out_m1,"         </specular> \n");
   //     fprintf(out_m1,"     <transparency visible=\"show\">0.5</transparency>\n");
        fprintf(out_m1,"      </material>          \n");
        fprintf(out_m1,"      </geometry>          \n");

	// BOX
	// //////////////////////////////////////////////////////////////////////////
        fprintf(out_m1,"      <geometry name=\"case\">\n");
        fprintf(out_m1,"         <pointSet dim=\"3\" point=\"hide\">\n");
	fprintf(out_m1,"            <points>	\n");
	fprintf(out_m1,"               <p> %f %f %f </p>\n", 0.0      , 0.0      , 0.0);
        fprintf(out_m1,"               <p> %f %f %f </p>\n", box[0][0], 0.0      , 0.0);
        fprintf(out_m1,"               <p> %f %f %f </p>\n", box[0][0], box[1][1], 0.0);
        fprintf(out_m1,"               <p> %f %f %f </p>\n", 0.0      , box[1][1], 0.0);
        fprintf(out_m1,"               <p> %f %f %f </p>\n", 0.0      , 0.0      , box[2][2]);
        fprintf(out_m1,"               <p> %f %f %f </p>\n", box[0][0], 0.0      , box[2][2]);
        fprintf(out_m1,"               <p> %f %f %f </p>\n", box[0][0], box[1][1], box[2][2]);
        fprintf(out_m1,"               <p> %f %f %f </p>\n", 0.0      , box[1][1], box[2][2]);
	fprintf(out_m1,"            </points>	\n");
        fprintf(out_m1,"         </pointSet>	\n");
        fprintf(out_m1,"         <lineSet line=\"show\">\n");
        fprintf(out_m1,"            <lines> 	\n");
        fprintf(out_m1,"               <l>0 1</l>	\n");
        fprintf(out_m1,"               <l>1 2</l>	\n");
        fprintf(out_m1,"               <l>2 3</l>	\n");
        fprintf(out_m1,"               <l>3 0</l>	\n");
        fprintf(out_m1,"               <l>0 4</l>	\n");
        fprintf(out_m1,"               <l>1 5</l>	\n");
        fprintf(out_m1,"               <l>2 6</l>	\n");
        fprintf(out_m1,"               <l>3 7</l>	\n");
        fprintf(out_m1,"               <l>4 5</l>	\n");
        fprintf(out_m1,"               <l>5 6</l>	\n");
        fprintf(out_m1,"               <l>6 7</l>	\n");
        fprintf(out_m1,"               <l>7 4</l>	\n");
        fprintf(out_m1,"               <color>0 0 0</color> \n");
        fprintf(out_m1,"            </lines>	\n");
        fprintf(out_m1,"         </lineSet>	\n");
        fprintf(out_m1,"      </geometry>		\n");
	//
	fprintf(out_m1,"   </geometries>\n");
	fprintf(out_m1,"</jvx-model>\n");

	fclose(out_m1);

	// m1 dat changed name to:
	// t1 dat t for thickness
	// The idea is to create a .dat format file. First plot the row. Element 0,0 has value 0
	// first row is X axis. Column 0 is used for axis Y labels. 
	// Place first row
	fprintf(out_t1," 0.00");
	for (j=0;j<dimX0;j++){ xi=j*delta; fprintf(out_t1," %5.2f", xi); };
	fprintf(out_t1,"\n");

	int flag;
	flag=0;
	for(k=0;k<dimY0;k++){
	 
           for (j=0;j<dimX0;j++){ 	

                xi=j*delta;
                yi=k*delta;
		zi=memGD->gpt[j][k].m1tickAVE;
		if(flag==0) { fprintf(out_t1,"%5.2f ", yi); flag=1;}; // Only print Y value at beginning of row
		fprintf(out_t1," %6.3f",zi);
           }
	   flag=0;
	   fprintf(out_t1,"\n");
        }
	fclose(out_t1);
	// ======================================================================
	// ======================================================================
	// 	LOWER LEAFLET TICKNESS
	// ======================================================================
	// ======================================================================


	// HEADER
	fprintf(out_m2,"<?xml version=\"1.0\" encoding=\"ISO-8859-1\" standalone=\"no\"?>\n");
	fprintf(out_m2,"<jvx-model>\n");
	fprintf(out_m2,"   <title>monotichness 1</title>\n");
   	fprintf(out_m2,"<description>\n");
      	fprintf(out_m2,"<abstract>Very difficult 2.5 dimensional surface.</abstract>\n");
	fprintf(out_m2,"       <software>Flux Modeling Package, version 2.0</software>\n");
	fprintf(out_m2,"   </description>\n");
	fprintf(out_m2,"	<geometries>\n");
	// PROTEIN
	/////////////////////////////////////////////////////////////////////////////
        for (prot=0;prot<sumprot;prot++){
             printf("prot= %d\n", prot);

	     fprintf(out_m2,"      <geometry name=\"protein%d\">\n",prot);
	     fprintf(out_m2,"         <pointSet dim=\"5\" point=\"show\">\n");
	     fprintf(out_m2,"            <points>       \n");
             for(jp=0;jp<(*pdat)[prot].npts ;jp++){
                i=(*pdat)[prot].idx[jp];
                xi=(*x)[i][0];
                yi=(*x)[i][1];
                zi=(*x)[i][2];
		fprintf(out_m2,"               <p> %f %f %f </p>\n",xi,yi,zi);
	     }
		fprintf(out_m2,"               <thickness>5</thickness>\n");
	        fprintf(out_m2,"               <color>%d %d  %d</color>\n",200+10*prot, 250-10*prot, prot);
             fprintf(out_m2,"            </points>      \n");
             fprintf(out_m2,"         </pointSet>       \n");
	     fprintf(out_m2,"      </geometry>          \n");
	}

	// GRID
        // /////////////////////////////////////////////////////////////////////////
  
     // =====================
     // Down plane
     // =====================
        fprintf(out_m2,"      <geometry name=\"grid points down-plane\">\n");
        fprintf(out_m2,"         <pointSet dim=\"3\" point=\"show\">\n");
        fprintf(out_m2,"            <points>       \n");
        for (j=0;j<dimX0;j++){
            for(k=0;k<dimY0;k++){
                xi=j*delta;
                yi=k*delta;
                zi=memGD->gpt[j][k].m2tickAVE;
                fprintf(out_m2,"               <p> %f %f %f </p>\n", xi, yi, zi);
            }
        }
	fprintf(out_m2,"		    <color>0 200 0</color>\n");
        fprintf(out_m2,"               <thickness>1</thickness>\n");
        fprintf(out_m2,"            </points>      \n");
        fprintf(out_m2,"         </pointSet>       \n");
        fprintf(out_m2,"          <faceSet face=\"show\" edge=\"show\">\n");
        fprintf(out_m2,"           <faces>\n");
        for (j=0;j<=dimX0-2;j++){
            for(k=0;k<=dimY0-2;k++){
                uno=j+k*dimX0;
                dos=j+1+k*dimX0;
                tres=j+1+(k+1)*dimX0;
                cuatro=j+(k+1)*dimX0;
                fprintf(out_m2,"               <f> %d %d %d %d </f>\n", uno ,dos, tres, cuatro);
            }
        }
//        fprintf(out_m2,"               <color>0 255 0</color>\n");
        fprintf(out_m2,"           </faces>\n");
        fprintf(out_m2,"           </faceSet>\n");
	fprintf(out_m2,"      <material>      	\n");
        fprintf(out_m2,"         <specular> \n");
        fprintf(out_m2,"            <color type=\"rgb\">255 255 255</color> \n");
        fprintf(out_m2,"         </specular> \n");
    //    fprintf(out_m2,"     <transparency visible=\"show\">0.5</transparency>\n");
        fprintf(out_m2,"      </material>          \n");
        fprintf(out_m2,"      </geometry>          \n");

	// BOX
	// //////////////////////////////////////////////////////////////////////////
        fprintf(out_m2,"      <geometry name=\"case\">\n");
        fprintf(out_m2,"         <pointSet dim=\"3\" point=\"hide\">\n");
	fprintf(out_m2,"            <points>	\n");
	fprintf(out_m2,"               <p> %f %f %f </p>\n", 0.0      , 0.0      , 0.0);
        fprintf(out_m2,"               <p> %f %f %f </p>\n", box[0][0], 0.0      , 0.0);
        fprintf(out_m2,"               <p> %f %f %f </p>\n", box[0][0], box[1][1], 0.0);
        fprintf(out_m2,"               <p> %f %f %f </p>\n", 0.0      , box[1][1], 0.0);
        fprintf(out_m2,"               <p> %f %f %f </p>\n", 0.0      , 0.0      , box[2][2]);
        fprintf(out_m2,"               <p> %f %f %f </p>\n", box[0][0], 0.0      , box[2][2]);
        fprintf(out_m2,"               <p> %f %f %f </p>\n", box[0][0], box[1][1], box[2][2]);
        fprintf(out_m2,"               <p> %f %f %f </p>\n", 0.0      , box[1][1], box[2][2]);
	fprintf(out_m2,"            </points>	\n");
        fprintf(out_m2,"         </pointSet>	\n");
        fprintf(out_m2,"         <lineSet line=\"show\">\n");
        fprintf(out_m2,"            <lines> 	\n");
        fprintf(out_m2,"               <l>0 1</l>	\n");
        fprintf(out_m2,"               <l>1 2</l>	\n");
        fprintf(out_m2,"               <l>2 3</l>	\n");
        fprintf(out_m2,"               <l>3 0</l>	\n");
        fprintf(out_m2,"               <l>0 4</l>	\n");
        fprintf(out_m2,"               <l>1 5</l>	\n");
        fprintf(out_m2,"               <l>2 6</l>	\n");
        fprintf(out_m2,"               <l>3 7</l>	\n");
        fprintf(out_m2,"               <l>4 5</l>	\n");
        fprintf(out_m2,"               <l>5 6</l>	\n");
        fprintf(out_m2,"               <l>6 7</l>	\n");
        fprintf(out_m2,"               <l>7 4</l>	\n");
        fprintf(out_m2,"               <color>0 0 0</color> \n");
        fprintf(out_m2,"            </lines>	\n");
        fprintf(out_m2,"         </lineSet>	\n");
        fprintf(out_m2,"      </geometry>		\n");
	//
	fprintf(out_m2,"   </geometries>\n");
	fprintf(out_m2,"</jvx-model>\n");

	fclose(out_m2);

	// /////////////////////////////////////////////////////////////////////////////////
	// m1 dat changed name to:
	// t1 dat t for thickness
	// The idea is to create a .dat format file. First plot the row. Element 0,0 has value 0
	// first row is X axis. Column 0 is used for axis Y labels. 
	// Place first row
	fprintf(out_t2," 0.00");
	for (j=0;j<dimX0;j++){ xi=j*delta; fprintf(out_t2," %7.4f", xi); };
	fprintf(out_t2,"\n");

	flag=0;
	for(k=0;k<dimY0;k++){
	 
           for (j=0;j<dimX0;j++){ 	

                xi=j*delta;
                yi=k*delta;
		zi=memGD->gpt[j][k].m2tickAVE;
		if(flag==0) { fprintf(out_t2,"%7.4f ", yi); flag=1;}; // Only print Y value at beginning of row
		fprintf(out_t2," %7.4f",zi);
           }
	   flag=0;
	   fprintf(out_t2,"\n");
        }
	fclose(out_t2);

	//
	// /////////////////////////////////////////////////////////////////////////////////


	// HEADER
	fprintf(out_m2m1,"<?xml version=\"1.0\" encoding=\"ISO-8859-1\" standalone=\"no\"?>\n");
	fprintf(out_m2m1,"<jvx-model>\n");
	fprintf(out_m2m1,"   <title>monotichness 1</title>\n");
   	fprintf(out_m2m1,"<description>\n");
      	fprintf(out_m2m1,"<abstract>Very difficult 2.5 dimensional surface.</abstract>\n");
	fprintf(out_m2m1,"       <software>Flux Modeling Package, version 2.0</software>\n");
	fprintf(out_m2m1,"   </description>\n");
	fprintf(out_m2m1,"	<geometries>\n");
	// PROTEIN
	/////////////////////////////////////////////////////////////////////////////
        for (prot=0;prot<sumprot;prot++){
             printf("prot= %d\n", prot);

	     fprintf(out_m2m1,"      <geometry name=\"protein%d\">\n",prot);
	     fprintf(out_m2m1,"         <pointSet dim=\"5\" point=\"show\">\n");
	     fprintf(out_m2m1,"            <points>       \n");
             for(jp=0;jp<(*pdat)[prot].npts ;jp++){
                i=(*pdat)[prot].idx[jp];
                xi=(*x)[i][0];
                yi=(*x)[i][1];
                zi=(*x)[i][2];
		fprintf(out_m2m1,"               <p> %f %f %f </p>\n",xi,yi,zi);
	     }
		fprintf(out_m2m1,"               <thickness>5</thickness>\n");
	        fprintf(out_m2m1,"               <color>%d %d  %d</color>\n",200+10*prot, 250-10*prot, prot);
             fprintf(out_m2m1,"            </points>      \n");
             fprintf(out_m2m1,"         </pointSet>       \n");
	     fprintf(out_m2m1,"      </geometry>          \n");
	}
 

	// ======================================================================
	// ======================================================================
	// 	BILAYER TICKNESS
	// ======================================================================
	// ======================================================================

        fprintf(out_m2m1,"      <geometry name=\"grid points bilayer tickness\">\n");
        fprintf(out_m2m1,"         <pointSet dim=\"3\" point=\"show\">\n");
        fprintf(out_m2m1,"            <points>       \n");
        for (j=0;j<dimX0;j++){
            for(k=0;k<dimY0;k++){
                xi=j*delta;
                yi=k*delta;
		// Sum of thickness for top and bottom leaflets
		zi=memGD->gpt[j][k].m1tickAVE + memGD->gpt[j][k].m2tickAVE;
                fprintf(out_m2m1,"               <p> %f %f %f </p>\n", xi, yi, zi);
            }
        }
	fprintf(out_m2m1,"		    <color>0 200 0</color>\n");
        fprintf(out_m2m1,"               <thickness>1</thickness>\n");
        fprintf(out_m2m1,"            </points>      \n");
        fprintf(out_m2m1,"         </pointSet>       \n");
        fprintf(out_m2m1,"          <faceSet face=\"show\" edge=\"show\">\n");
        fprintf(out_m2m1,"           <faces>\n");
        for (j=0;j<=dimX0-2;j++){
            for(k=0;k<=dimY0-2;k++){
                uno=j+k*dimX0;
                dos=j+1+k*dimX0;
                tres=j+1+(k+1)*dimX0;
                cuatro=j+(k+1)*dimX0;
                fprintf(out_m2m1,"               <f> %d %d %d %d </f>\n", uno ,dos, tres, cuatro);
            }
        }
//        fprintf(out_m2m1,"               <color>0 255 0</color>\n");
        fprintf(out_m2m1,"           </faces>\n");
        fprintf(out_m2m1,"           </faceSet>\n");
	fprintf(out_m2m1,"      <material>      	\n");
        fprintf(out_m2m1,"         <specular> \n");
        fprintf(out_m2m1,"            <color type=\"rgb\">255 255 255</color> \n");
        fprintf(out_m2m1,"         </specular> \n");
  //      fprintf(out_m2m1,"     <transparency visible=\"show\">0.5</transparency>\n");
        fprintf(out_m2m1,"      </material>          \n");
        fprintf(out_m2m1,"      </geometry>          \n");

	// BOX
	// //////////////////////////////////////////////////////////////////////////
        fprintf(out_m2m1,"      <geometry name=\"case\">\n");
        fprintf(out_m2m1,"         <pointSet dim=\"3\" point=\"hide\">\n");
	fprintf(out_m2m1,"            <points>	\n");
	fprintf(out_m2m1,"               <p> %f %f %f </p>\n", 0.0      , 0.0      , 0.0);
        fprintf(out_m2m1,"               <p> %f %f %f </p>\n", box[0][0], 0.0      , 0.0);
        fprintf(out_m2m1,"               <p> %f %f %f </p>\n", box[0][0], box[1][1], 0.0);
        fprintf(out_m2m1,"               <p> %f %f %f </p>\n", 0.0      , box[1][1], 0.0);
        fprintf(out_m2m1,"               <p> %f %f %f </p>\n", 0.0      , 0.0      , box[2][2]);
        fprintf(out_m2m1,"               <p> %f %f %f </p>\n", box[0][0], 0.0      , box[2][2]);
        fprintf(out_m2m1,"               <p> %f %f %f </p>\n", box[0][0], box[1][1], box[2][2]);
        fprintf(out_m2m1,"               <p> %f %f %f </p>\n", 0.0      , box[1][1], box[2][2]);
	fprintf(out_m2m1,"            </points>	\n");
        fprintf(out_m2m1,"         </pointSet>	\n");
        fprintf(out_m2m1,"         <lineSet line=\"show\">\n");
        fprintf(out_m2m1,"            <lines> 	\n");
        fprintf(out_m2m1,"               <l>0 1</l>	\n");
        fprintf(out_m2m1,"               <l>1 2</l>	\n");
        fprintf(out_m2m1,"               <l>2 3</l>	\n");
        fprintf(out_m2m1,"               <l>3 0</l>	\n");
        fprintf(out_m2m1,"               <l>0 4</l>	\n");
        fprintf(out_m2m1,"               <l>1 5</l>	\n");
        fprintf(out_m2m1,"               <l>2 6</l>	\n");
        fprintf(out_m2m1,"               <l>3 7</l>	\n");
        fprintf(out_m2m1,"               <l>4 5</l>	\n");
        fprintf(out_m2m1,"               <l>5 6</l>	\n");
        fprintf(out_m2m1,"               <l>6 7</l>	\n");
        fprintf(out_m2m1,"               <l>7 4</l>	\n");
        fprintf(out_m2m1,"               <color>0 0 0</color> \n");
        fprintf(out_m2m1,"            </lines>	\n");
        fprintf(out_m2m1,"         </lineSet>	\n");
        fprintf(out_m2m1,"      </geometry>		\n");
	//
	fprintf(out_m2m1,"   </geometries>\n");
	fprintf(out_m2m1,"</jvx-model>\n");

	fclose(out_m2m1);

 

	// ###############################################################################################
	fprintf(out_t21," 0.00");
	for (j=0;j<dimX0;j++){ xi=j*delta; fprintf(out_t21," %5.2f", xi); };
	fprintf(out_t21,"\n");

	flag=0;
	for(k=0;k<dimY0;k++){
	 
           for (j=0;j<dimX0;j++){ 	

                xi = j*delta;
                yi = k*delta;
		zi = memGD->gpt[j][k].m1tickAVE + memGD->gpt[j][k].m2tickAVE;
		if(flag==0) { fprintf(out_t21,"%5.2f ", yi); flag=1;}; // Only print Y value at beginning of row
		fprintf(out_t21," %5.2f",zi);
           }
	   flag=0;
	   fprintf(out_t21,"\n");
        }
	fclose(out_t21);
	// ###############################################################################################




}

