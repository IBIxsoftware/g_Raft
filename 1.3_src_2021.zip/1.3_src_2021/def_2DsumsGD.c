/*
 *
 *      Parser for Graft input
 *
 */

#include <stdio.h>
#include <stdlib.h>

#include <stddef.h>
#include <ctype.h>
#include <string.h>
#include <math.h>

#include "parser.h"

/*
#define arr_size 250 
#define smallsize 20
#define MAXLIP 65 
#define CHAINATS 60
*/

// SUMS STRUCTURE ALLOCATION
// ###########################################################
t_2Dsums def_2DsumsGD(t_gopts *opts, matrix box){
	
	t_2Dsums sumsGD;

	int j, k;
	int dimX0, dimY0;
	double delta;

	delta=opts->delta;

	dimX0=(int) (floor(box[0][0]/delta)) + 1;
	dimY0=(int) (floor(box[1][1]/delta)) + 1;
	printf("Creating a %dx%d grid for curvature calculations \n", dimX0, dimY0);

	sumsGD.gpt=calloc(dimX0, sizeof(t_gpt *));
	for(j=0;j<dimX0;j++){
		sumsGD.gpt[j]=calloc(dimY0,sizeof(t_gpt));
	} 
 
	opts->dimX0=dimX0;
	opts->dimY0=dimY0;

	// =======================================
	sumsGD.dimX0=dimX0;
	sumsGD.dimY0=dimY0;
	sumsGD.nframes=0;
	for(j=0;j<dimX0;j++){
		for(k=0;k<dimY0;k++){
		     // Midplane sums
		     // =========================
			// TOP
			sumsGD.gpt[j][k].Nt=0;
			sumsGD.gpt[j][k].ts=0.0;
			sumsGD.gpt[j][k].ts2=0.0;
			sumsGD.gpt[j][k].tdistLP=0.0;  // Lipid_membrane-protein distance

			// MIDPLANE
			sumsGD.gpt[j][k].Nm=0;
			sumsGD.gpt[j][k].ms=0.0;
			sumsGD.gpt[j][k].ms2=0.0;
			sumsGD.gpt[j][k].mdistLP=0.0;  // Lipid_membrane-protein distance

			// DOWN PLANE
			sumsGD.gpt[j][k].Nd=0;
			sumsGD.gpt[j][k].ds=0.0;
			sumsGD.gpt[j][k].ds2=0.0;
			sumsGD.gpt[j][k].ddistLP=0.0;  // Lipid_membrane-protein distance
                     // =========================
                     // Gradients for Curvature
                     // =========================
                     /*
 			sumsGD.gpt[j][k].fx=0.0;
			sumsGD.gpt[j][k].fy=0.0;
			sumsGD.gpt[j][k].fxx=0.0;
			sumsGD.gpt[j][k].fxy=0.0;		                    
			sumsGD.gpt[j][k].fyy=0.0;
		     */
                     // =========================
                     // Order Parameters
                     // =========================

		     // =========================
		     //	Initialization Lipid A type density sums
		     // =========================
			sumsGD.gpt[j][k].sNt_Alip=0;
			sumsGD.gpt[j][k].st_Alip=0.0;
                        sumsGD.gpt[j][k].st2_Alip=0.0;

                        sumsGD.gpt[j][k].sNd_Alip=0;
                        sumsGD.gpt[j][k].sd_Alip=0.0;
                        sumsGD.gpt[j][k].sd2_Alip=0.0;
		     // =========================
		}
	}

	return sumsGD;
}


// GLOBAL GRID ALLOCATION & INITIALIZATION
// ###########################################################
/*
t_2Dgrid def_2Dgrid(t_gopts *opts, matrix box){

 	t_2Dgrid memGD;

	int j, k;
	int dimX0, dimY0;
	double delta;

	delta=opts->delta;

	dimX0=opts->dimX0;
	dimY0=opts->dimY0;

	memGD.dimX0=dimX0;
	memGD.dimY0=dimY0;

	printf("Creating a %d x %d grid for curvature calculations \n", dimX0, dimY0);

	memGD.gpt=calloc(dimX0, sizeof(t_gpt *));
	for(j=0;j<dimX0;j++){
		//printf("Hi\n");
		memGD.gpt[j]=calloc(dimY0,sizeof(t_gpt));
	} 
 
	printf("memGD.gpt Allocated \n");

	// =======================================
	memGD.dimX0=dimX0;
	memGD.dimY0=dimY0;
	memGD.delta=delta;
	for(j=0;j<dimX0;j++){
		for(k=0;k<dimY0;k++){
		     // Top, Midplane, and Down plane
		     // =========================================
			
			memGD.gpt[j][k].tAVE=0.0; 
			memGD.gpt[j][k].tVAR=0.0;  
			memGD.gpt[j][k].tSEM=0.0;

			memGD.gpt[j][k].mAVE=0.0;
			memGD.gpt[j][k].mVAR=0.0;
			memGD.gpt[j][k].mSEM=0.0;

			memGD.gpt[j][k].dAVE=0.0;
			memGD.gpt[j][k].dVAR=0.0;
			memGD.gpt[j][k].dSEM=0.0;
		     // Lipid tickness monolayer1 and monolayer 2 
		     // =========================================
			memGD.gpt[j][k].m1tickAVE=0.0;
			memGD.gpt[j][k].m1tickVAR=0.0;
			memGD.gpt[j][k].m1tickSEM=0.0;

			memGD.gpt[j][k].m2tickAVE=0.0;
			memGD.gpt[j][k].m2tickVAR=0.0;
			memGD.gpt[j][k].m2tickSEM=0.0;
		     // Density lipid type A
		     // =========================================
			memGD.gpt[j][k].m1lA_AVE=0.0;
			memGD.gpt[j][k].m1lA_VAR=0.0;
			memGD.gpt[j][k].m1lA_SEM=0.0;
			
                        memGD.gpt[j][k].m2lA_AVE=0.0;
                        memGD.gpt[j][k].m2lA_VAR=0.0;
                        memGD.gpt[j][k].m2lA_SEM=0.0;

		     // =========================================	
		}
	}

	return memGD;
}

*/
	
