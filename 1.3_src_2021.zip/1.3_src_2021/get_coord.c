/*
 *
 *	
 *
 * 	This file includes get_cordprot,   get_cordvor and get_cordsurf
 *
 */


#include <stdio.h>
#include <stdlib.h>

#include <stddef.h>
#include <ctype.h>
#include <string.h>
#include "math.h"

#include "parser.h"
#include "readinp.h"

#define arr_size 80 
#define MAXLIP 10 
#define CHAINATS 40

//
//
//	coordprot: Update protein coordinates and store at pdat variable
//		   coordinates are used by both, voronoi and surface calc 
//		   analysis methods.
//
// //////////////////////////////////////////////////////////////////////////////
double cost(rvec *v1, rvec *v2);
double distvec(rvec vref, rvec vtry, matrix box);

coordprot(t_gopts *opts, t_pdat **pdat, rvec **x)
{
        int i;
	int sumprot;
	int prot;
	int jat;
	double xi, yi, zi;

	sumprot = opts->npro;
	
	//printf("INSIDE coordprot \n");

        for (prot=0;prot<sumprot;prot++){
	     printf("prot= %d\n", prot);
	     for(i=0;i<(*pdat)[prot].npts ;i++){
		jat=(*pdat)[prot].idx[i];
		xi=(*x)[jat][0];
		yi=(*x)[jat][1];
		zi=(*x)[jat][2];
		// Do something 
	     	// printf("HI%d %f %f %f\n ", jat, xi, yi, zi);
		
	     }
	     
	}
	
}

/*
// //////////////////////////////////////////////////////////////////////////////
coordvpts(t_gopts *opts, t_ldat **ldat, t_memb *memb, rvec **x)
{
	int i, lip;
	int nats;
	int natoms;
	int nprots;
	int slips;
	int njlips;
	char *lname;
	char *aname;
	
	int jp;
	double xp, yp, zp;
	
	nats = opts->np;
	slips = opts->nltypes; 	// num lipid types
*/
	/*
	for(lip=0;lip<nlips;lip++){
		// Iterate over lipid types
		//
		lname=(*ldat)[lip].lname;
		aname=(*ldat)[lip].fa;
		for(i=0;i<nats;i++){
	   	    
		   
		}
	}
	*/
/*
	for(jp=0; jp< slips; jp++){
		i = (*memb).lidx[jp];
		xp=(*x)[i][0];  yp=(*x)[i][1];  zp=(*x)[i][2];
		

	}

}
*/
// //////////////////////////////////////////////////////////////////////////////
