/*
 *
 *	This file declares all variables used by g_raft
 *
 */

// gmx_bool, matrix, tensor defined at simple.h
// matrix and tensors are 3 by 3
#include <stdio.h>
#include <stdlib.h>

#ifndef _parser_h
#define _parser_h

#include "typedefs.h"
#include "string2.h"
#include "readinp.h"
#include "grompp.h"
#include "smalloc.h" // Contains srenew 

// LIPID DEFINITIONS
// ===================================
typedef struct{
   // INDIVIDUAL LIPID INFORMATION
   // LIPID DATA
   // ==================
   int gid;		// Group ID
   int natxl;		// number of particles or atoms in lipid
   char lname[6];	// Name, i.e. "DAPC"
   char fa[5];          // first atom name
   char la[5];          // last atom name

   int nsup, *lsup;	// number of ats to define upper-surface, and associated list. i.e 2, [3,4] 
   int nsdown, *lsdown;	// number of ats to define bottom-surface and associated list, i.e 2, [8 12]
   //int nv, *vbead;      // Number of voronoi particles, and list with ref to first bead

   int nvsites, *vsites; // Numver of voronoi sites, and v-sites
   int nq6, *q6bead;	// Beads for phi_6 order parameter analyses 

   int nt;              // Number of tails

   double *P2trCh;      // Pz treshold

   // DATA PER TAIL
   // ==================
   int *naxt; 		// Number of atoms per tail, i.e. [6 8],
   			//  vector dimension "nt"
   int **tal;   	// Tail Atom List. Matrix. Dim nt X naxt
   double Pzlipid;	// 
   double *Pztail;	// Pz=Sum 1/2(3-cos A)
   double **P2cut;	// Pzcut
   int **PZexcl;	// Pzangles not taken

   // SYSTEM SPECIFIC
   // ==================
   int nlips;		// Number of lipids of this type

} t_ldat;

// PROTEIN DEFINITIONS
// ===================================
// SINGLE-PROTEIN STRUCTURE
typedef struct {
	int gid; 	// Group it belongs
	char pname[6];	// Protein name

	char bn[5];	// Bead name
	int fa, la;	// first and last atom interval
 // int ptype; 		// 1=surface, 2=inserted protein.
 // int pbead;		
 	int npts; 	// Number of beads (remember this is per protein)
	int *idx;	// index numbers to x, size npts
	rvec *x;	// size npts
} t_pdat;

typedef struct{
	int np;
	int nlips; 
	rvec *vp;	// Voronoi center points malloc(nvpts*sizeof(rvec))
	
} t_vpts; // Voronoi space


typedef struct{
	int np;		// num of particles
	int npx; 	// Extra npx
	int nlip;	// Number of lipids
	double *Pz;	// Pz by lipid

	int sch;	// sum of chains?
	double *Pzch;	// Pz by chain

	int snv;	// Sum nv particles in fundamental square
	int snvextra;	// Total vertex particles in extended grid.
	int *vlist;     // Size: snv, value=index, elements are consecutive
	int *vindex;	// natoms

} t_surf; //  surface available space


typedef struct{
	int lidx;	// First bead index
	rvec Nlip;	// Local normal
	rvec Hlip;	// Local normal
	rvec Tlip;	// Lipid head
	int ltype;	// lipid type. i.e. 0, 1, 2 if you have 3 lipids types on your system
	int lUorD; 	// Belonging to upper or lower monolayer (2D case)
			// Suord[j]=1 => up, Suord[j]=0 ==> down,
	char lname[6];	// Lipid name
} t_lip; 


// CONTAINS COORDINATE DATA 
// for definition of lipids check t_ldat 
// ===========================================================
typedef struct{
	// HEAD SPACE (first frame Lipids)
	int slips;	// Number of lipids

	int *lidx;	// First bead index (referred to membrane data)
	rvec *Nlip;	// Local normal	
	rvec *Hlip;	// Lipid head
	rvec *Tlip;	// Tail position average
	int *ltype;     // lipid type. i.e. 0, 1, 2 if you have 3 lipids types on your system

	int *lUorD;	// Belonging to upper or lower monolayer (2D case)
			// Suord[j]=1 => up, Suord[j]=0 ==> down,
 	char lname[6];
	// SUBSTITUTE THE STATEMENT GIVEN ABOVE
	t_lip *lipid;

	// SURFACE SPACE (Lipids) 
	int sspts;
	int ssptsxtra;
	int *sptslst;
 
	char *indxRefrm; 

        // V-SITE SPACE (Lipids) used to be voronoi.
	int *vptsxlip;  // vector of v-sites  (num_of_lipids)
	int svpts; 	// sum of vsites (NOT sum of lipids)
	int *vptslnum; 	// each element mapped to lipid number (size svpts)
	int *vpts; 	// particle-number (size svpts)

	// PROTEIN SPACE
	int sprot;
	int *nprot;	

} t_memb;		// system

// SYSTEM+CURVATURE FLAGS
// ===================================
typedef struct options {
	int np;		// Number of particles 

	// SYSTEM FLAGS
	int tes;	// Tesselation
	int sys;	// System
	int pro;	// Procedure
	int clu;	// Pz, m6, Pz&m6

	int cur;	// Curvature
	double delta;	// delta for grid spacing
	int geo;	// geo;         // 1=Planar, 2=polar, 3=spherical
	int fty;        // 1=Binomial (default), 2=MEX wavelet
	int fw;		// filter width (standard, for fty=1 is 9, for fty=2 is 13)
	double ftyshift;// filter shift 
//	double fde;     // Grid spacing
	int fbn;        // number of bins
	int fop;	// Optional flag

	// SYSTEM SPECIFIC VARIABLES
	// Membrane variables
	int nlgp;	// Number of lipid groups
	int nltypes;       // Number of lipids of each type
	//int lgid;	// Lipid gid [1..nlip], i.e. 1 1 1 2 2 for nlip=5
     	// Protein Variables
	int npgp;	// Number of protein groups 
	int npro;       // Number of proteins
	//int **pmat;	// Protein Matrix

	double dB;	// Delta, buffer for pbc
	double rcut_h;	// cutoff raddi head
	double rcut_vll;// cutoff raddi voronoi lipid-lipid
	double rcut_vlp;// curoff raddi voronoi lipid-protein. defailt = rcut_v
	double rcut_vpp;// curoff raddi voronoi protein-protein, default = rcut_v
	double rcut_t;  // cutoff raddi tail

	int density;	// Flag activates 3D density options
	int enrich;
	int fw3D;	// Filter width 3D option

	// TRAJECTORY ANALYSIS
	int frminit, frmend, frmskip; 	// initial, final, and skip frames
					// only used for trajectory analyses

	int dimX0, dimY0, dimZ0; // Dimension of grid 

} t_gopts;	// OUTPUT FLAGS

int gid[100];

// 2Dgrid Temporary (get data before processing)
// This is were you put your data first

	typedef struct{
	     // =====================
	     // Thickness 
		int Nt; double t; // Top (number of elements, value)
		int Nm; double m; // Middle (number of elements, value)
		int Nd; double d; // Down (number of elements, value)
	     // Curvature
	     // =====================
		// Mean
		int K_Nt, K_Nm, K_Nd;
		double K_t, K_m, K_d;
		// Gaussian
		int G_Nt, G_Nm, G_Nd;
		double G_t, G_m, G_d;
 	     // Lipid type-A density
	     // =====================
		double lA_t, lA_d; 
 	     // P2 Order parameter
	     // =====================
		int P2_Nt, P2_Nd;
		double P2_t, P2_d;
	     // F6 Order parameter
	     // =====================
		int F6_Nt, F6_Nd;
		double F6_t, F6_d;
	     // =====================		
	} t_gsml;

// 2Dgrid sums USED FOR STATS ALONG TIME
// #####################################################################
	typedef struct{
		// Thickness variables
		// ========================
		int Nt;		; // Number of points top on grid point
		double ts, ts2  ; // sum and	
		double tdistLP  ; // Distance to protein
   
		int Nm;
		double ms, ms2; 
		double mdistLP;

		int Nd;
		double ds, ds2; 
		double ddistLP;

		// Lipid per face variables 2D density map
		// ========================
		int sNt_Alip;	// Lipid class A top count
		double st_Alip; // Lipid class A top value
		double st2_Alip;// Lipid class A top sum of squares  
	
		int sNd_Alip;	// Lipid class A down
		double sd_Alip;	// Lipid class A down sum
		double sd2_Alip;// Lipid class A down sum of squares

		// Gradient
		// ========================
		//double fx, fy;
		//double fxx, fxy, fyy;

	
	} t_gsums;
	// =================================================
	typedef struct{
		int nframes;	// number of frames
		int dimX0;
		int dimY0;
		int nt, nm, nd; // number of counts at top, middle and down
		t_gsums **gpt;  // gridpoint array of sums
	} t_2Dsums;

// 2Dgrid definition. REPORTS FINAL RESULTS 
// #####################################################################
	// =================================================
	typedef struct{
		int Nt;
		double tAVE;	// top monolayer height
		double tVAR;	// top monolayer variance
		double tSEM;	// top monolayer standard error of the mean	

		int Nm;
		double mAVE;	// middle monolayer height
		double mVAR;
		double mSEM;
		
		int Nd;
		double dAVE; 	// bottom monolayer height
		double dVAR; 
		double dSEM;
	     // This is the tickness: (not just t-m and b-m), mt=membrane tickness es abs(m1-m2) 
		double m1tickAVE;  // Top monolayer tickness
		double m1tickVAR;
		double m1tickSEM;

		double m2tickAVE;  // Bottom monolayer tickness
		double m2tickVAR;
		double m2tickSEM;

	     // Curvature variables
		double fx, fy;
		double fxx, fxy, fyy;
		double J, G;
		double c1, c2;

		double fx_t, fy_t;
		double fxx_t, fxy_t, fyy_t;
		double J_t, G_t;
		double c1_t, c2_t;
	
		double fx_d, fy_d;
		double fxx_d, fxy_d, fyy_d;
		double J_d, G_d;
		double c1_d, c2_d;

	     // Lipid type-A density
		int lAm1N;
		double lAm1AVE;
		double lAm1VAR;
		double lAm1SEM;

		int lAm2N;
		double lAm2AVE;
		double lAm2VAR;
		double lAm2SEM;

	} t_gpt; // Grid Point
	// =================================================
	typedef struct{
		int nframes;	// number of frames 
		int dimX0;
		int dimY0;
		double delta;
		t_gpt **gpt;
	} t_2Dgrid;

// #####################################################################
//
//	DENSITY MAP VARIABLES
//
// #####################################################################
	typedef struct {
		// Density Variables for ALL lipids defined
		int N;	 // How many times this val is used
		double sumRho;  // Sum of value
		double sumRho2; // Sum of value squared
		double distLP; // Lipid-Protein Distance

		// Same variables for Lipids group A only
		int NA;
		double sumRhoA;
		double sumRhoA2;
		double distLAP;
		// Proteins
		int NP;
		double sumRhoP;
		double sumRhoP2;
	} t_3Dgpt;

	typedef struct {
		int nframes;
		int dimX0;
		int dimY0;	
		int dimZ0;
		double delta;
		t_3Dgpt ***gpt;
	} t_3Dsums;

	// Small variable
	// ///////////////////////////
        typedef struct{
                int Nbdxcell;  // Count all Lipid types
		int NbdAxcell; // Only type A lipids
		int NbdPxcell; // Proteins
        } t_3Dsml;

	// AVERAGES
	// ///////////////////////////
	typedef struct {
		// All lipid Groups
		int N;  
		double rhoAVE;  
		double rhoVAR; 
		double rhoSEM;  
		double distLP;
		// Lipid Group 1
		int NA; 
		double rhoAAVE; 
		double rhoAVAR; 
		double rhoASEM; 
		double distLAP;
		// Protein
		int NP;
		double rhoPave;
		double rhoPvar;
	} t_stats3Dgpt;
	typedef struct {
		int nframes;
		int dimX0;
		int dimY0;
		int dimZ0;
		double delta;
		double rhoALL_ave, rhoALL_sigma, rhoALL_sem;
		double rhoALL_Aave, rhoALL_Asigma, rhoALL_Asem;
		double rhoALL_Pave, rhoALL_Psigma, rhoALL_Psem; 
		t_stats3Dgpt ***gpt; 
	} t_3Dstats;

// #####################################################################

const char *get_estr(int *ninp,t_inpfile **inp,const char *name,const char *def);

#define STYPE(name,var,def)  if ((tmp=get_estr(&ninp,&inp,name,def)) != NULL) strcpy(var,tmp)
#define ETYPE(name,var,defs) var=get_eenum(&ninp,&inp,name,defs)

#ifdef __cplusplus
extern "C" {
#endif

extern int *initvecint(int n);
extern int **mat_space_int(int m, int n);
extern char **mat_space_char(int m, int n);
extern char mat_free_char(char **a, int m);

//extern void get_inputs(char *mdparin, char *mdparout, t_gopts *gopts); 
#ifdef __cplusplus
}
#endif

#endif  /* _parser_h */


