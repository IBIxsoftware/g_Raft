/*
 *
 *      Parser for Graft input
 *
 */

#include <stdio.h>
#include <stdlib.h>

#include <stddef.h>
#include <ctype.h>
#include <string.h>
#include <math.h>

#include "parser.h"

double costeta(rvec *v1, rvec *v2);
double filter(int type, int w, int mu, double shift);

t_2Dgrid calc_GDstats(t_2Dsums *sumsGD,  t_memb *memb, t_ldat **ldat, t_pdat **pdat, t_atoms *atoms, rvec **x, t_gopts *opts, matrix box)
{
	t_2Dgrid memGD;
	t_2Dgrid memGDfit;	// Filtered version
        int j, k;
        int dimX0, dimY0;
        double delta;

	int   jp;	
	int jh, jt; // jhead, jtail counter	
	int slips;
	int Nlip;
	char *jlname, *atnam;
  
        int jresindx;
        char *jresnam, *janame;
	char *jresnamn;
	rvec x_j; 
	rvec vecB;
	double ctheta;
	int jnhats, jntats;
	int valhead, valtail;
	int jlip;

	rvec try;
	double boxX, boxY;
 
	int jtindx, jhindx;
	int gpx, gpy; double gpz;


	int w;		// width of filter
	int mu, nu; 	// Variables for filter function
	int jref, kref; // Reference indices that match filter to tmpGD
	double sumfZval_m, sumf_m; // Midplane sums factor*Zval and sum of factors
	int Xmax, Ymax;	
	int px, py;

	int Nt;
	double tsum, tsum2;
	double tave, tvar, tsem;
	int Nm; 
	double msum, msum2;
	double mave, mvar, msem; 
	int Nd;
	double dsum, dsum2;
	double dave, dvar, dsem;

	// For curvature
	// ==================
	int j1, j2;
	int k1, k2;
	int jm1, jm2;
	int km1, km2;
	double Zc, Zd;
	double Zb, Za;
	double Z0;
	 
	double h;
	double Kg, Km;
	double c1, c2;
	double discr;
 
	double fx, fy, fxx, fxy, fyy;

	//

        delta=opts->delta;

        dimX0=opts->dimX0;
        dimY0=opts->dimY0;

        memGD.dimX0=dimX0;
        memGD.dimY0=dimY0;

        printf("Creating a %d x %d grid for curvature calculations \n", dimX0, dimY0);

        memGD.gpt=(t_gpt **)calloc(dimX0, sizeof(t_gpt *));
        for(j=0;j<dimX0;j++) memGD.gpt[j]=(t_gpt *)calloc(dimY0,sizeof(t_gpt));

        printf("memGD.gpt Allocated \n");

        // =======================================
        memGD.dimX0=dimX0;
        memGD.dimY0=dimY0;
        memGD.delta=delta;
        for(j=0;j<dimX0;j++){
           for(k=0;k<dimY0;k++){
              // Top, Midplane, and Down plane
              // =========================================
                memGD.gpt[j][k].tAVE=0.0; 
		memGD.gpt[j][k].tVAR=0.0; 
		memGD.gpt[j][k].tSEM=0.0;

                memGD.gpt[j][k].mAVE=0.0; 
		memGD.gpt[j][k].mVAR=0.0; 
		memGD.gpt[j][k].mSEM=0.0;

                memGD.gpt[j][k].dAVE=0.0; 
		memGD.gpt[j][k].dVAR=0.0; 
		memGD.gpt[j][k].dSEM=0.0;
              // Lipid tickness monolayer1 and monolayer 2 
              // =========================================
                memGD.gpt[j][k].m1tickAVE=0.0; 
		memGD.gpt[j][k].m1tickVAR=0.0; 
		memGD.gpt[j][k].m1tickSEM=0.0;

                memGD.gpt[j][k].m2tickAVE=0.0; 
		memGD.gpt[j][k].m2tickVAR=0.0; 
		memGD.gpt[j][k].m2tickSEM=0.0;

	      // Partial Derivatives for curvature calculations
	      // =========================================
                memGD.gpt[j][k].fx=0.0; 
		memGD.gpt[j][k].fy=0.0; 
  
                memGD.gpt[j][k].fxx=0.0; 
		memGD.gpt[j][k].fxy=0.0; 
		memGD.gpt[j][k].fyy=0.0;

		// Partial derivatives and curvature midplane
                memGD.gpt[j][k].J=0.0; 
		memGD.gpt[j][k].G=0.0; 
                memGD.gpt[j][k].c1=0.0; 
		memGD.gpt[j][k].c2=0.0; 
  
		// Partial derivatives and curvature top
                memGD.gpt[j][k].J_t=0.0; 
		memGD.gpt[j][k].G_t=0.0; 
                memGD.gpt[j][k].c1_t=0.0; 
		memGD.gpt[j][k].c2_t=0.0; 

		// Partial derivatives and curvature down
                memGD.gpt[j][k].J_d=0.0; 
		memGD.gpt[j][k].G_d=0.0; 
                memGD.gpt[j][k].c1_d=0.0; 
		memGD.gpt[j][k].c2_d=0.0; 

	      // Density lipid type A
              // =========================================
                memGD.gpt[j][k].lAm1AVE=0.0; 
		memGD.gpt[j][k].lAm1VAR=0.0; 
		memGD.gpt[j][k].lAm1SEM=0.0;
                memGD.gpt[j][k].lAm2AVE=0.0; 
		memGD.gpt[j][k].lAm2VAR=0.0; 
		memGD.gpt[j][k].lAm2SEM=0.0;
              // =========================================       
                }
        }

 

	// ##############################################################
	//
	//	TEMPORARY GRID	
	//
	// ##############################################################
	dimX0=sumsGD->dimX0;
	dimY0=sumsGD->dimY0;

	slips = memb->slips;
	Nlip = opts->nltypes; // Number of types
	vecB[0]=0.0; 	vecB[1]=0.0;	vecB[2]=1.0;
	boxX=box[0][0];	boxY=box[1][1];


	// ##############################################################
	//
	// 	GET SURFACE FRAME
	//
	// ##############################################################
	

	Xmax=dimX0-1;  Ymax=dimY0-1;

	for(j=0; j<dimX0; j++){
	for(k=0; k<dimY0; k++){
		// Nottice I do not initialize the variable, I simple add to it.
		// ===========================
		// TOP PLANE SUMS 
		// ===========================  
		Nt=sumsGD->gpt[j][k].Nt;
		if(Nt>0){
			tsum=sumsGD->gpt[j][k].ts;
			tsum2=sumsGD->gpt[j][k].ts2;

			tave=tsum/((double) Nt);		
			tvar=(1/Nt)*(tsum2 - pow(tsum,2)/Nt);
			tsem=sqrtf(tvar/Nt);
//			printf("tsum = %f\n", tsum);
		} else {
			tave=0.0;
			tvar=0.0;
			tsem=0.0;
		};

		//printf("TOP %i %i %f \n", j, k, tave);

		memGD.gpt[j][k].tAVE=tave;
		memGD.gpt[j][k].tVAR=tvar;
		memGD.gpt[j][k].tSEM=tsem;

		// MIDPLANE SUMS 
		// ===========================  
		Nm=sumsGD->gpt[j][k].Nm;
		if(Nm>0){
			msum=sumsGD->gpt[j][k].ms;
			msum2=sumsGD->gpt[j][k].ms2;

			mave=msum/Nm;
			mvar=(1/Nm)*(msum2-pow(msum,2)/Nm);
			msem=sqrtf(mvar/Nm);
		} else {
			mave=0.0;
			mvar=0.0;
			msem=0.0;
		};
		//printf("MIDPLANE %i %i %f \n", j, k, mave);
		memGD.gpt[j][k].mAVE=mave;
		memGD.gpt[j][k].mVAR=mvar;
		memGD.gpt[j][k].mSEM=msem;

		// DOWN PLANE SUMS 
		// ===========================  
		Nd=sumsGD->gpt[j][k].Nd;
		if(Nd>0){
			dsum=sumsGD->gpt[j][k].ds ;
			dsum2=sumsGD->gpt[j][k].ds2;
		
			dave=dsum/Nd;
			dvar=(1/Nd)*(dsum2-pow(dsum,2)/Nd);
			dsem=sqrtf(dvar/Nd);
		} else {
			dave=0.0;
			dvar=0.0;		
		};
		//printf("DOWNPLANE %i %i %f \n", j, k, dave);
		memGD.gpt[j][k].dAVE=dave;
		memGD.gpt[j][k].dVAR=dvar;
		memGD.gpt[j][k].dSEM=dsem;
		// ===========================  
	}
	}


	// ##############################################################
	//
	//	TICKNESS CALCULATIONS
	//
	// ##############################################################
	int tickmethod;
	tickmethod=0;
	if (tickmethod==0){

		for(j=0; j<=Xmax; j++){
		for(k=0; k<=Ymax; k++){
			// Monolayer 1
			memGD.gpt[j][k].m1tickAVE=fabs(memGD.gpt[j][k].tAVE - memGD.gpt[j][k].mAVE);
			//printf("memGD->gpt[j][k].m1tickAVE = %f\n",memGD->gpt[j][k].m1tickAVE);
	
			// Monolayer 2
			memGD.gpt[j][k].m2tickAVE=fabs(memGD.gpt[j][k].mAVE - memGD.gpt[j][k].dAVE);
			
		}
		}
			
		
	} else {
			
		
	}


	// ##############################################################
	//
	//	C U R V A T U R E     C A L C U L A T I O N S 
	//
	// ##############################################################
	// https://en.wikipedia.org/wiki/Five-point_stencil
	// http://www.holoborodko.com/pavel/numerical-methods/numerical-derivative/central-differences/
	// http://www.mathworks.com/matlabcentral/fileexchange/11168-surface-curvature/content/surfature.m
	// http://www.mathematik.uni-dortmund.de/~kuzmin/cfdintro/lecture4.pdf

	int j0, k0;
	printf("EDUARDO: \ndimX0=%d, Xmax=%d\n",dimX0, Xmax);
        for(j=0; j<=Xmax; j++){
        for(k=0; k<=Ymax; k++){
		
	    jm2=j-2; if(jm2<0)  jm2=j-2+dimX0;   
	    jm1=j-1; if(jm1<0) jm1=j-1+dimX0; 
	    j0 = j;  if(j0<0) j0=j0-1+dimX0;
	             if(j0>Xmax) j0=j-dimX0;
	    j1 =j+1; if(j1>Xmax) j1=j+1-dimX0; 
	    j2 =j+2; if(j2>Xmax) j2=j+2-dimX0;	
    				
	    km2=k-2; if(km2<0) km2=k-2+dimY0;
	    km1=k-1; if(km1<0) km1=k-1+dimY0; 
	    k0 = k;  if(k0<0)  k0=k+dimY0;
		     if(k0>Ymax) k0=k-dimY0;
	    k1 =k+1; if(k1>Ymax) k1=k+1-dimY0; 
	    k2 =k+2; if(k2>Ymax) k2=k+2-dimY0;
	    


	    Za=memGD.gpt[jm2][k0].mAVE;
	    Zb=memGD.gpt[jm1][k0].mAVE;	
	    Z0=memGD.gpt[j0][k0].mAVE;
	    Zc=memGD.gpt[j1][k0].mAVE;
	    Zd=memGD.gpt[j2][k0].mAVE;	
	    fx = (Za-8.0*Zb+8.0*Zc-Zd)/(12.0*delta);	
  	    memGD.gpt[j][k].fx=fx;

	    Za=memGD.gpt[j0][km2].mAVE;
	    Zb=memGD.gpt[j0][km1].mAVE;	
	    Zc=memGD.gpt[j0][k1].mAVE;
	    Zd=memGD.gpt[j0][k2].mAVE;	

	    fy = (Za-8.0*Zb+8.0*Zc-Zd)/(12.0*delta);	 	   
	    memGD.gpt[j][k].fy=fy;
	   
  	    // Second Derivatives
	    // fxx
// 	    printf("Xmax=%i,(jm2=%i, jm1=%i, j=%i, j1=%i, j2=%i)\n", Xmax, jm2, jm1, j, j1, j2);

	    Za=memGD.gpt[jm2][k0].mAVE;
	    Zb=memGD.gpt[jm1][k0].mAVE;	
	    Z0=memGD.gpt[j0][k0].mAVE;
	    Zc=memGD.gpt[j1][k0].mAVE;
	    Zd=memGD.gpt[j2][k0].mAVE;	
	    fxx = (-Za+16.0*Zb-30.0*Z0+16.0*Zc-Zd)/(12.0*delta*delta);	 
	    memGD.gpt[j][k].fxx = fxx;
			
	    // fyy
//	    printf("Xmax=%i,(km2=%i, km1=%i, j=%i, k1=%i, k2=%i)\n", Ymax, km2, km1, k, k1, k2);

	    Za=memGD.gpt[j0][km2].mAVE;
	    Zb=memGD.gpt[j0][km1].mAVE;	
	    Z0=memGD.gpt[j0][k0].mAVE;
	    Zc=memGD.gpt[j0][k1].mAVE;
	    Zd=memGD.gpt[j0][k2].mAVE;	

	    fyy = (-Za+16.0*Zb-30.0*Z0+16.0*Zc-Zd)/(12.0*delta*delta);	 
	    memGD.gpt[j][k].fyy = fyy; 
 
	    // fxy
	    Za=memGD.gpt[jm1][km1].mAVE;
	    Zb=memGD.gpt[j1][k1].mAVE;	
	    Zc=memGD.gpt[j1][km1].mAVE;
	    Zd=memGD.gpt[jm1][k].mAVE;		    
	    fxy = (Za+Zb-Zc-Zd)/(4.0*delta*delta);
	    memGD.gpt[j][k].fxy = fxy;
	
	    // DEFINE CURVATURES
	    discr = sqrtf(fx*fx+fy*fy+1.0);
	    Kg=(fxx*fyy-fxy*fxy)/(pow(discr,4.0));	             
	    Km=((1.0+fx*fx)*fyy - 2.0*fx*fy*fxy + (1.0+fy*fy)*fxx)/(2.0*pow(discr,3.0));

	 //   printf("fx=%f, fy=%f, fxx=%f, fxy=%f, fyy=%f, discr=%f\n",fx, fy, fxx, fxy, fyy, discr);	
	 //   printf("Kg=%f, Km=%f, c1=%f, c2=%f\n",Kg, Km, c1, c2);		
	    // DEFINE c1, c2
	    c1= Km + sqrtf(Km*Km-Kg);
	    c2=	Km - sqrtf(Km*Km-Kg);

	    // COMMIT TO ARRAY	
	    memGD.gpt[j0][k0].J=Km;
	    memGD.gpt[j0][k0].G=Kg;

	    memGD.gpt[j0][k0].c1=c1;
	    memGD.gpt[j0][k0].c2=c2;
 
	}
	}

	// ##############################################################
	// 	CURVATURE TOP
	// ##############################################################
	 
        for(j=0; j<=Xmax; j++){
        for(k=0; k<=Ymax; k++){
		
	    jm2=j-2; if(jm2<0)  jm2=j-2+dimX0;   
	    jm1=j-1; if(jm1<0) jm1=j-1+dimX0; 
	    j1 =j+1; if(j1>Xmax) j1=j+1-dimX0; 
	    j2 =j+2; if(j2>Xmax) j2=j+2-dimX0;	
    				
	    km2=k-2; if(km2<0) km2=k-2+dimY0;
	    km1=k-1; if(km1<0) km1=k-1+dimY0; 
	    k1 =k+1; if(k1>Ymax) k1=k+1-dimY0; 
	    k2 =k+2; if(k2>Ymax) k2=k+2-dimY0;
	 

	    Za=memGD.gpt[jm2][k].tAVE;
	    Zb=memGD.gpt[jm1][k].tAVE;	
	    Z0=memGD.gpt[j][k].tAVE;
	    Zc=memGD.gpt[j1][k].tAVE;
	    Zd=memGD.gpt[j2][k].tAVE;	
	    fx = (Za-8.0*Zb+8.0*Zc-Zd)/(12.0*delta);	
  
	    Za=memGD.gpt[j][km2].tAVE;
	    Zb=memGD.gpt[j][km1].tAVE;	
	    Zc=memGD.gpt[j][k1].tAVE;
	    Zd=memGD.gpt[j][k2].tAVE;	

	    fy = (Za-8.0*Zb+8.0*Zc-Zd)/(12.0*delta);	 
	   
  	    // Second Derivatives
	    // fxx
	    Za=memGD.gpt[jm2][k].tAVE;
	    Zb=memGD.gpt[jm1][k].tAVE;	
	    Z0=memGD.gpt[j][k].tAVE;
	    Zc=memGD.gpt[j1][k].tAVE;
	    Zd=memGD.gpt[j2][k].tAVE;	
	    fxx = (-Za+16.0*Zb-30.0*Z0+16.0*Zc-Zd)/(12.0*delta*delta);	 
	    //memGD.gpt[j][k].fxx = fxx;
			
	    // fyy
 	    //printf("Xmax=%i,(km2=%i, km1=%i, j=%i, k1=%i, k2=%i)\n", Ymax, km2, km1, k, k1, k2);
	    Za=memGD.gpt[j][km2].tAVE;
	    Zb=memGD.gpt[j][km1].tAVE;	
	    Z0=memGD.gpt[j][k].tAVE;
	    Zc=memGD.gpt[j][k1].tAVE;
	    Zd=memGD.gpt[j][k2].tAVE;	

	    fyy = (-Za+16.0*Zb-30.0*Z0+16.0*Zc-Zd)/(12.0*delta*delta);	 
	    //memGD.gpt[j][k].fyy = fyy; 
 
	    // fxy
	    Za=memGD.gpt[jm1][km1].tAVE;
	    Zb=memGD.gpt[j1][k1].tAVE;	
	    Zc=memGD.gpt[j1][km1].tAVE;
	    Zd=memGD.gpt[jm1][k].tAVE;		    
	    fxy = (Za+Zb-Zc-Zd)/(4*delta*delta);
	   // memGD.gpt[j][k].fxy = fxy;
	
	    // DEFINE CURVATURES
	    discr = sqrtf(fx*fx +fy*fy +1.0);
	    Kg=(fxx*fyy -fxy*fxy)/(pow(discr,4.0));	             
	    Km=((1.0 +fx*fx)*fyy - 2.0*fx*fy*fxy + (1.0 +fy*fy)*fxx)/(2.0*pow(discr,3.0));
 		
	    // DEFINE c1, c2
	    c1= Km + sqrtf(Km*Km-Kg);
	    c2=	Km - sqrtf(Km*Km-Kg);

	    // COMMIT TO ARRAY	
	    memGD.gpt[j][k].J_t=Km;
	    memGD.gpt[j][k].G_t=Kg;

	    memGD.gpt[j][k].c1_t=c1;
	    memGD.gpt[j][k].c2_t=c2;
 
	 }
	 }

	// ##############################################################
	// 	CURVATURE DOWN
	// ##############################################################
 
        for(j=0; j<=Xmax; j++){
        for(k=0; k<=Ymax; k++){
		   
	    // FIRST PARTIAL DERIVATIVES

	    jm2=j-2; if(jm2<0) jm2=j-2+dimX0; 
	    jm1=j-1; if(jm1<0) jm1=j-1+dimX0; 
	    j1 =j+1; if(j1>Xmax) j1=j+1-dimX0; 
	    j2 =j+2; if(j2>Xmax) j2=j+2-dimX0;	
    				
	    km2=k-2; if(km2<0) km2=k-2+dimY0;
	    km1=k-1; if(km1<0) km1=k-1+dimY0; 
	    k1 =k+1; if(k1>Ymax) k1=k+1-dimY0; 
	    k2 =k+2; if(k2>Ymax) k2=k+2-dimY0;
 

	    Za=memGD.gpt[jm2][k].dAVE;
	    Zb=memGD.gpt[jm1][k].dAVE;	
	    Z0=memGD.gpt[j][k].dAVE;
	    Zc=memGD.gpt[j1][k].dAVE;
	    Zd=memGD.gpt[j2][k].dAVE;	
	    fx = (Za-8.0*Zb+8.0*Zc-Zd)/(12.0*delta);	
  
	    Za=memGD.gpt[j][km2].dAVE;
	    Zb=memGD.gpt[j][km1].dAVE;	
	    Zc=memGD.gpt[j][k1].dAVE;
	    Zd=memGD.gpt[j][k2].dAVE;	

	    fy = (Za-8.0*Zb+8.0*Zc-Zd)/(12.0*delta);	 

//
  	    // Second Derivatives
	    // fxx
	    Za=memGD.gpt[jm2][k].dAVE;
	    Zb=memGD.gpt[jm1][k].dAVE;	
	    Z0=memGD.gpt[j][k].dAVE;
	    Zc=memGD.gpt[j1][k].dAVE;
	    Zd=memGD.gpt[j2][k].dAVE;	
	    fxx = (-Za+16.0*Zb-30.0*Z0+16.0*Zc-Zd)/(12.0*delta*delta);	 
	    //memGD.gpt[j][k].fxx = fxx;
			
	    // fyy
//	    printf("Xmax=%i,(km2=%i, km1=%i, j=%i, k1=%i, k2=%i)\n", Ymax, km2, km1, k, k1, k2);

	    Za=memGD.gpt[j][km2].dAVE;
	    Zb=memGD.gpt[j][km1].dAVE;	
	    Z0=memGD.gpt[j][k].dAVE;
	    Zc=memGD.gpt[j][k1].dAVE;
	    Zd=memGD.gpt[j][k2].dAVE;	

	    fyy = (-Za+16.0*Zb-30.0*Z0+16.0*Zc-Zd)/(12.0*delta*delta);	 
	    //memGD.gpt[j][k].fyy = fyy; 
 
	    // fxy
	    Za=memGD.gpt[jm1][km1].dAVE;
	    Zb=memGD.gpt[j1][k1].dAVE;	
	    Zc=memGD.gpt[j1][km1].dAVE;
	    Zd=memGD.gpt[jm1][k].dAVE;		    
	    fxy = (Za+Zb-Zc-Zd)/(4.0*delta*delta);
	   // memGD.gpt[j][k].fxy = fxy;
	
	    // DEFINE CURVATURES
	    discr = sqrtf(fx*fx+fy*fy+1.0);
	    Kg=(fxx*fyy-fxy*fxy)/(pow(discr,4.0));	             
	    Km=((1.0+fx*fx)*fyy - 2.0*fx*fy*fxy + (1.0+fy*fy)*fxx)/(2.0*pow(discr,3.0));
 		
	    // DEFINE c1, c2
	    c1= Km + sqrtf(Km*Km-Kg);
	    c2=	Km - sqrtf(Km*Km-Kg);

	    // COMMIT TO ARRAY	
	    memGD.gpt[j][k].J_d=Km;
	    memGD.gpt[j][k].G_d=Kg;

	    memGD.gpt[j][k].c1_d=c1;
	    memGD.gpt[j][k].c2_d=c2;
 
	}
	}


        // ##############################################################
        //
        // AVERAGE LIPID TYPE-1 OCCUPANCY (Lipids per area)
        //
        // ##############################################################
	double area;
	double totalup, totaldown;
	totalup=0;
	totaldown=0;

	area = delta*delta;	

	totalup=0.0;
	totaldown=0.0;
	tsum =0.0;
	tsum2=0.0;
	dsum =0.0;
	dsum2=0.0;

	Xmax=dimX0-1;  Ymax=dimY0-1;
        for(j=0; j<=Xmax; j++){
        for(k=0; k<=Ymax; k++){
                // ===========================
                // TOP PLANE SUMS 
                // ===========================  
		tave=0.0;
		tvar=0.0;
		tsem=0.0;                
                if(sumsGD->gpt[j][k].st_Alip >0.0){
                        tsum=sumsGD->gpt[j][k].st_Alip;
                        tsum2=sumsGD->gpt[j][k].st2_Alip;
			Nt=sumsGD->nframes;

                        tave=tsum/((double) Nt);
                        tvar=(1/(double) Nt)*(tsum2 - pow(tsum,2)/(double) Nt);
                        tsem=sqrtf(tvar/(double) Nt);
                        //printf("=============================>>>>>>> TOP tsum = %f tave=%f\n", tsum, tave);
 
			//printf("TOP %i %i %f %f\n", j, k, tave, area);
			totalup += tsum;

			memGD.gpt[j][k].lAm1AVE=tave/area;
			memGD.gpt[j][k].lAm1VAR=tvar/area;
			memGD.gpt[j][k].lAm1SEM=tsem/area;
			//printf("totalup = %f \n", totalup);
			//printf("EDUARDO %f %f %f \n", tave, tvar, tsem);
			 
		};
	
		// DOWN PLANE SUMS 
		// ===========================  
                
       		dave=0.0;
		dvar=0.0;
		dsem=0.0;
		
                if(sumsGD->gpt[j][k].sd_Alip>0.0){
                        dsum=sumsGD->gpt[j][k].sd_Alip;
                        dsum2=sumsGD->gpt[j][k].sd2_Alip;
			Nd=sumsGD->nframes;

                        dave=dsum/((double) Nd);
                        dvar=(1/(double) Nd)*(dsum2 - pow(dsum,2)/(double) Nd);
                        dsem=sqrtf(dvar/(double) Nd);
                        //printf("=============================>>>>>>> DOWN tsum = %f\n", dave);
                	
			totaldown += dsum;
			//if(dave>0.0) printf("DOWN %i %i %f %f\n", j, k, dave, area);

			memGD.gpt[j][k].lAm2AVE=dave/area;
			memGD.gpt[j][k].lAm2VAR=dvar/area;
			memGD.gpt[j][k].lAm2SEM=dsem/area;
		 	//printf("EDUARDO %f %f %f \n", dave, dvar, dsem);
		//if(tave > 0.0 ) printf("ALELUYA %f \n", &memGD.gpt[j][k].m2lA_AVE );
		};
	}
	}
	
 

	// ##############################################################
	//
	//	FILTERING MADE AT THE END OF THE STATS FOR MOLECULE 
	//
	// ##############################################################
	double sumFA_m1, sumFV_m1, sumFS_m1;

	double sumF_m1;
	double sumFA_m2, sumFV_m2, sumFS_m2;
	double sumF_m2;
	int dimXmax, dimYmax;
	double fval;
	int ftype;
	double shift;

        memGDfit.gpt=(t_gpt **)calloc(dimX0, sizeof(t_gpt *));
        for(j=0;j<dimX0;j++) memGDfit.gpt[j]=(t_gpt *)calloc(dimY0,sizeof(t_gpt));

        printf("memGDfit.gpt Allocated \n");

        // =======================================
        memGDfit.dimX0=dimX0;
        memGDfit.dimY0=dimY0;
        memGDfit.delta=delta;
        for(j=0;j<dimX0;j++){
           for(k=0;k<dimY0;k++){
              // Top, Midplane, and Down plane
              // =========================================
                 memGDfit.gpt[j][k].tAVE=memGD.gpt[j][k].tAVE; 
		 memGDfit.gpt[j][k].tVAR=memGD.gpt[j][k].tVAR; 
		 memGDfit.gpt[j][k].tSEM=memGD.gpt[j][k].tSEM;
                 memGDfit.gpt[j][k].mAVE=memGD.gpt[j][k].mAVE; 
		 memGDfit.gpt[j][k].mVAR=memGD.gpt[j][k].mVAR; 
		 memGDfit.gpt[j][k].mSEM=memGD.gpt[j][k].mSEM;
                 memGDfit.gpt[j][k].dAVE=memGD.gpt[j][k].dAVE; 
		 memGDfit.gpt[j][k].dVAR=memGD.gpt[j][k].dVAR; 
		 memGDfit.gpt[j][k].dSEM=memGD.gpt[j][k].dSEM;

	      // Curvature
	      // =========================================
		 memGDfit.gpt[j][k].J=memGD.gpt[j][k].J;
		 memGDfit.gpt[j][k].G=memGD.gpt[j][k].G;
		 memGDfit.gpt[j][k].c1=memGD.gpt[j][k].c1;
		 memGDfit.gpt[j][k].c2=memGD.gpt[j][k].c2;

		 memGDfit.gpt[j][k].J_t=memGD.gpt[j][k].J_t;
		 memGDfit.gpt[j][k].G_t=memGD.gpt[j][k].G_t;
		 memGDfit.gpt[j][k].c1_t=memGD.gpt[j][k].c1_t;
		 memGDfit.gpt[j][k].c2_t=memGD.gpt[j][k].c2_t;

		 memGDfit.gpt[j][k].J_d=memGD.gpt[j][k].J_d;
		 memGDfit.gpt[j][k].G_d=memGD.gpt[j][k].G_d;
		 memGDfit.gpt[j][k].c1_d=memGD.gpt[j][k].c1_d;
		 memGDfit.gpt[j][k].c2_d=memGD.gpt[j][k].c2_d;

              // Lipid tickness monolayer1 and monolayer 2 
              // =========================================
                 memGDfit.gpt[j][k].m1tickAVE=memGD.gpt[j][k].m1tickAVE; 
		 memGDfit.gpt[j][k].m1tickVAR=memGD.gpt[j][k].m1tickVAR; 
		 memGDfit.gpt[j][k].m1tickSEM=memGD.gpt[j][k].m1tickSEM;

                 memGDfit.gpt[j][k].m2tickAVE=memGD.gpt[j][k].m2tickAVE; 
		 memGDfit.gpt[j][k].m2tickVAR=memGD.gpt[j][k].m2tickVAR; 
		 memGDfit.gpt[j][k].m2tickSEM=memGD.gpt[j][k].m2tickSEM;
                }
        }

 	w=opts->fw3D;
	printf("fw3D=%d\n",w);
	ftype=opts->fty;
	shift=opts->ftyshift;

	dimXmax=dimX0-1;  dimYmax=dimY0-1;	

        for(j=0;j<dimX0;j++){
           for(k=0;k<dimY0;k++){
             // Density lipid type A
             // =========================================
		 // Top leaflet 
                 memGDfit.gpt[j][k].lAm1AVE=0.0; 
		 memGDfit.gpt[j][k].lAm1VAR=0.0; 
		 memGDfit.gpt[j][k].lAm1SEM=0.0;
		 // Bottom 
                 memGDfit.gpt[j][k].lAm2AVE=0.0; 
		 memGDfit.gpt[j][k].lAm2VAR=0.0; 
		 memGDfit.gpt[j][k].lAm2SEM=0.0;
              // =========================================  
 		sumFA_m1=0.0; sumFV_m1=0.0; sumFS_m1=0.0; 
		sumF_m1=0.0;
		sumFA_m2=0.0; sumFV_m2=0.0; sumFS_m2=0.0; 
		sumF_m2=0.0;

		//printf("EDUARDO dimXmax=%d, Ymax=%d \n", j, k);
		for(mu=0; mu<=2*w; mu++){	
		for(nu=0; nu<=2*w; nu++){

			jref = j + mu - w; 
			if(jref<0) jref=jref+dimXmax;
			if(jref>dimXmax) jref=jref-dimXmax;

			kref = k + nu - w;
			if(kref<0) kref=kref+dimYmax;
			if(kref>dimYmax) kref=kref-dimYmax;

			// Value of filter function at kref, jref:	 		
			fval = filter(ftype,w,mu,shift)*filter(ftype,w,nu,shift);

			//if(memGD.gpt[jref][kref].lAm1AVE>0.0){
			sumFA_m1 = sumFA_m1 + fval*memGD.gpt[jref][kref].lAm1AVE;
			sumFV_m1 = sumFV_m1 + fval*memGD.gpt[jref][kref].lAm1VAR;
			sumFS_m1 = sumFS_m1 + fval*memGD.gpt[jref][kref].lAm1SEM;
			sumF_m1 = sumF_m1 + fval;
			//}

			//if(memGD.gpt[jref][kref].lAm2AVE>0.0){
			sumFA_m2 = sumFA_m2 + fval*memGD.gpt[jref][kref].lAm2AVE;
			sumFV_m2 = sumFV_m2 + fval*memGD.gpt[jref][kref].lAm2VAR;
			sumFS_m2 = sumFS_m2 + fval*memGD.gpt[jref][kref].lAm2SEM;
			sumF_m2 = sumF_m2 + fval;
			//}

		}
		}

	      // Commit Points
              // =========================================  
		// Top leaflet 
		if(sumF_m1>0.0){
                  memGDfit.gpt[j][k].lAm1AVE=sumFA_m1/sumF_m1; 
		  memGDfit.gpt[j][k].lAm1VAR=sumFV_m1/sumF_m1; 
		  memGDfit.gpt[j][k].lAm1SEM=sumFS_m1/sumF_m1;
		  //printf("CHECK %f %f \n", memGDfit.gpt[j][k].lAm1AVE, memGDfit.gpt[j][k].lAm1VAR);
		} else {
		  memGDfit.gpt[j][k].lAm1AVE=0.0;
		  memGDfit.gpt[j][k].lAm1VAR=0.0;
		  memGDfit.gpt[j][k].lAm1SEM=0.0;
		}
		// Bottom 
		if(sumF_m2>0.0){
                  memGDfit.gpt[j][k].lAm2AVE=sumFA_m2/sumF_m2; 
		  memGDfit.gpt[j][k].lAm2VAR=sumFV_m2/sumF_m2; 
		  memGDfit.gpt[j][k].lAm2SEM=sumFS_m2/sumF_m2;     		
	     	} else {
		  memGDfit.gpt[j][k].lAm2AVE=0.0;
		  memGDfit.gpt[j][k].lAm2VAR=0.0;
		  memGDfit.gpt[j][k].lAm2SEM=0.0;
		}
           }
        }

	// ############################################################## 
	//
	// 	RE-SCALING OPTION
	//
	// ##############################################################

	totalup = totalup/((double) (sumsGD->nframes));
	totalup = totalup/((double) (Xmax+1)*(Ymax+1));
	totaldown=totaldown/((double) (sumsGD->nframes));
	totaldown=totaldown/((double) (Xmax+1)*(Ymax+1));
	totalup /= area;
	totaldown /=area;

	printf("Average Total lipids up %f \n", totalup);
	printf("Average Total lipids down %f \n", totaldown);

	if(opts->enrich ==1){
         for(j=0; j<=Xmax; j++){
           for(k=0; k<=Ymax; k++){
		memGDfit.gpt[j][k].lAm1AVE =  100.0*(memGDfit.gpt[j][k].lAm1AVE/totalup -1.0);  
		memGDfit.gpt[j][k].lAm2AVE  = 100.0*(memGDfit.gpt[j][k].lAm2AVE/totaldown -1.0); 
	   }
	 }
	}
	printf("======> enrich = %i \n", opts->enrich);
	// ##############################################################
	printf("\n");
	return memGDfit;
 
}
