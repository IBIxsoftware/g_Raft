/*
 *
 *      Parser for Graft input
 *
 */

#include <stdio.h>
#include <stdlib.h>

#include <stddef.h>
#include <ctype.h>
#include <string.h>

#include "parser.h"
#include "readinp.h"

#define arr_size 250 
#define smallsize 20
#define MAXLIP 65 
#define CHAINATS 60

// ##################################################################
//
//   	L I P I D S
// 
// ##################################################################

t_ldat *get_ldat(const char *mdparin, const char *mdparout, t_gopts *gopts){

	t_ldat *ldat;

        int nlgrps;
        int nlips;
        char lnames[MAXLIP*3][6];
        char *lnums;
        int *nltails;
        int sumlips;
        int sumchains;
        int kk=0;
        int lip;
        int lg;
        char linein[ arr_size ];
        char gname[80]="";
        char tmp10b[80];
	char oneword[40];
        char *words[40];
	int j, k, nu, maxi, sumvs, lt;
        int nelem, nats;
	int nexcl, sumtr, sumats;
	int sumSup, sumSdown;
	int sumcount;
        char *keyword;
	char lnam[10]="";
	char llegend[10]="";
        char vnames[CHAINATS][6];
        char anames[CHAINATS][6];

        FILE *datain = fopen ( mdparin, "r" );
        FILE *dataout = fopen ( mdparout, "a+" );
        FILE *parmin = fopen("LIPIDS.lib","r");

	const char *grpfile;
	FILE *datagrp; 
	char *lipidin;
	int ch;
	// ##############################################################################
        fprintf(dataout,"\n; LIPID GROUPS INFORMATION  \n");
        fprintf(dataout,"; ========================================== \n");
// Number of groups
        rewind(datain);
        keyword="l-ngrps";
	fprintf(dataout,"%s = ",keyword);
	nlgrps=2; // Default
        while ( (fgets ( linein, sizeof linein, datain ) != NULL) | nelem>-1)
        {
           if( strlen(linein)>3){
                nelem=scantext(linein,keyword,words);
                if(nelem>0 & strcmp(keyword,words[0])==0){
                    if(atoi(words[1])>0){
                        nlgrps=atoi(words[1]);
                    } else {
                        nlgrps=2;
                        printf(" number of lipid groups set to default 2 \n");
                    };
                };
            };
        };
	gopts->nlgp = nlgrps;
	fprintf(dataout,"%i ", nlgrps);
        fprintf(dataout,"    	; number of lipid groups, Default=2 \n");
 
	// ##############################################################################
	// 
	// 	FIND NUMBER OF LIPIDS
	//
	sumlips=0;
	int nelemlip;
 
	for (lg=0;lg<nlgrps;lg++){	
		maxi=-2;
		nextvar:
		rewind(datain);
		strcpy(gname,"l-grp"); sprintf(tmp10b, "%d", lg+1); strcat(gname,tmp10b); 
		printf("\nParsing lipid group: %s \n", gname);
		nlips=1; 
		while ( (fgets ( linein, sizeof linein, datain ) != NULL) | nelem>-1)
		{
		    if( strlen(linein)>2){
			nelem=scantext(linein,gname,words);
			if(nelem>0 && strcmp(gname,words[0])==0 && strcmp(words[1],"file")!=0){			  
				// printf("ESTAS AQUI \n");
				nelemlip=0;
				     for(j=1;j<nelem;j++){
					//printf("MACHO %s %d\n",words[j], strlen(words[j]));	
					nelemlip++;
			 	     }
			 
				 //printf("NUMELEM read from mdp %d %d \n", nelemlip, nelem-1);
				 sumlips=sumlips+(nelem-1);
			} 
				 
			 
			if(nelem>0 & strcmp(gname,words[0])==0 & strcmp(words[1],"file")==0){  	
			    //if(strcmp(words[1],"file")==0){
				// Read from file
				//printf("ESTAS EN LEER DE FILE\n");
				grpfile=strcat(gname,".dat");
				datagrp=fopen(grpfile, "r" );
					nelemlip=0;
					do {
					ch=fgetc(datagrp);
					if(ch == '\n') nelemlip++;
					} while (ch != EOF);
					//printf("NUMELEM read from file %d \n", nelemlip);
 					sumlips=sumlips+nelemlip;
				fclose(datagrp);
	
			        maxi=max(maxi,nelem);
			     
			}
		    
		    }   
		}
		   
	}
	printf("NUMBER OF LIPIDS DEFINED %d \n",sumlips);

	// ALLOCATION
	gopts->nltypes = sumlips;
	ldat = malloc(sumlips*sizeof(t_ldat));


	/////////////////////////////////////////////////////////////////////////////////// 
	//
	//			READ LABEL DATA FOR ALL LIPIDS
	//
	///////////////////////////////////////////////////////////////////////////////////
	sumlips=0;
	int jk;
	jk=0; 
	int cnttrash;
 	for (lg=0;lg<nlgrps;lg++){	
		maxi=-2;
		 
		rewind(datain);
		strcpy(gname,"l-grp"); sprintf(tmp10b, "%d", lg+1); strcat(gname,tmp10b); 
		printf("\nParsing lipid group: %s \n", gname);
		nlips=1; 
		while ( (fgets ( linein, sizeof linein, datain ) != NULL) | nelem>-1)
		{
		    if( strlen(linein)>2){
			nelem=scantext(linein,gname,words);
			if(nelem>0 && strcmp(gname,words[0])==0 && strcmp(words[1],"file")!=0){			  
				// printf("ESTAS AQUI \n");
				nelemlip=0;
				     for(j=1;j<nelem;j++){
					//printf("MACHO %s %d\n",words[j], strlen(words[j]));	
					nelemlip++;
					 
					//printf("COMMIT LIPID %d %s\n", jk+1, words[j]);
					strcpy(lnames[jk],words[j]);
					strcpy(ldat[jk].lname,lnames[jk]);
					gid[jk]=lg+1;
					jk++;	
			 	     }
			 
				 //printf("NUMELEM read from mdp %d %d \n", nelemlip, nelem-1);
				 sumlips=sumlips+(nelem-1);
			} 
				 
			 
			if(nelem>0 & strcmp(gname,words[0])==0 & strcmp(words[1],"file")==0){  	
			    //if(strcmp(words[1],"file")==0){
				// Read from file
				//printf("ESTAS EN LEER DE FILE\n");
				grpfile=strcat(gname,".dat");
				datagrp=fopen(grpfile, "r" );
					nelemlip=0;
					do {
					   ch=fgetc(datagrp);
					   if(ch == '\n') nelemlip++;
					} while (ch != EOF);
					printf("NUMELEM read from file %d \n", nelemlip);
					rewind(datagrp);
					for(j=1;j<nelemlip+1;j++){
						
					     fgets(tmp10b, sizeof tmp10b, datagrp);
						cnttrash=scanline(tmp10b,words);
					     //printf("COMMIT LIPIDf %d %d %s\n", jk+1, strlen(words[0]), words[0]);
						strcpy(lnames[jk],words[0]);
						strcpy(ldat[jk].lname,lnames[jk]);
						gid[jk]=lg+1;
					    jk++;	
					}
 					sumlips=sumlips+nelemlip;
				fclose(datagrp);
	
			        maxi=max(maxi,nelem);
			     
			}
		    
		    }   
		}
		   
	}
	printf("NUMBER OF LIPIDS REDEFINED %d \n",sumlips);

//	check, print lipid names
	printf("Lipids\n");
	for (lip=0;lip<sumlips;lip++){
		ldat[lip].natxl=0;
	    printf("%s ",lnames[lip]);
	}; printf("\n");
 
        for(j=0;j<sumlips;j++){
		//ldat[j].lname=malloc(5*sizeof(char));
		//strcpy(ldat[j].lname,lnames[j]);
		// INITIALIZE
		//printf("sumlips = %d ",sumlips);
		//printf("lyptys %d %s \n", j, ldat[j].lname);
		ldat[j].gid=gid[j];
		printf("Lipid %d Group %d Name %s \n", j+1, ldat[j].gid, ldat[j].lname);

        }
 
//	##############################################################################

        printf("\n");
        printf("; Individual Lipid Information, definitions from library file LIPIDS.lib\n");
        fprintf(dataout,"\n");
        for (lip=0;lip<sumlips;lip++){

        	printf("\n");
        	//printf("; Individual Lipid Information\n");
        	fprintf(dataout,"\n");
        	printf("\n; Lipid %i (%s) \n", lip+1, lnames[lip]);
        	printf("; ------------------------------------------:) \n");
        	fprintf(dataout,"\n; Lipid %i (%s) \n", lip+1, lnames[lip]);
        	fprintf(dataout,"; ------------------------------------------ \n");
        	//printf("; Processing Lipid %i \n", lip+1);

// BEGIN SURF
		if(gopts->cur > 0){

		//printf("Get surface bead information \n");
		//fprintf(dataout,"; surface particles \n");
	
		// ====================================================================================
		// Sup
		// ====================================================================================
		sumSup=0;
		kk=0; nelem=3; maxi=-2;
		//rewind(datain);
		rewind(parmin);
		// Word to parse
		//strcpy(gname,"l"); sprintf(tmp10b, "%d", lip+1); strcat(gname,tmp10b);
		strcpy(gname,""); sprintf(tmp10b, "%s", lnames[lip]); strcat(gname,tmp10b);
		strcpy(tmp10b,"_Ltop"); strcat(gname,tmp10b);
		printf("Parsing: %s, ", gname);
		fprintf(dataout,"%s = ",gname);
		nats=1;	
		while ( (fgets ( linein, sizeof linein, parmin ) != NULL) | nelem>-1)
		{
			if( strlen(linein)>3){
                                        nelem=scantext(linein,gname,words);
                                        if(nelem>0 & strcmp(gname,words[0])==0){
                                                for(j=1;j<nelem;j++){
                                                        strcpy(vnames[kk],words[j]);
                                                        kk++;
                                                };
                                        };
                                        maxi=max(maxi,nelem);

                                };
		}
		if (maxi-1<=0 ){
                        printf("No lipids specified, variable %s needs to be set on file %s \n", gname, mdparin);
                        exit(3);
                        };
                sumSup = sumSup + (maxi-1);

                ldat[lip].nsup=sumSup;
                ldat[lip].lsup=calloc(sumSup,sizeof(int));
                printf(" %d Ltop particle(s) {", sumSup);
                for (k=0;k<sumSup;k++){
                    printf(" %s ", vnames[k]);
                    fprintf(dataout," %s ",vnames[k]);
                    ldat[lip].lsup[k]=atoi(vnames[k]);
                 };
                 printf("}, \n");
                 fprintf(dataout,"\n");
	
		// ===============================================================================
		// Sdown
		// ===============================================================================
                sumSdown=0;
                kk=0; nelem=3; maxi=-2;
                rewind(parmin);
                // Word to parse
                //strcpy(gname,"l"); sprintf(tmp10b, "%d", lip+1); strcat(gname,tmp10b);
		strcpy(gname,""); sprintf(tmp10b, "%s", lnames[lip]); strcat(gname,tmp10b);
                strcpy(tmp10b,"_Ldown"); strcat(gname,tmp10b);
                printf("Parsing: %s, ", gname);
                fprintf(dataout,"%s = ",gname);
                nats=1;
                while ( (fgets ( linein, sizeof linein, parmin ) != NULL) | nelem>-1)
                {
                        if( strlen(linein)>3){
                                        nelem=scantext(linein,gname,words);
                                        if(nelem>0 & strcmp(gname,words[0])==0){
                                                for(j=1;j<nelem;j++){
                                                        strcpy(vnames[kk],words[j]);
                                                        kk++;
                                                };
                                        };
                                        maxi=max(maxi,nelem);

                                };
                }
                if (maxi-1<=0 ){
                        printf("No lipids specified, variable %s needs to be set on file %s \n", gname, mdparin);
                        exit(3);
                        };
		sumSdown = sumSdown + (maxi-1);
		ldat[lip].nsdown=sumSdown;
                ldat[lip].lsdown=calloc(sumSdown,sizeof(int));
                printf(" %d Ldown particle(s) {", sumSdown);
                for (k=0;k<sumSdown;k++){
                    printf(" %s ", vnames[k]);
                    fprintf(dataout," %s ",vnames[k]);
                    ldat[lip].lsdown[k]=atoi(vnames[k]);
                 };
                 printf("}, \n");
                 fprintf(dataout,"\n");

	}

// END SURF
//	##############################################################################

//  INDIVIDUAL LIPID INFORMATION

	        // ========================================
	        // VERTEX-ATOM NUMBERS (FOR CURVATURE CALCS)
	                // lip+1 index for lipid number
 		// =====================================================
/*
	                //printf("; B Processing Lipid %i \n", lip+1);
			fprintf(dataout,"; V-site beads \n");
	        	// Loop to scan all lipid groups
	        	sumvs=0; 
	        	kk=0;      
	        	nelem=3;
	                maxi=-2;
	                rewind(parmin);
			
	                //strcpy(gname,"l"); sprintf(tmp10b, "%d", lip+1); strcat(gname,tmp10b); 
			strcpy(gname,""); sprintf(tmp10b, "%s", lnames[lip]); strcat(gname,tmp10b);
			strcpy(tmp10b,"_Vnum"); strcat(gname,tmp10b);
                	printf("Parsing: %s, ", gname);
                	fprintf(dataout,"%s = ",gname);
		
                	nats=1; 
                	while ( (fgets ( linein, sizeof linein, parmin ) != NULL) | nelem>-1)
                	{
                   		if( strlen(linein)>3){
                        		nelem=scantext(linein,gname,words);
                        		if(nelem>0 & strcmp(gname,words[0])==0){
                                		for(j=1;j<nelem;j++){
                                		        strcpy(vnames[kk],words[j]);
                                		        kk++;
                                		};
                        		};
                        		maxi=max(maxi,nelem);

                    		};
                	};
                	if (maxi-1<=0 ){ 
                	        printf("No lipids specified, variable %s needs to be set on file %s \n", gname, mdparin);
                	        exit(3);
                	};
                	sumvs = sumvs + (maxi-1);

			ldat[lip].nvsites=sumvs;
			ldat[lip].vbead=calloc(sumvs,sizeof(int));
        		printf(" %d voronoi center(s) {", sumvs);
        		for (k=0;k<sumvs;k++){
			   printf(" %s ", vnames[k]);
			   fprintf(dataout," %s ",vnames[k]);
			   ldat[lip].vbead[k]=atoi(vnames[k]);
				
        		}; 
			printf("}, \n");
			fprintf(dataout,"\n");		       

			// PRINT AGAIN VORONOI CENTERS
			//for (k=0;k<ldat[lip].nv;k++) printf("REPRINT lip=%d %d \n",lip, ldat[lip].vbead[k]);   
*/
	        // V-site beads  (again)
		// =====================================================
	                // lip+1 index for lipid number
	                //printf("; B Processing Lipid %i \n", lip+1);
			fprintf(dataout,"; V-sites \n");
	        	// Loop to scan all lipid groups
	        	sumvs=0; 
	        	kk=0;      
	        	nelem=3;
	                maxi=-2;
	                rewind(parmin);
			
	                //strcpy(gname,"l"); sprintf(tmp10b, "%d", lip+1); strcat(gname,tmp10b); 
			strcpy(gname,""); sprintf(tmp10b, "%s", lnames[lip]); strcat(gname,tmp10b);
			strcpy(tmp10b,"_Vnum"); strcat(gname,tmp10b);
                	printf("Parsing: %s, ", gname);
                	fprintf(dataout,"%s = ",gname);
		
                	nats=1; 
                	while ( (fgets ( linein, sizeof linein, parmin ) != NULL) | nelem>-1)
                	{
                   		if( strlen(linein)>3){
                        		nelem=scantext(linein,gname,words);
                        		if(nelem>0 & strcmp(gname,words[0])==0){
                                		for(j=1;j<nelem;j++){
                                		        strcpy(vnames[kk],words[j]);
                                		        kk++;
                                		};
                        		};
                        		maxi=max(maxi,nelem);

                    		};
                	};
                	if (maxi-1<=0 ){ 
                	        printf("No lipids specified, variable %s needs to be set on file %s \n", gname, mdparin);
                	        exit(3);
                	};
                	sumvs = sumvs + (maxi-1);

			ldat[lip].nvsites=sumvs;
			ldat[lip].vsites=calloc(sumvs,sizeof(int));
        		printf(" %d V-site center(s) {", sumvs);
        		for (k=0;k<sumvs;k++){
			   printf(" %s ", vnames[k]);
			   fprintf(dataout," %s ",vnames[k]);
			   ldat[lip].vsites[k]=atoi(vnames[k]);
        		}; 
			printf("}, \n");
			fprintf(dataout,"\n");			
	        // fhi6 beads  
		// =====================================================
	                // lip+1 index for lipid number
	                //printf("; B Processing Lipid %i \n", lip+1);
			fprintf(dataout,"; phi_6 particles \n");
	        	// Loop to scan all lipid groups
	        	sumvs=0; 
	        	kk=0;      
	        	nelem=3;
	                maxi=-2;
	                rewind(parmin);
			
	                //strcpy(gname,"l"); sprintf(tmp10b, "%d", lip+1); strcat(gname,tmp10b); 
			strcpy(gname,""); sprintf(tmp10b, "%s", lnames[lip]); strcat(gname,tmp10b);
			strcpy(tmp10b,"_Qnum"); strcat(gname,tmp10b);
                	printf("Parsing: %s, ", gname);
                	fprintf(dataout,"%s = ",gname);
		
                	nats=1; 
                	while ( (fgets ( linein, sizeof linein, parmin ) != NULL) | nelem>-1)
                	{
                   		if( strlen(linein)>3){
                        		nelem=scantext(linein,gname,words);
                        		if(nelem>0 & strcmp(gname,words[0])==0){
                                		for(j=1;j<nelem;j++){
                                		        strcpy(vnames[kk],words[j]);
                                		        kk++;
                                		};
                        		};
                        		maxi=max(maxi,nelem);

                    		};
                	};
                	if (maxi-1<=0 ){ 
                	        printf("No lipids specified, variable %s needs to be set on file %s \n", gname, mdparin);
                	        exit(3);
                	};
                	sumvs = sumvs + (maxi-1);

			ldat[lip].nq6=sumvs;
			ldat[lip].q6bead=calloc(sumvs,sizeof(int));
        		printf(" %d phi6 center(s) {", sumvs);
        		for (k=0;k<sumvs;k++){
			   printf(" %s ", vnames[k]);
			   fprintf(dataout," %s ",vnames[k]);
			   ldat[lip].q6bead[k]=atoi(vnames[k]);
        		}; 
			printf("}, \n");
			fprintf(dataout,"\n");

		//  ========================================
		// Pztesh TRESHOLD VALUE FOR Pz TO CHANGE LIPID STATE
	                //printf("; Processing Lipid %i \n", lip+1);
			fprintf(dataout,"; P2 chain treshold values \n");
	        	// Loop to scan all lipid groups
	        	sumvs=0; 
	        	kk=0;      
	        	nelem=3;
	                maxi=-2;
	                rewind(parmin);
			
	               // strcpy(gname,"l"); sprintf(tmp10b, "%d", lip+1); strcat(gname,tmp10b); 
			strcpy(gname,""); sprintf(tmp10b, "%s", lnames[lip]); strcat(gname,tmp10b);
			strcpy(tmp10b,"_P2trCh"); strcat(gname,tmp10b);
                	printf("Parsing: %s, ", gname);
                	fprintf(dataout,"%s = ",gname);
		
                	nats=1; 
                	while ( (fgets ( linein, sizeof linein, parmin ) != NULL) | nelem>-1)
                	{
                   		if( strlen(linein)>3){
                        		nelem=scantext(linein,gname,words);
                        		if(nelem>0 & strcmp(gname,words[0])==0){
                                		for(j=1;j<nelem;j++){
                                		        strcpy(vnames[kk],words[j]);
                                		        kk++;
                                		};
                        		};
                        		maxi=max(maxi,nelem);
                    		};
                	};
                	if (maxi-1<=0 ){ 
                	        printf("No option specified, variable %s needs to be set on file %s \n", gname, mdparin);
                	        exit(3);
                	};

                	sumvs = sumvs + (maxi-1); // Dont need to sum, it passes only once

			ldat[lip].nt = sumvs;

			//ldat[lip].nv=sumvs; Dont need it anymore, voronoi particles defined above
			ldat[lip].P2trCh=calloc(sumvs,sizeof(double));

			printf("%d chain(s)/lipid, w. tresh. val(s) {", sumvs);
        		for (k=0;k<sumvs;k++){
				printf(" %s ", vnames[k]);
				fprintf(dataout," %s ",vnames[k]);
				ldat[lip].P2trCh[k]=atof(vnames[k]);
        		}; 
			printf("},\n");
			fprintf(dataout,"\n\n");		       


	   // ================================================= //
	   // ================================================= //
	   //							//
	   // 		READING TAIL INPUT VARIABLES		//
	   //							//
	   // ================================================= //
	   // ================================================= //
//	   		printf("NUMBER OF TAILS for this lipid %d \n", ldat[lip].nt);

			ldat[lip].naxt=calloc(ldat[lip].nt, sizeof(int *));
			// Allocate space for tal (Tail Atom list)
			ldat[lip].tal=calloc(ldat[lip].nt, sizeof(int *));
			//
			ldat[lip].Pztail=calloc(ldat[lip].nt, sizeof(double ));
			// Allocate space for P2cut
			ldat[lip].P2cut=calloc(ldat[lip].nt, sizeof(double *));
			// Allocate space for exclusion
			ldat[lip].PZexcl=calloc(ldat[lip].nt, sizeof(int *));

			printf("; Data per lipid chain\n");
			for(lt=0;lt<(ldat[lip].nt);lt++){

				printf("; lipid %i chain %i \n", lip+1, lt+1);
				fprintf(dataout,"; acyl chain info \n");
                     // READING TAIL-PARTICLE NUMBERS  
		     // ====================================================================	
                        	nexcl=0;
                        	kk=0;
                        	nelem=3;
                        	maxi=-2;
                        	rewind(parmin);

                        	strcpy(gname,""); sprintf(tmp10b, "%s", lnames[lip]); strcat(gname,tmp10b);
                        	strcat(gname,"-t"); sprintf(tmp10b, "%d", lt+1); strcat(gname,tmp10b);
                        	strcpy(tmp10b,"_num"); strcat(gname,tmp10b);

				nats=1;
                        	while ( (fgets ( linein, sizeof linein, parmin ) != NULL) | nelem>-1)
				{
                                	if( strlen(linein)>3){
                                        	nelem=scantext(linein,gname,words);
                                        	if(nelem>0 & strcmp(gname,words[0])==0){
                                        	        for(j=1;j<nelem;j++){
                                        	                strcpy(anames[kk],words[j]);
                                        	                kk++;
							};
						};
						maxi=max(maxi,nelem);
					};
				};
                        	if (maxi-1<=0 ){
                        	        printf("Variable %s needs to be set on file %s \n", gname, mdparin);
                        	        exit(3);
                        	};
                        	nexcl = nexcl + (maxi-1);

                        	printf("Parsing: %s,", gname);
                        	printf(" %i elements {", nexcl);
                        	fprintf(dataout,"%s = ",gname);
                        	for (k=0;k<nexcl;k++){
                        	    printf(" %s ",anames[k]);
                        	    fprintf(dataout,"%s ",anames[k]);
                        	};
				printf("} ");
                        	fprintf(dataout,"\n");

			// Allocate space for global variable
				//ldat[lip].naxt=(int *)calloc(ldat[lip].nt,sizeof(int));

				ldat[lip].naxt[lt]=nexcl;
	
				ldat[lip].tal[lt]=(int *)calloc(nexcl,sizeof(int));

				ldat[lip].P2cut[lt]=(double *)calloc(nexcl-2,sizeof(float));

				ldat[lip].PZexcl[lt]=(int *)calloc(nexcl-2,sizeof(int));


				printf("Reading lipid tail %d\n", lt);
				for (nu=0;nu<nexcl;nu++){
				    ldat[lip].tal[lt][nu]=atoi(anames[nu]);
				    //printf("%i, GADelements %i \n",  nexcl, ldat[lip].tal[lt][nu]);
				};

	
			// READING GLOBAL PZexcl TRESHOLD
			// ====================================================================	
		
                        	sumtr=0;
                        	kk=0;
                        	nelem=3;
                        	maxi=-2;
                        	rewind(parmin);

                        	strcpy(gname,""); sprintf(tmp10b, "%s", lnames[lip]); strcat(gname,tmp10b);
                        	strcat(gname,"-t"); sprintf(tmp10b, "%d", lt+1); strcat(gname,tmp10b);
                        	strcpy(tmp10b,"_P2exc"); strcat(gname,tmp10b);

                        	nats=1;
                        	while ( (fgets ( linein, sizeof linein, parmin ) != NULL) | nelem>-1)
                        	{
                        	        if( strlen(linein)>3){
                        	                nelem=scantext(linein,gname,words);
                        	                if(nelem>0 & strcmp(gname,words[0])==0){
                        	                        for(j=1;j<nelem;j++){
                        	                                strcpy(anames[kk],words[j]);
                        	                                kk++;
                        	                        };
                                	        };
                                	        maxi=max(maxi,nelem);

                                	};
                        	};
                        	if (maxi-1<=0 ){
                        	        printf("No treshold specified, variable %s needs to be set on file %s \n", gname, mdparin);
                        	        exit(3);
                        	};
                        	sumtr = sumtr + (maxi-1);
                        	if (kk >= sumats-1 & sumats > 2){
                        	        printf("variable %s on input file  %s needs to define only %i variables \n", gname, mdparin, sumats-2);
                        	        exit(3);
                        	};
				if(sumtr != ldat[lip].naxt[lt]-2){
				        printf("\nvariable %s needs to include %i elements instead of %i, for %i particles \n", gname, ldat[lip].naxt[lt]-2, sumtr,ldat[lip].naxt[lt]);
				        exit(3);
		        	};

                        	printf("Parsing: %s, ", gname);
                        	printf(" %i elements { ", sumtr);
                        	fprintf(dataout,"%s = ",gname);

                        	for (k=0;k<sumtr;k++){
				        printf("%s ",anames[k]);
                        	        fprintf(dataout,"%s ",anames[k]);
					ldat[lip].PZexcl[lt][k]=atoi(anames[k]);
                        	};
                        	printf("}\n");
                        	fprintf(dataout,"\n");

			// ========================================================================
			//printf("l%i-t%i_PZtresh = \n",lip+1,lt+1);

			//fprintf(dataout,"l%i-t%i_PZtresh = \n",lip+1,lt+1);
			//fprintf(dataout,"l%i-t%i_PZ0 = \n\n",lip+1,lt+1);
	    	};
		rewind(parmin);
		rewind(datain);

        }; printf("\n");

//        fprintf(dataout,"%i ", nlgrps);
//        fprintf(dataout,"       ; number of lipid groups, Default=2 \n");

        fclose(dataout);
        //fclose(datain); // FOREST

	return ldat;
}


