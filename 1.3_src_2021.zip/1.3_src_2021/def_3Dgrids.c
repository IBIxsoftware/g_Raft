/*
 *
 *      Parser for Graft input
 *
 */

#include <stdio.h>
#include <stdlib.h>

#include <stddef.h>
#include <ctype.h>
#include <string.h>
#include <math.h>

#include "parser.h"

// SUMS STRUCTURE ALLOCATION
// ###########################################################
t_3Dsums def_3DsumsGD(t_gopts *opts, matrix box){
	
	t_3Dsums sums3DGD;

	int i, j, k;
	int dimX0, dimY0, dimZ0;
	double delta;

	delta=opts->delta;

	dimX0=(int) (floor(box[0][0]/delta)) + 1;
	dimY0=(int) (floor(box[1][1]/delta)) + 1;
	dimZ0=(int) (floor(box[2][2]/delta)) + 1;

	printf("Creating a %dx%dx%d grid for density calculations \n", dimX0, dimY0, dimZ0);

	sums3DGD.gpt=(t_3Dgpt ***) calloc(dimX0, sizeof(t_3Dgpt **));
	for(j=0;j<dimX0;j++){
	   sums3DGD.gpt[j]=(t_3Dgpt **) calloc(dimY0, sizeof(t_3Dgpt *));
	   for(k=0;k<dimY0;k++){
		sums3DGD.gpt[j][k]=(t_3Dgpt *)calloc(dimZ0,sizeof(t_3Dgpt));
	   }
	} 
 
	opts->dimX0=dimX0;
	opts->dimY0=dimY0;
	opts->dimZ0=dimZ0;

	printf("Creating a %dx%dx%d grid for density calculations \n", dimX0, dimY0, dimZ0);
	// =======================================
	sums3DGD.dimX0=dimX0;
	sums3DGD.dimY0=dimY0;
	sums3DGD.dimZ0=dimZ0;
	sums3DGD.nframes=0;


	for(i=0;i<dimX0;i++){
	   for(j=0;j<dimY0;j++){
		for(k=0;k<dimZ0;k++){
		     // Density All Lipids
		     // =============================
			sums3DGD.gpt[i][j][k].N=0; 		// Count number of times node is used
			sums3DGD.gpt[i][j][k].sumRho=0.0; 	// Count rho_ijk
			sums3DGD.gpt[i][j][k].sumRho2=0.0; 	// Count rho_ijk^2 
			sums3DGD.gpt[i][j][k].distLP=0.0;  	// Lipid_membrane-protein distance
		     // Density Lipid group A
		     // =============================
			sums3DGD.gpt[i][j][k].NA=0; 		// Count number of times node is used
			sums3DGD.gpt[i][j][k].sumRhoA=0.0; 	// Count rho_ijk
			sums3DGD.gpt[i][j][k].sumRhoA2=0.0; 	// Count rho_ijk^2 
			sums3DGD.gpt[i][j][k].distLAP=0.0;  	// Lipid_membrane-protein distance
		     // Density Proteins
		     // =============================
			sums3DGD.gpt[i][j][k].NP=0; 		// Count number of times a node is used
			sums3DGD.gpt[i][j][k].sumRhoP=0.0;	// Count rho_ijk 
			sums3DGD.gpt[i][j][k].sumRhoP2=0.0;	// Count rho_ijk^2
		     // =============================
		}
	   }
	}
	return sums3DGD;
}

// GLOBAL GRID ALLOCATION & INITIALIZATION
// ###########################################################
 
t_3Dstats def_3DstatsGD(t_gopts *opts, matrix box){

 	t_3Dstats stats3DGD;

	int i, j, k;
	int dimX0, dimY0, dimZ0;
	double delta;

	delta=opts->delta;

        dimX0=(int) (floor(box[0][0]/delta)) + 1;
        dimY0=(int) (floor(box[1][1]/delta)) + 1;
        dimZ0=(int) (floor(box[2][2]/delta)) + 1;

	printf("Creating a %dx%dx%d 3Dgrid for Density Stats Calculations\n", dimX0, dimY0, dimZ0);


        stats3DGD.gpt=(t_stats3Dgpt ***) calloc(dimX0, sizeof(t_stats3Dgpt **));
        for(j=0;j<dimX0;j++){
           stats3DGD.gpt[j]=(t_stats3Dgpt **) calloc(dimY0, sizeof(t_stats3Dgpt *));
           for(k=0;k<dimY0;k++){
                stats3DGD.gpt[j][k]=(t_stats3Dgpt *)calloc(dimZ0,sizeof(t_stats3Dgpt));
           }
        }
 
	printf("stats3DGD.gpt Allocated \n");

	// =======================================
	stats3DGD.dimX0=dimX0;
	stats3DGD.dimY0=dimY0;
	stats3DGD.dimZ0=dimZ0;
	stats3DGD.delta=delta;
	stats3DGD.nframes=0;
	stats3DGD.rhoALL_ave=0.0;
	for(i=0;i<dimX0;i++){
	   for(j=0;j<dimY0;j++){
		for(k=0;k<dimZ0;k++){
		     // All lipids Density
		     // =========================================
		     	stats3DGD.gpt[i][j][k].N=0;
			stats3DGD.gpt[i][j][k].rhoAVE=0.0;
			stats3DGD.gpt[i][j][k].rhoVAR=0.0;
			stats3DGD.gpt[i][j][k].rhoSEM=0.0;
			stats3DGD.gpt[i][j][k].distLP=0.0;
		     // =========================================	
		     // Lipid A-group Density
		     // =========================================	
		     	stats3DGD.gpt[i][j][k].NA=0;
			stats3DGD.gpt[i][j][k].rhoAAVE=0.0;
			stats3DGD.gpt[i][j][k].rhoAVAR=0.0;
			stats3DGD.gpt[i][j][k].rhoASEM=0.0;
			stats3DGD.gpt[i][j][k].distLAP=0.0;
		     // =========================================	
		     // Protein groups Density
		     // =========================================
			stats3DGD.gpt[i][j][k].NP=0;
			stats3DGD.gpt[i][j][k].rhoPave=0.0;
			stats3DGD.gpt[i][j][k].rhoPvar=0.0;

		}
	   }
	}

	return stats3DGD;
}
 

