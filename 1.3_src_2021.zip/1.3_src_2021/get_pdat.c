/*
 *
 *      Parser for Graft input
 *
 */

#include <stdio.h>
#include <stdlib.h>

#include <stddef.h>
#include <ctype.h>
#include <string.h>

#include "parser.h"
#include "readinp.h"

#define arr_size 250 
#define smallsize 20
#define MAXLIP 65 
#define CHAINATS 60

// ################################################################################################
//
// 		 P  R  O  T  E  I  N 
// 
// ################################################################################################

t_pdat *get_pdat(const char *mdparin, const char *mdparout, t_gopts *gopts){

	t_pdat *pdat;

        char lnames[MAXLIP*3][6];
        char anames[CHAINATS][6];

	int j, k, kk, maxi, nats;
	char *keyword;
        int nelem;
        char *words[40];
        char gname[80]="";
        char tmp10b[80];

	int pgrps;
        char linein[ arr_size ];

        FILE *datain = fopen ( mdparin, "r" );
        FILE *dataout = fopen ( mdparout, "a+" );

	
	fprintf(dataout,"\n; PROTEINS  \n");
        fprintf(dataout,"; ========================================== \n");
	rewind(datain);
	keyword="p-grps";
	//fprintf(dataout,"%s = ",keyword);
	pgrps=0;
        while ( (fgets ( linein, sizeof linein, datain ) != NULL) | nelem>-1)
        {
           if( strlen(linein)>3){
                nelem=scantext(linein,keyword,words);
                if(nelem>0 & strcmp(keyword,words[0])==0){
		  //fprintf(dataout,"%s = ",words[0]);
                    if(atoi(words[1])>0){
                        pgrps=atoi(words[1]);
			printf("%i groups requested\n", pgrps);
			printf("Remember. Stats are calculated respect to groups, not individual proteins");
                    } else {
                        pgrps=0;
                        printf("p-group default set to 0\n");
			printf("If you want to include protein groups on your analysis, please include\n");
			printf("the p-groups = (number) statement, complete additional options as requested\n\n");
                    };
                };
            };  
        };
	gopts->npgp = pgrps;

        fprintf(dataout,"; Number of protein groups, Default=0  \n");
	fprintf(dataout,"p-grps = %i \n", pgrps);
	// Parse PROTEINS 
	// ==========================================================
	int sumprot;
	int pg, nprots;
	int prot;
	// Loop to scan all protein groups
	sumprot=0; // Sum all lipids
	kk=0;	   // Counter for 
	for (pg=1;pg<=pgrps;pg++){
		maxi=-2;
		rewind(datain);
		strcpy(gname,"p-grp"); sprintf(tmp10b, "%d", pg); strcat(gname,tmp10b); // Group name
		printf("\nParsing: %s,{ ", gname);
	  	fprintf(dataout,"%s = ",gname);
		nprots=1; // Default

		while ( (fgets ( linein, sizeof linein, datain ) != NULL) | nelem>-1)
        	{
        	   if( strlen(linein)>3){
        	        nelem=scantext(linein,gname,words);
        	        if(nelem>0 & strcmp(gname,words[0])==0){
			    // printf("The following elements are defined for variable %s :\n", gname);
			    	for(j=1;j<nelem;j++){
        	                	//sumprots = sumprots + nelem;
				        printf("%s ", words[j]);
					fprintf(dataout,"%s ", words[j]);
					// Lipid labels
					strcpy(lnames[kk],words[j]);
					//printf("Prot.Num=%i, group=%i\n", kk+1, pg);
					gid[kk]=pg;
					kk++;
				};
				//printf("NAMA");
			};
			maxi=max(maxi,nelem);
			
        	    };
        	};

		
		if (maxi-1<=0){
			printf("!!variable %s needs to be properly set on file %s \n", gname, mdparin);
			exit(3);
		};
		
		fprintf(dataout,"\n");
		printf("} ,%i proteins", maxi-1);
		sumprot = sumprot + (maxi-1);
	};
	printf("\n%i proteins required \n",sumprot);	
	fprintf(dataout,"\n");

//	check, print lipid names
	gopts->npro=sumprot;
	pdat = malloc(sumprot*sizeof(t_pdat));
        for(j=0;j<sumprot;j++){
	        strcpy(pdat[j].pname,lnames[j]);
		pdat[j].gid=gid[j];
	        //printf("NAMES SHOULD LOOK FINE %s ",lnames[j]);
        }

	// ==========================================================
	fprintf(dataout,"; Protein definition \n");
	fprintf(dataout,"; ------------------------------------------ \n");
        for (prot=0;prot<sumprot;prot++){ 
	  // nexcl=0;
                kk=0;
                nelem=3;
                maxi=-2;
                rewind(datain);

		strcpy(gname,"p"); sprintf(tmp10b, "%d", prot+1); strcat(tmp10b,"-Calpha"); strcat(gname,tmp10b);
		nats=1;


                while ( (fgets ( linein, sizeof linein, datain ) != NULL) | nelem>-1)
		{
                                if( strlen(linein)>3){
                                        nelem=scantext(linein,gname,words);
					
                                        if(nelem>0 & strcmp(gname,words[0])==0){
                                                for(j=1;j<nelem;j++){
                                                        strcpy(anames[kk],words[j]);
                                                        kk++;
						};
					
					};
					maxi=max(maxi,nelem);
				};
		};
		nelem=maxi-1;
                if (nelem!=3 ){
                                printf("Variable %s needs to be properly set on file %s. \n", gname, mdparin);
				printf("Need to specify alpha-particle name, first, last particle in interval\n");
                                exit(3);
                };
                        //nexcl = nexcl + (maxi-1);
			
                printf("\nParsing %s; %s", gname, pdat[prot].pname);
                //printf(" %i elements {", nelem);
		printf(" defined for %s on [", anames[0]);
                fprintf(dataout,"%s = ",gname);
		fprintf(dataout,"%s ",anames[0]);

	     // Commit to prot space
		strcpy(pdat[prot].bn,anames[0]);
		pdat[prot].fa=atoi(anames[1]);
		pdat[prot].la=atoi(anames[2]);
                for (k=1;k<nelem;k++){
                     printf(" %s ",anames[k]);
                     fprintf(dataout,"%s ",anames[k]);
                };
	      //
		printf("] interval");
                fprintf(dataout,"\n");
                 
       
        }
	printf("\n");

// ############### 

	// ==========================================================
	printf("End of parsing \n ");
	// close files
	fclose(dataout);
	fclose(datain);
	return pdat;
};

