
//      ###################################################################
//      //
//      //                          M A I N    F U N C T I O N
//      //
//      //      ###################################################################
#include <stdio.h>
#include <stdlib.h>

#include <stddef.h>
#include <ctype.h>
#include <string.h>

#include "readinp.h"

#include "parser.h"


// #######################################################################
//
//	LDATEXTRA:
//		- 1. SET NUMBER OF ATOMS PER LIPID 
//		- 2. NUMBER OF LIPIDS OF EACH TIME ON SYSTEM
//		     (the second should be probably defined on lipspace)
// #######################################################################

ldatextra(t_gopts *opts, t_ldat **ldat, t_atoms *atoms)
{
	int natoms;
	int natsxtra;
	int i, lip;
	char *atnam;
	char *resnam;
	char *firstat;
        int tresnum;
        char *tresnam;
        char *lname;

	char *aname;

	int indx, atnum, resnum, resindx, atprnt;
	int count;
	int bigcount;
//	printf("Muff kitteh is inside ldatextra \n");

	bigcount=0; // Counts lipid particle, regardless of type

	natoms = (*atoms).nr;
//	printf("atoms = %i \n", natoms);
	natoms = opts->np;
	printf("%i particles read \n", natoms);

	// FIRST GET THE SURFACE ATOMS
	//surf.np=0;
	tresnum=-1;

// 	========================================================
//	1. SET NUMBER OF ATOMS PER LIPID
//	since we have number of atoms for each lipid type,
// 	and the index of the first atom
// 	========================================================
	for(lip=0;lip<(opts->nltypes);lip++){
	    lname=(*ldat)[lip].lname;
	    // printf("lname = %s\n", lname);
	    for(i=0; i<natoms; i++){
		   resindx = atoms->atom[i].resind;
		   resnum = resindx+1;
		   resnam = *(atoms->resinfo[resindx].name);
		   atnam = *(atoms->atomname[i]);
		   atnum = i+1;
		   atprnt = i+1;
		   /*
           	   if( i > 99999) atprnt = 99999;
	           fprintf(stdout,"%5d%-5s%5s%5i%8.3f%8.3f%8.3f\n",resnum, resnam, atnam, atprnt, (*x)[i][0], (*x)[i][1],(*x)[i][2]); 
		   */
		   // Point at first atom of LIPID k
	 	   if(strcmp(lname,resnam)==0){
		   	//printf("Lipid %s ",resnam);
		    	strcpy((*ldat)[lip].fa,atnam);
			// Small loop to find number of atoms
			count=0;
			while(resnum != (atoms->atom[i+count].resind) ){
			     count++;      
			     bigcount++;
			} 
			// Last atom
			strcpy((*ldat)[lip].la,*(atoms->atomname[i+count-1]));
			// printf("last bead %s \n",*(atoms->atomname[i+count-1]));
			// Number of atoms
			(*ldat)[lip].natxl = count;
			printf("Lipid %s has %d particles\n", resnam, count);
			break;
		   }
            }
	}
	 
	//printf("\n bigcount= %d",bigcount);
// 	========================================================
//	2. NUMBER OF LIPIDS OF EACH TIME ON SYSTEM
// 	========================================================
	bigcount=0;
	for(lip=0;lip<(opts->nltypes);lip++){
            lname=(*ldat)[lip].lname;
	    aname=(*ldat)[lip].fa;
	    count=0;
            //printf("lname = %s\n", lname);
            for(i=0; i<natoms; i++){
		   resindx = atoms->atom[i].resind;
                   resnam = *(atoms->resinfo[resindx].name);
                   atnam = *(atoms->atomname[i]);
                   if(strcmp(lname,resnam)==0 && strcmp(aname,atnam)==0){
		      	count++;
                   }
            }
	    printf("%d %s lipids on system \n", count, lname);
	    (*ldat)[lip].nlips=count;
        }

	//printf("\n bigcount= %d",bigcount);
	//printf("END INSIDE \n");




}


// ########################################################################################
//	MEMSPACE: CREATES ARRAY MEMB CONTAINING slips TOTAL LIPIDS ON MEMBRANE
//		1. FIRST BEAD OF A LIPID REFERRED TO  (*memb).lidx[slips]=i 
//		   the number is referred to atom numbers on atoms array
//		2. LIPID TYPE (*memb).ltype[slips]=lip
//		   number referred to lipid number
// ########################################################################################
memspace(t_gopts *opts, t_ldat **ldat, t_atoms *atoms, t_memb *memb)
{

	int kprot;
	int lip;
	int slips;
	int i, natoms;
	int count, k, countnv, nv, nltypes;
	int resindx;
        char *atnam;
        char *resnam;
        char *firstat;
        char *lname;

        char *aname;
	natoms = opts->np;
	nltypes = opts->nltypes;;
	// GET NUMBER OF LIPIDS PER TYPE AND ADD IT
	slips=0;
	for(lip=0;lip<nltypes;lip++){
	 	slips = slips + (*ldat)[lip].nlips;	
	}
	printf("You have %d lipids \n", slips);

 
	// ALLOCATE
	// NUMBER OF HEAD BEADS 
	memb->slips=slips;
	memb->indxRefrm=calloc(slips,sizeof(char)); // Lipid number
	(*memb).lidx=calloc(slips,sizeof(int));	 // First bead on lipid
	(*memb).lUorD=calloc(slips,sizeof(int)); // Lipid up or down	
	(*memb).Nlip=calloc(slips,sizeof(rvec)); // Local normal of vector
	(*memb).Hlip=calloc(slips,sizeof(rvec)); // Head lipid
	(*memb).Tlip=calloc(slips,sizeof(rvec)); // Tail position
	(*memb).ltype=calloc(slips,sizeof(int)); // Lipid type

	(*memb).lipid=(t_lip *)calloc(slips,sizeof(t_lip));
	(*memb).vptsxlip=calloc(slips,sizeof(int)); // sum of voronoi points per lipid
						 // this is redundant, but i like it

	slips=0;
	countnv=0;
	for(lip=0;lip<nltypes;lip++){
           lname=(*ldat)[lip].lname;
	   aname=(*ldat)[lip].fa;  
	   nv=(*ldat)[lip].nvsites;
	   // FILL DATA ON memb
           for(i=0; i<natoms; i++){
                   resindx = atoms->atom[i].resind;
                   resnam = *(atoms->resinfo[resindx].name);
                   atnam = *(atoms->atomname[i]);
                   if(strcmp(lname,resnam)==0 && strcmp(aname,atnam)==0){ // COUNT WITH FIRST BEAD
			(*memb).lidx[slips]=i; // FIRST BEAD NEW LIPID
	                // printf("ELEM %d value=%d is the atom index of particle 1 \n", slips, i);
			//
			// SETS LIPID TYPE SO WE CAN REFEER TO IT LATER
			(*memb).ltype[slips]=lip;
			// printf("lidx=%d, Lname=%s, ltype=%d, aname=%s \n", i, resnam, lip,atnam );	
			
			// New way of storing
			(*memb).lipid[slips].lidx=i;	    // Index to BEAD, NOT Lipid number	
			(*memb).lipid[slips].ltype=lip;     // Lipid type 
			//(*memb).lipid[slips].lname,lname);
			strcpy((*memb).lipid[slips].lname,lname);
			// printf("NANANA %s\n", (*memb).lipid[slips].lname);

 			(*memb).vptsxlip[slips]=nv;
			
			countnv = countnv + nv;

                        slips++;

                   }
            }
	    // Count number of tails
	         	 

	}	
	printf("===> %d lipid types, %d lipids in total, %d v-sites total \n", opts->nltypes, slips, countnv);

	// Lipid V-site data
	(*memb).svpts=countnv;
 	(*memb).vptslnum=calloc(countnv,sizeof(int)); 	// V-site lipid number
 	(*memb).vpts=calloc(countnv,sizeof(int)); 	// V-site particle numbers

// NEWBIE

	int jvatom, jj, js, jnhats;
	int numv;

	slips=0;
	countnv=0;

	for(lip=0;lip<nltypes;lip++){
	    lname=(*ldat)[lip].lname;
	    aname=(*ldat)[lip].fa;  
	    nv=(*ldat)[lip].nvsites;
            for(i=0; i<natoms; i++){
                resindx = atoms->atom[i].resind;
                resnam = *(atoms->resinfo[resindx].name);
                atnam = *(atoms->atomname[i]);
                if(strcmp(lname,resnam)==0 && strcmp(aname,atnam)==0){ // COUNT WITH FIRST BEAD

		     /*
			jnhats=(*ldat)[lip].nsdown; 
			for(jh=0; jh<jnhats; jh++){
				jj=(*ldat)[lip].lsdown[jh];
				printf("lsdown lipid=%s lip=%d, nv=%d, %d \n", lname, lip, jnhats, jj);
			} 
		     */
		     /*
			for(jh=0; jh<nv; jh++){
	 			jj=(*ldat)[lip].vsites[jh];
 	 			printf("v-site lipid=%s lip=%d, nv=%d, %d \n", lname, lip, nv, jj);
	 		}
		     */
	    	      memb->indxRefrm[slips]=slips+1;	// Need this label for the time we use image beads
							// in such a case lip will not be the same as lip+1
							// say memb->indxRefrm[lip+slips]=lip+1 etc.

		     for(js=0; js<nv; js++){
		         jvatom = i + (*ldat)[lip].vsites[js]-1;
		   //    printf("v-site ch_no=%d lip.No=%d,lipid=%s lip_type=%d, js=%d, indx=%d, labl=%s\n", countnv, slips+1, lname, lip, js, jvatom, *(atoms->atomname[jvatom]));
			 (*memb).vptslnum[slips]=slips;
			 (*memb).vpts[slips]=jvatom;
 		         countnv++;
		     }  
		 slips++;
		 }	
	     }   	 
	}

// NEWBIE	
	
  	printf("Completed MEMB \n");
}




// ########################################################################################
//	PROTSPACE: CREATES PROTEIN SPACE 
// ########################################################################################
protspace(t_gopts *opts, t_pdat **pdat, t_atoms *atoms)
{
	int prot, nprot, i;
	int fa, la;
	char *bname; // Bead name
	char *pname; // Protein name
	int natoms;
	int inx;
	char *atnam;
	int count;
	int resindx;
	char *resnam;

	natoms=opts->np;
	nprot=opts->npro;
	//printf("Muff kitteh is here \n");
	
	for(prot=0;prot<nprot;prot++){
	    pname=(*pdat)[prot].pname;
	    bname=(*pdat)[prot].bn;
	    fa=(*pdat)[prot].fa;
	    la=(*pdat)[prot].la;
	 //   printf(" %s = [%d-%d] \n\n", bname, fa, la);
	    count=0;
	    for(i=fa-1;i<la;i++){
		  resindx = atoms->atom[i].resind;
		  resnam = *(atoms->resinfo[resindx].name);
		  atnam = *(atoms->atomname[i]);
		  if(strcmp(atnam,bname)==0){ 
	//	       printf("HI%d %d, %s %s \n", prot, i, resnam, atnam);
		       	++count;
		  }
	    }
	//    printf("COUNT Number of atoms %d \n", count);
	    (*pdat)[prot].npts=count;
	    (*pdat)[prot].idx=calloc(count,sizeof(int));
	    (*pdat)[prot].x=calloc(count,sizeof(double));
	}
	// 
	// EVERYTHING ALLOCATED, NOW REPEAT AND FILL 
	//
	//printf("AGAIN \n");
	for(prot=0;prot<nprot;prot++){
	   pname=(*pdat)[prot].pname;
	   bname=(*pdat)[prot].bn;
	   fa=(*pdat)[prot].fa;
	   la=(*pdat)[prot].la;
	   printf(" %s = [%d-%d] \n", bname, fa, la);
	   count=0;
	   for(i=fa-1;i<la;i++){
		resindx = atoms->atom[i].resind;
		resnam = *(atoms->resinfo[resindx].name);
		atnam = *(atoms->atomname[i]);
		if(strcmp(atnam,bname)==0){
			// Assignment
		//	printf("HI%d %d, %s %s ", prot, i, resnam, atnam);
		//	printf("HI%d, %d \n", prot, i);
		//	(*pdat)[prot].idx[i]=count; // INCORRECT
		//	printf(" number %d content %d \n",count, i);
		        (*pdat)[prot].idx[count]=i; // CORRECT
			++count;
		}
	   }
	  // printf("COUNT Number of atoms %d \n", count);

	}

}

