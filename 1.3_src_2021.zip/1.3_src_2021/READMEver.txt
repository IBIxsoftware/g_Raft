
gmx_raft.c		Main file, calls everything else

gmx_raft.c_casi2	Can read xtc file and manage coordinates frame by frame
			Line 271 lists atom coordinates if you uncomment it.
			does not recognize tpr file. Only trajectory.

			gmxdump provided xtc subroutine 
			vi /home/eduardoLOCAL/Bio/TAR.GZ/gromacs-4.5.5/src/kernel/gmxdump.c


Curvatura backup matlab program
	http://www.mathworks.com/matlabcentral/fileexchange/11168-surface-curvature/content/surfature.m
