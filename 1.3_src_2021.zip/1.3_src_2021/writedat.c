/*
 *
 *	WRITING STUFF 
 *
 */

#include <stdio.h>
#include <stdlib.h>

#include <stddef.h>
#include <ctype.h>
#include <string.h>
#include <math.h>
#include "parser.h"
#include "readinp.h"

#define arr_size 80 
#define MAXLIP 10 
#define CHAINATS 40
////////////////////////////////////////////////////////////////////////////////////
void writedat(t_2Dgrid *memGD, t_pdat **pdat, rvec**x, t_gopts *opts, matrix box)
{
	int i, j, jp, flag, k;
	int prot, sumprot;
	double xi, yi, zi;
	double dimX0, dimY0,delta;
 
	double c1i, c2i;
	double pi;
	double shape;
	double cness;
	FILE *fcness;
	FILE *fshape;

	dimX0=memGD->dimX0;
	dimY0=memGD->dimY0;
	delta=opts->delta;

	sumprot = opts->npro;

	////////////////////////////////////////////////////////////////////////////
	//	THICKNESS 
	////////////////////////////////////////////////////////////////////////////
	FILE *out_t21= fopen("thickness12.dat","w");
	fprintf(out_t21," 0.00");
	for (j=0;j<dimX0;j++){ xi=j*delta; fprintf(out_t21," %5.2f", xi); };
	fprintf(out_t21,"\n");
	 
	flag=0;
	for(k=0;k<dimY0;k++){
	 
           for (j=0;j<dimX0;j++){ 	

                xi = j*delta;
                yi = k*delta;
 
		zi = fabs(memGD->gpt[j][k].tAVE) - fabs(memGD->gpt[j][k].dAVE);
		if(flag==0) { fprintf(out_t21,"%5.2f ", yi); flag=1;}; // Only print Y value at beginning of row
		fprintf(out_t21," %5.2f",zi);
           }
	   flag=0;
	   fprintf(out_t21,"\n");
        }
	fclose(out_t21);


	// zi=memGD->gpt[j][k].tAVE;
	////////////////////////////////////////////////////////////////////////////
	//	HEIGHT 
	////////////////////////////////////////////////////////////////////////////
	// TOP
	FILE *height_t= fopen("height_t.dat","w");
	fprintf(height_t," 0.00");
	for (j=0;j<dimX0;j++){ xi=j*delta; fprintf(height_t," %5.2f", xi); };
	fprintf(height_t,"\n");
	 
	flag=0;
	for(k=0;k<dimY0;k++){	 
           for (j=0;j<dimX0;j++){ 	
                xi = j*delta;
                yi = k*delta; 
		zi = memGD->gpt[j][k].tAVE;
		if(flag==0) { fprintf(height_t,"%5.2f ", yi); flag=1;}; // Only print Y value at beginning of row
		fprintf(height_t," %5.2f",zi);
           }
	   flag=0;
	   fprintf(height_t,"\n");
        }
	fclose(height_t);

	// MIDDLE
	FILE *height_m= fopen("height_m.dat","w");
	fprintf(height_m," 0.00");
	for (j=0;j<dimX0;j++){ xi=j*delta; fprintf(height_m," %5.2f", xi); };
	fprintf(height_m,"\n");
	 
	flag=0;
	for(k=0;k<dimY0;k++){	 
           for (j=0;j<dimX0;j++){ 	
                xi = j*delta;
                yi = k*delta; 
		zi = memGD->gpt[j][k].mAVE;
		if(flag==0) { fprintf(height_m,"%5.2f ", yi); flag=1;}; // Only print Y value at beginning of row
		fprintf(height_m," %5.2f",zi);
           }
	   flag=0;
	   fprintf(height_m,"\n");
        }
	fclose(height_m);

	// DOWN
	FILE *height_d= fopen("height_d.dat","w");
	fprintf(height_d," 0.00");
	for (j=0;j<dimX0;j++){ xi=j*delta; fprintf(height_d," %5.2f", xi); };
	fprintf(height_d,"\n");
	 
	flag=0;
	for(k=0;k<dimY0;k++){	 
           for (j=0;j<dimX0;j++){ 	
                xi = j*delta;
                yi = k*delta; 
		zi = memGD->gpt[j][k].dAVE;
		if(flag==0) { fprintf(height_d,"%5.2f ", yi); flag=1;}; // Only print Y value at beginning of row
		fprintf(height_d," %5.2f",zi);
           }
	   flag=0;
	   fprintf(height_d,"\n");
        }
	fclose(height_d);


	////////////////////////////////////////////////////////////////////////////
	FILE *out_t1= fopen("thickness1.dat","w");
	fprintf(out_t1," 0.00");
	for (j=0;j<dimX0;j++){ xi=j*delta; fprintf(out_t1," %5.2f", xi); };
	fprintf(out_t1,"\n");
 
	flag=0;
	for(k=0;k<dimY0;k++){
	 
           for (j=0;j<dimX0;j++){ 	

                xi = j*delta;
                yi = k*delta;
 
		zi = fabs(memGD->gpt[j][k].tAVE) - fabs(memGD->gpt[j][k].mAVE);
		if(flag==0) { fprintf(out_t1,"%5.2f ", yi); flag=1;}; // Only print Y value at beginning of row
		fprintf(out_t1," %5.2f",zi);
           }
	   flag=0;
	   fprintf(out_t1,"\n");
        }
	fclose(out_t1);
	////////////////////////////////////////////////////////////////////////////
	FILE *out_t2= fopen("thickness2.dat","w");
	fprintf(out_t2," 0.00");
	for (j=0;j<dimX0;j++){ xi=j*delta; fprintf(out_t2," %5.2f", xi); };
	fprintf(out_t2,"\n");
 
	flag=0;
	for(k=0;k<dimY0;k++){
	 
           for (j=0;j<dimX0;j++){ 	

                xi = j*delta;
                yi = k*delta;
 
		zi = fabs(memGD->gpt[j][k].mAVE) - fabs(memGD->gpt[j][k].dAVE);
		if(flag==0) { fprintf(out_t2,"%5.2f ", yi); flag=1;}; // Only print Y value at beginning of row
		fprintf(out_t2," %5.2f",zi);
           }
	   flag=0;
	   fprintf(out_t2,"\n");
        }
	fclose(out_t2);

 
	////////////////////////////////////////////////////////////////////////////
	// MEAN CURVATURE TOP
	////////////////////////////////////////////////////////////////////////////
	FILE *curv_J= fopen("curv_Km_t.dat","w");
	fprintf(curv_J," 0.00");
	for (j=0;j<dimX0;j++){ xi=j*delta; fprintf(curv_J," %6.3f", xi); };
	fprintf(curv_J,"\n");
 
	flag=0;
	for(k=0;k<dimY0;k++){
	 
           for (j=0;j<dimX0;j++){ 	

                xi = j*delta;
                yi = k*delta;
 
		zi =  memGD->gpt[j][k].J_t ;
		if(flag==0) { fprintf(curv_J,"%6.3f ", yi); flag=1;}; // Only print Y value at beginning of row
		fprintf(curv_J," %6.3f",zi);
		//printf("j=%i, k=%i, J=%f, ", j, k, (*memGD).gpt[j][k].J_t);
           }
	   flag=0;
	   fprintf(curv_J,"\n");
        }
	fclose(curv_J);
 
	////////////////////////////////////////////////////////////////////////////
	// MEAN CURVATURE MIDPLANE
	////////////////////////////////////////////////////////////////////////////

	curv_J= fopen("curv_Km_m.dat","w");
	fprintf(curv_J," 0.00");
	for (j=0;j<dimX0;j++){ xi=j*delta; fprintf(curv_J," %6.3f", xi); };
	fprintf(curv_J,"\n");
 
	flag=0;
	for(k=0;k<dimY0;k++){
	 
           for (j=0;j<dimX0;j++){ 	

                xi = j*delta;
                yi = k*delta;
 
		zi =  memGD->gpt[j][k].J ;
		if(flag==0) { fprintf(curv_J,"%6.3f ", yi); flag=1;}; 
		fprintf(curv_J," %6.3f",zi);
           }
	   flag=0;
	   fprintf(curv_J,"\n");
        }
	fclose(curv_J);
	////////////////////////////////////////////////////////////////////////////
	// MEAN CURVATURE DOWN PLANE
	////////////////////////////////////////////////////////////////////////////
	curv_J= fopen("curv_Km_d.dat","w");
	fprintf(curv_J," 0.00");
	for (j=0;j<dimX0;j++){ xi=j*delta; fprintf(curv_J," %6.3f", xi); };
	fprintf(curv_J,"\n");
 
	flag=0;
	for(k=0;k<dimY0;k++){
	 
           for (j=0;j<dimX0;j++){ 	

                xi = j*delta;
                yi = k*delta;
 
		zi =  memGD->gpt[j][k].J_d ;
		if(flag==0) { fprintf(curv_J,"%6.3f ", yi); flag=1;}; // Only print Y value at beginning of row
		fprintf(curv_J," %6.3f",zi);
		//printf("j=%i, k=%i, J=%f, G=%f\n", j, k, (*memGD).gpt[j][k].J, (*memGD).gpt[j][k].G);
           }
	   flag=0;
	   fprintf(curv_J,"\n");
        }
	fclose(curv_J);

	// ################################################################################################
	// GAUSSIAN CURVATURE TOP-PLANE
	////////////////////////////////////////////////////////////////////////////
	// ===========
	FILE *curv_G= fopen("curv_Kg_t.dat","w");
	fprintf(curv_G," 0.00");
	for (j=0;j<dimX0;j++){ xi=j*delta; fprintf(curv_G," %6.3f", xi); };
	fprintf(curv_G,"\n");
 
	flag=0;
	for(k=0;k<dimY0;k++){
	 
           for (j=0;j<dimX0;j++){ 	

                xi = j*delta;
                yi = k*delta;
		zi = memGD->gpt[j][k].G_t;
		if(flag==0) { fprintf(curv_G,"%6.3f ", yi); flag=1;}; // Only print Y value at beginning of row
		fprintf(curv_G," %6.3f",zi);
           }
	   flag=0;
	   fprintf(curv_G,"\n");
        }
	fclose(curv_G);
	// ===========
	// GAUSSIAN CURVATURE MID-PLANE
	// ===========
	curv_G= fopen("curv_Kg_m.dat","w");
	fprintf(curv_G," 0.00");
	for (j=0;j<dimX0;j++){ xi=j*delta; fprintf(curv_G," %6.3f", xi); };
	fprintf(curv_G,"\n");
 
	flag=0;
	for(k=0;k<dimY0;k++){
	 
           for (j=0;j<dimX0;j++){ 	

                xi = j*delta;
                yi = k*delta;
		zi = memGD->gpt[j][k].G;
		if(flag==0) { fprintf(curv_G,"%6.3f ", yi); flag=1;}; // Only print Y value at beginning of row
		fprintf(curv_G," %6.3f",zi);
           }
	   flag=0;
	   fprintf(curv_G,"\n");
        }
	fclose(curv_G);
	// ===========
	// GAUSSIAN CURVATURE DOWN-PLANE
	// ===========
	curv_G= fopen("curv_Kg_d.dat","w");
	fprintf(curv_G," 0.00");
	for (j=0;j<dimX0;j++){ xi=j*delta; fprintf(curv_G," %6.3f", xi); };
	fprintf(curv_G,"\n");
 
	flag=0;
	for(k=0;k<dimY0;k++){	 
           for (j=0;j<dimX0;j++){ 	
                xi = j*delta;
                yi = k*delta;
		// zi = fabs(memGD->gpt[j][k].G_d);
	 	zi = memGD->gpt[j][k].G_d;
		if(flag==0) { fprintf(curv_G,"%6.3f ", yi); flag=1;}; // Only print Y value at beginning of row
		fprintf(curv_G," %6.3f",zi);
           }
	   flag=0;
	   fprintf(curv_G,"\n");
        }
	fclose(curv_G);
	// ################################################################################################
	// ################################################################################################
	// SHAPE 
	// ################################################################################################

	// ===========
	// TOP-SHAPE
	// ===========
	fshape=fopen("shape_t.dat","w");
	fprintf(fshape," 0.00");
	for (j=0;j<dimX0;j++){ xi=j*delta; fprintf(fshape," %6.3f", xi); };
	fprintf(fshape,"\n");

	pi=3.141592;
	flag=0;
	for(k=0;k<dimY0;k++){
	 
           for (j=0;j<dimX0;j++){ 	

                xi = j*delta;
                yi = k*delta;
		c1i = memGD->gpt[j][k].c1_t;
		c2i = memGD->gpt[j][k].c2_t;
		shape=(2.0/pi)*atan((c1i+c2i)/(min(c1i,c2i)-max(c1i,c2i)));

		if(flag==0) { fprintf(fshape,"%6.3f ", yi); flag=1;}; // Only print Y value at beginning of row
		fprintf(fshape," %6.3f",shape);
           }
	   flag=0;
	   fprintf(fshape,"\n");
        }
	fclose(fshape); 

	// ===========
	// MID-SHAPE
	// ===========
	fshape=fopen("shape_m.dat","w");
	fprintf(fshape," 0.00");
	for (j=0;j<dimX0;j++){ xi=j*delta; fprintf(fshape," %6.3f", xi); };
	fprintf(fshape,"\n");
	flag=0;
	for(k=0;k<dimY0;k++){
	 
           for (j=0;j<dimX0;j++){ 	

                xi = j*delta;
                yi = k*delta;
		c1i = memGD->gpt[j][k].c1;
		c2i = memGD->gpt[j][k].c2;
		shape=(2.0/pi)*atan((c1i+c2i)/(min(c1i,c2i)-max(c1i,c2i)));

		if(flag==0) { fprintf(fshape,"%6.3f ", yi); flag=1;}; // Only print Y value at beginning of row
		fprintf(fshape," %6.3f",shape);
           }
	   flag=0;
	   fprintf(fshape,"\n");
        }
	fclose(fshape);
	// ===========
	// LOW-SHAPE 
	// ===========
	fshape=fopen("shape_d.dat","w");
	fprintf(fshape," 0.00");
	for (j=0;j<dimX0;j++){ xi=j*delta; fprintf(fshape," %6.3f", xi); };
	fprintf(fshape,"\n");
	flag=0;
	for(k=0;k<dimY0;k++){
	 
           for (j=0;j<dimX0;j++){ 	

                xi = j*delta;
                yi = k*delta;
		c1i = memGD->gpt[j][k].c1_d;
		c2i = memGD->gpt[j][k].c2_d;
		shape=(2.0/pi)*atan((c1i+c2i)/(min(c1i,c2i)-max(c1i,c2i)));

		if(flag==0) { fprintf(fshape,"%6.3f ", yi); flag=1;}; // Only print Y value at beginning of row
		fprintf(fshape," %6.3f",shape);
           }
	   flag=0;
	   fprintf(fshape,"\n");
        }
	fclose(fshape);

	// ################################################################################################
	// CURVEDNESS 
	// ################################################################################################
	// ==============
	// TOP-CURVEDNESS
	// ==============
	fcness= fopen("curvedness_t.dat","w");
	fprintf(fcness," 0.00");
	for (j=0;j<dimX0;j++){ xi=j*delta; fprintf(fcness," %6.3f", xi); };
	fprintf(fcness,"\n");
 	pi=3.141592;
	flag=0;
	for(k=0;k<dimY0;k++){
	 
           for (j=0;j<dimX0;j++){ 	

                xi = j*delta;
                yi = k*delta;
		c1i = memGD->gpt[j][k].c1_t;
		c2i = memGD->gpt[j][k].c2_t;
		cness=sqrtf((c1i*c1i +c2i*c2i)/2.0);

		if(flag==0) { fprintf(fcness,"%6.3f ", yi); flag=1;}; // Only print Y value at beginning of row
		fprintf(fcness," %6.3f",cness);
           }
	   flag=0;
	   fprintf(fcness,"\n");
        }
	fclose(fcness);
	// ==============
	// MID-CURVEDNESS
	// ==============
	fcness= fopen("curvedness_m.dat","w");
	fprintf(fcness," 0.00");
	for (j=0;j<dimX0;j++){ xi=j*delta; fprintf(fcness," %6.3f", xi); };
	fprintf(fcness,"\n");
 	pi=3.141592;
	flag=0;
	for(k=0;k<dimY0;k++){
	 
           for (j=0;j<dimX0;j++){ 	

                xi = j*delta;
                yi = k*delta;
		c1i = memGD->gpt[j][k].c1;
		c2i = memGD->gpt[j][k].c2;
		cness=sqrtf((c1i*c1i +c2i*c2i)/2.0);

		if(flag==0) { fprintf(fcness,"%6.3f ", yi); flag=1;}; // Only print Y value at beginning of row
		fprintf(fcness," %6.3f",cness);
           }
	   flag=0;
	   fprintf(fcness,"\n");
        }
	fclose(fcness);
	// ==============
	// LOW-CURVEDNESS 
	// ==============
	fcness= fopen("curvedness_d.dat","w");
	fprintf(fcness," 0.00");
	for (j=0;j<dimX0;j++){ xi=j*delta; fprintf(fcness," %6.3f", xi); };
	fprintf(fcness,"\n");
 	pi=3.141592;
	flag=0;
	for(k=0;k<dimY0;k++){
	 
           for (j=0;j<dimX0;j++){ 	

                xi = j*delta;
                yi = k*delta;
		c1i = memGD->gpt[j][k].c1_d;
		c2i = memGD->gpt[j][k].c2_d;
		cness=sqrtf((c1i*c1i +c2i*c2i)/2.0);

		if(flag==0) { fprintf(fcness,"%6.3f ", yi); flag=1;}; // Only print Y value at beginning of row
		fprintf(fcness," %6.3f",cness);
           }
	   flag=0;
	   fprintf(fcness,"\n");
        }
	fclose(fcness);

	// ################################################################################################
	// ################################################################################################

	FILE *out_lAt = fopen("lAt.dat","w");
	fprintf(out_lAt," 0.000");
	for (j=0;j<dimX0;j++){ xi=j*delta; fprintf(out_lAt," %6.3f", xi); };
	fprintf(out_lAt,"\n");

	flag=0;
	for(k=0;k<dimY0;k++){ 
           for (j=0;j<dimX0;j++){ 	

                xi = j*delta;
                yi = k*delta;
		zi = memGD->gpt[j][k].lAm1AVE; 
		// if(zi>0) printf("%f =====> \n", zi);
		if(flag==0) { fprintf(out_lAt,"%6.3f ", yi); flag=1;}; // Only print Y value at beginning of row
		fprintf(out_lAt," %6.3f", zi);
		//if(zi>0.0) printf(" ====================>  %f ", zi) ;
		 
           }
	   flag=0;
	   fprintf(out_lAt,"\n");
        }
	fclose(out_lAt);


	// ################################################################################################
	// ################################################################################################
	// STDEV
	// ################################################################################################

	out_lAt = fopen("lAt_SEM.dat","w");
	fprintf(out_lAt," 0.000");
	for (j=0;j<dimX0;j++){ xi=j*delta; fprintf(out_lAt," %6.3f", xi); };
	fprintf(out_lAt,"\n");

	flag=0;
	for(k=0;k<dimY0;k++){ 
           for (j=0;j<dimX0;j++){ 	

                xi = j*delta;
                yi = k*delta;
		zi = memGD->gpt[j][k].lAm1SEM; 
		// if(zi>0) printf("%f =====> \n", zi);
		if(flag==0) { fprintf(out_lAt,"%6.3f ", yi); flag=1;}; // Only print Y value at beginning of row
		fprintf(out_lAt," %6.3f", zi);
		//if(zi>0.0) printf(" ====================>  %f ", zi) ;
		 
           }
	   flag=0;
	   fprintf(out_lAt,"\n");
        }
	fclose(out_lAt);

	out_lAt = fopen("lAt_VAR.dat","w");
	fprintf(out_lAt," 0.000");
	for (j=0;j<dimX0;j++){ xi=j*delta; fprintf(out_lAt," %6.3f", xi); };
	fprintf(out_lAt,"\n");

	flag=0;
	for(k=0;k<dimY0;k++){ 
           for (j=0;j<dimX0;j++){ 	

                xi = j*delta;
                yi = k*delta;
		zi = memGD->gpt[j][k].lAm1VAR; 
		// if(zi>0) printf("%f =====> \n", zi);
		if(flag==0) { fprintf(out_lAt,"%6.3f ", yi); flag=1;}; // Only print Y value at beginning of row
		fprintf(out_lAt," %6.3f", zi);
		//if(zi>0.0) printf(" ====================>  %f ", zi) ;
		 
           }
	   flag=0;
	   fprintf(out_lAt,"\n");
        }
	fclose(out_lAt);

//


	out_lAt = fopen("lAd_SEM.dat","w");
	fprintf(out_lAt," 0.000");
	for (j=0;j<dimX0;j++){ xi=j*delta; fprintf(out_lAt," %6.3f", xi); };
	fprintf(out_lAt,"\n");

	flag=0;
	for(k=0;k<dimY0;k++){ 
           for (j=0;j<dimX0;j++){ 	

                xi = j*delta;
                yi = k*delta;
		zi = memGD->gpt[j][k].lAm2SEM; 
		// if(zi>0) printf("%f =====> \n", zi);
		if(flag==0) { fprintf(out_lAt,"%6.3f ", yi); flag=1;}; // Only print Y value at beginning of row
		fprintf(out_lAt," %6.3f", zi);
		//if(zi>0.0) printf(" ====================>  %f ", zi) ;
		 
           }
	   flag=0;
	   fprintf(out_lAt,"\n");
        }
	fclose(out_lAt);

	out_lAt = fopen("lAd_VAR.dat","w");
	fprintf(out_lAt," 0.000");
	for (j=0;j<dimX0;j++){ xi=j*delta; fprintf(out_lAt," %6.3f", xi); };
	fprintf(out_lAt,"\n");

	flag=0;
	for(k=0;k<dimY0;k++){ 
           for (j=0;j<dimX0;j++){ 	

                xi = j*delta;
                yi = k*delta;
		zi = memGD->gpt[j][k].lAm2VAR; 
		// if(zi>0) printf("%f =====> \n", zi);
		if(flag==0) { fprintf(out_lAt,"%6.3f ", yi); flag=1;}; // Only print Y value at beginning of row
		fprintf(out_lAt," %6.3f", zi);
		//if(zi>0.0) printf(" ====================>  %f ", zi) ;
		 
           }
	   flag=0;
	   fprintf(out_lAt,"\n");
        }
	fclose(out_lAt);


	// ################################################################################################
	FILE *out_lAd = fopen("lAd.dat","w");
        fprintf(out_lAd," 0.000");
        for (j=0;j<dimX0;j++){ xi=j*delta; fprintf(out_lAd," %6.4f", xi); };
        fprintf(out_lAd,"\n");

        flag=0;
        for(k=0;k<dimY0;k++){
           for (j=0;j<dimX0;j++){

                xi = j*delta;
                yi = k*delta;
                zi =  memGD->gpt[j][k].lAm2AVE;
		//if(zi>0) printf("%f =====> \n", zi);
                if(flag==0) { fprintf(out_lAt,"%6.4f ", yi); flag=1;}; // Only print Y value at beginning of row
                fprintf(out_lAt," %6.4f", zi);
		 
           }
           flag=0;
           fprintf(out_lAt,"\n");
        }
        fclose(out_lAt);

	////////////////////////////////////////////////////////////////////////////
	// PROTEIN
	/////////////////////////////////////////////////////////////////////////////
	FILE *out_prot = fopen("proteinbeads.dat","w");
	 
        for (prot=0;prot<sumprot;prot++){
             printf("prot= %d\n", prot);
              for(jp=0;jp<(*pdat)[prot].npts ;jp++){
                i=(*pdat)[prot].idx[jp];
                xi=(*x)[i][0];
                yi=(*x)[i][1];
                zi=(*x)[i][2];
		fprintf(out_prot,"  %f %f %f  \n",xi,yi,zi);
	     }
	}
	fclose(out_prot);
	////////////////////////////////////////////////////////////////////////////
 
}

  

