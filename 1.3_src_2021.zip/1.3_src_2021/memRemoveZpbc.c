/*
 *
 *	
 *
 * 	This file includes get_cordprot,   get_cordvor and get_cordsurf
 *
 */


#include <stdio.h>
#include <stdlib.h>

#include <stddef.h>
#include <ctype.h>
#include <string.h>
#include "math.h"

#include "parser.h"
#include "readinp.h"

#define arr_size 80 
#define MAXLIP 10 
#define CHAINATS 40

//
//
//	coordprot: Update protein coordinates and store at pdat variable
//		   coordinates are used by both, voronoi and surface calc 
//		   analysis methods.
//
// //////////////////////////////////////////////////////////////////////////////
double cost(rvec *v1, rvec *v2);
double distvec(rvec vref, rvec vtry, matrix box);
double distv(rvec *vref, rvec *vtry, matrix box);
//void lipReform(int j, int k, int nkbead, rvec **x, matrix box);

// //////////////////////////////////////////////////////////////////////////////
//
//	This reforms everything in accordance to lipid tails, i.e.
//	removes pbc arctifacts and makes the membrane whole
//
// //////////////////////////////////////////////////////////////////////////////
memRemoveZpbc(t_gopts *opts, t_ldat **ldat, t_memb *memb, rvec **x, matrix box)
{
	int lip, Nlip;
	int j, jp;
	int k, kp; 
	int slips;
	int nltype;

	int jlip;
	int jresindx;
	char *jresnam, *janame;
	char *jlname;
	int jnhats, jntats;
	int jhval, jtval;
	int jh, jt;

	int klip;
	int kresindx;
	char *kresnam, *kaname;
	char *klname;
	int knhats, kntats;
	int khval, ktval;
	int kh, kt;

	

	double tmp;
	double ctheta;
	double dist;

	int nptsh, nhats;
	int ntats, nptst;
	int counthd, counttl;
	
	int hval, tval;
	int mu, nkbeads;
	char valhead, valtail;

	char flagfirst;

        rvec vecA, vecB;
        rvec delta, fac;
 
	counthd=0;
	counttl=0;
	slips = memb->slips;
	Nlip = opts->nltypes; // Number of types

	nptsh=0;
	nptst=0;

	for(lip=0;lip<Nlip; lip++){
	    nltype=(*ldat)[lip].nlips;
	    nhats=(*ldat)[lip].nsup;
	    ntats=(*ldat)[lip].nsdown;
	    nptsh=nptsh + nltype*nhats;
	    nptst=nptst + nltype*ntats;
	}

	printf("Number of head beads= %d\n", nptsh);
	printf("Number of tail beads= %d\n", nptst);

/*
        memb->dimhds = nptsh;
        memb->dimtsep= nptst;
	memb->dimtjn = nptst;

	memb->mathds = mat_space_char(nptsh, nptsh); // Heads matrix
	memb->mattsep= mat_space_char(nptst, nptst); // Tails matrix 
	memb->mattjn = mat_space_char(nptst, nptst); // Tails matrix

	memb->matOUT = mat_space_char(slips, slips);
	memb->matIN = mat_space_char(slips, slips);
*/


	flagfirst=0;


	char **mcell; 
	int gXdim, gYdim;
	int gx, gy;
	int gxlip, gylip;
	int natxl;
	int ax, ay;
	int nu;
	double ztry, zref, ztail;
	double Ttry, Tref, Tryloc;
	double zold, znew;

	int *cellnelem;
	double *cellzsum;

	int newX, newY, sum;
	int cellcount;

	double dgrid=1.0;

	gXdim=1+(int) (box[0][0]/dgrid); // +1 to include the 0, plus 1 to be beyond limit
	gYdim=1+(int) (box[1][1]/dgrid); // ONLY changed this to +1 only to include the 0.  April 2015

	mcell=mat_space_char(gXdim, gYdim);
	
	cellnelem=calloc(gXdim*gYdim,sizeof(int));
	cellzsum=calloc(gXdim*gYdim,sizeof(double));

	printf("gXdimLARGE=%d gYdimLARGE=%d \n", gXdim, gYdim);

        for(gx=0; gx<gXdim; gx++){
	    for(gy=0; gy<gYdim; gy++){
	    	mcell[gx][gy]=0;				
	    }
	}

 
	// ============================================================
	//
	//	CORRECT FRAME DATA
	//
	// ============================================================

	cellcount=0;

     	for(gx=0;gx<gXdim;gx++){
 
     	for(gy=0;gy<gXdim;gy++){
 
  
	// BEGIN LOOP ON ZCELL
 
             for(jp=0; jp<slips; jp++){
                   j=(*memb).lidx[jp]; 
 
		   jlip=(*memb).ltype[jp];
		   jlname=(*ldat)[jlip].lname;	
			
			vecA[0]=(*memb).Tlip[jp][0];
			vecA[1]=(*memb).Tlip[jp][1];
		   
			ax=(int) vecA[0]/dgrid;  
			ay=(int) vecA[1]/dgrid; 
			if(ax>gXdim-1) ax=0;   // Move to 0
			if(ax<0) ax=gXdim-1; // Send to last frame		
			if(ay>gYdim-1) ay=0;
			if(ay<0) ay=gYdim-1;	 

			if(ax==gx && ay == gy){
	
				mcell[gx][gy]=mcell[gx][gy]+1;

				// FIRST LIPID IN CELL SET zref
				if(mcell[gx][gy]==1) { 
					//printf("gx,gy=%d, %d \n", gx, gy);
					cellcount++; // new cell box
					// Update Tref	for(mu=0;mu<3;mu++) vecA[mu]=(*memb).Tlip[jp][mu];
					if(cellcount==1){
						// Reference for first cell, lipid-tail vector jp	
					   	Tref=(*memb).Tlip[jp][2]; 					
 		 				 
					} else {
						// Get zref for next cell 
						if(cellnelem[cellcount-1] !=0){						 
						 Tref= cellzsum[cellcount-1]/((float) cellnelem[cellcount-1]);
						} else { Tref = box[2][2]/2.0 ; };
						 Ttry=(*memb).Tlip[jp][2];	
						 reformz(Tref,&Ttry,box[2][2]/1.0);
						 (*memb).Tlip[jp][2]=Ttry;					
						//Tref=Ttry;
 						 
					} 
					//printf("cell=%d gx,gy=[%d,%d] Tref=%f \n", cellcount, ax, ay, Tref);
					cellnelem[cellcount]++;
	 				cellzsum[cellcount]=cellzsum[cellcount]+Tref;
					// Reform jp-lipid particles
 
 					for(nu=0;nu<(*ldat)[jlip].natxl;nu++){
						ztry=(*x)[j+nu][2];
						reformz(Tref,&ztry,box[2][2]); 
						(*x)[j+nu][2]=ztry;
					}
  			
				} else { 
					// Reform new Normal according to zref
						Ttry=(*memb).Tlip[jp][2];
						reformz(Tref,&Ttry,box[2][2]/1.0); 	
					 	(*memb).Tlip[jp][2]=Ttry;
						cellnelem[cellcount]++;
						cellzsum[cellcount]=cellzsum[cellcount]+Ttry; 
						 						  
						for(nu=0; nu<(*ldat)[jlip].natxl; nu++)	
  						{						
							ztry=(*x)[j+nu][2];
							reformz(Tref,&ztry,box[2][2]);
							(*x)[j+nu][2]=ztry;					
						};
 				
				};
			 
			// OPERATIONS ON LIPIDS
			}
	  	
		   }


	}
  
 	}   
 

}


