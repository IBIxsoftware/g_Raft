



//      ###################################################################
//      //
//      //                          M A I N    F U N C T I O N
//      //
//      //      ###################################################################
#include <stdio.h>
#include <stdlib.h>

#include <stddef.h>
#include <ctype.h>
#include <string.h>
#include <math.h>

#include "parser.h"
#include "readinp.h"

#include "parser.h"


void set_mems(t_atoms **atoms){
	int i, natoms;
	natoms = (*atoms)->nr;
	printf("inside set_mem atoms = %i ", natoms);
	for (i=0;i<natoms; i++){
	    //printf("SHALALA %5d \n",((*atoms)->atom[i].resind)+1 );
	};
}

void alloc_surf(t_gopts *gopts, t_ldat *ldat, t_pdat *pdat, t_atoms *atoms,  t_surf *surf)
{
	int indx, npts;
	int tnum, lip, nlip;
	int ref;
	int resnum;
	char resnam[5];
	int anum; 
	char anam[5];

	char triallipnam[5];
	char trialatnam[5];

	npts = (atoms)->nr;
	printf("surf-npts %d", npts); 

	surf->np=npts;

	nlip = gopts->nltypes; 
	// Find number of lipids on box


	for (lip=0;lip<nlip;lip++){
	      for (indx=0;indx<npts;indx++){
		  // Names and numbers on gro file
		  /*
		  ref=((*atoms)->atom[indx].resind); 
		  resnum=ref+1;
		  strcpy(resnam,*((*atoms)->resinfo[ref].name));
		  strcpy(anam,*((*atoms)->atomname[indx]));
		 */
                  ref=(atoms->atom[indx].resind); 
                  resnum=ref+1;
                  strcpy(resnam,*(atoms->resinfo[ref].name));
                  strcpy(anam,*(atoms->atomname[indx]));

		  anum = indx+1;
		  tnum = anum;
		  if(tnum > 99999) tnum=99999;
		  fprintf(stdout,"%5d%-5s%5s%5i\n",resnum,resnam,anam,tnum); 
	    
		  // Find the first atom for lipido = lip;
		 // strcpy(triallipnam, ldat[lip].lname);
		 //printf("LIPID %s \n", ldat[lip].lname);
	      }
	}

	//printf("LIPID %s \n", ldat[1].lname);
	return;
}


