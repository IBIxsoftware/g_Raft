/*
 *
 *	
 *
 * 	This file includes get_cordprot,   get_cordvor and get_cordsurf
 *
 */


#include <stdio.h>
#include <stdlib.h>

#include <stddef.h>
#include <ctype.h>
#include <string.h>
#include "math.h"

#include "parser.h"
#include "readinp.h"

#define arr_size 80 
#define MAXLIP 10 
#define CHAINATS 40

//
//
//	coordprot: Update protein coordinates and store at pdat variable
//		   coordinates are used by both, voronoi and surface calc 
//		   analysis methods.
//
// //////////////////////////////////////////////////////////////////////////////
double cost(rvec *v1, rvec *v2);
double distvec(rvec vref, rvec vtry, matrix box);

//
//	coordva:	Update vertice coordinates vpts used for voronoi tesselation
//
// //////////////////////////////////////////////////////////////////////////////

lipNormals(t_gopts *opts, t_ldat **ldat, t_memb *memb, t_atoms *atoms, rvec **x, matrix box)
{
        int i, lip;
        int np;
        int natoms;
        int mats;
        int slips;
        int njlips;
        char *lname;
	char *resnam;
	char *aname;
	int resindx;
        int jp;
	int ih, it;
	int ic;
	int hval, tval;
        double xp, yp, zp;
	rvec fac;
	rvec delta;
	rvec xh0, xh;
	rvec xt0, xt;
	double dxli, dyli, dzli;
	double area, areadB;
	rvec SuAVE, SdAVE;
	int nhats, ntats;
	int mu;
	double dist;

	slips = memb->slips;

	//printf("IN coordlip(), %d lipids\n", slips);
/*
	for(jp=0; jp<slips; jp++){
		// Remember, i points to the head
		i=(*memb).lidx[jp];
		xp=(*x)[i][0];  yp=(*x)[i][1];  zp=(*x)[i][2];
	}
*/

	//for(lip=0;lip<opts->nlip ;lip++){
	//	lname=(*ldat)[lip].lname;
	        for(jp=0; jp<slips; jp++){
         	        i=(*memb).lidx[jp];
			resindx = atoms->atom[i].resind;
                  	resnam = *(atoms->resinfo[resindx].name);
			aname = *(atoms->atomname[i]);

			lip=(*memb).ltype[jp]; // Lipid type
			lname=(*ldat)[lip].lname;
			//if(strcmp(lname,resnam)==0){
			     // Head tail
                	   	xp=(*x)[i][0];  
			   	yp=(*x)[i][1];  
			   	zp=(*x)[i][2];
			     // printf("\n %s  %s %d %f %f %f \n",resnam, aname, i, xp, yp, zp);
			     // SuAVE (AVERAGE VECTOR POINTING TO HEAD BEADS)
			     	nhats=(*ldat)[lip].nsup;
				hval=(*ldat)[lip].lsup[0];
				for(mu=0;mu<3;mu++){
				   xh0[mu]=(*x)[i+(hval-1)][mu]; 
				   SuAVE[mu]=xh0[mu];
				}
				for(ih=1; ih<nhats ;ih++){ 
				   hval=(*ldat)[lip].lsup[ih];	
				   for(mu=0;mu<3;mu++){
					xh[mu]=(*x)[i+(hval-1)][mu]; 
					delta[mu]=fabs(xh[mu]-xh0[mu]); fac[mu]=1.0; 
				   	if(delta[mu]>box[mu][mu]/2){
				  	   if(xh[mu]>xh0[mu]) fac[mu]=-1.0;
				   	   	SuAVE[mu]=SuAVE[mu] + xh[mu] + (fac[mu])*(box[mu][mu]);
				  	} else {
						SuAVE[mu]=SuAVE[mu] + xh[mu];
				   	}
				   }
				   //printf("nhats=%d, hval=%d ", nhats, hval);
				   //printf("pointint at atom %s ",*(atoms->atomname[i+(hval-1)]));
				}
				for(mu=0;mu<3;mu++){ SuAVE[mu]=SuAVE[mu]/nhats;
							(*memb).Hlip[jp][mu]=SuAVE[mu]; }

			     // SdAVE (AVERAGE VECTOR POINTING TO TAIL BEADS)
			     	ntats=(*ldat)[lip].nsdown;
				tval=(*ldat)[lip].lsdown[0];
				for(mu=0;mu<3;mu++){
				   xt0[mu]=(*x)[i+(tval-1)][mu]; 
                                   SdAVE[mu]=xt0[mu];
				}
                                for(it=1; it<ntats ;it++){      
                                   tval=(*ldat)[lip].lsdown[it];
				   for(mu=0;mu<3;mu++){
				     	xt[mu]=(*x)[i+(tval-1)][mu]; 
					delta[mu]=fabs(xt[mu]-xt0[mu]); fac[mu]=1.0;
					if(delta[mu]>box[mu][mu]/2){
						if(xt[mu]>xt0[mu]) fac[mu]=-1.0;
					   	SdAVE[mu]=SdAVE[mu] + xt[mu] + fac[mu]*box[mu][mu];
					} else {
						SdAVE[mu]=SdAVE[mu] + xt[mu];
					}
				   }
                              	   //printf("ntats=%d, tval=%d ", ntats, tval);
                              	   //printf("pointing at atom %s \n",*(atoms->atomname[i+(tval-1)]));
                                }
				for(mu=0;mu<3;mu++){ SdAVE[mu]=SdAVE[mu]/ntats;
						     (*memb).Tlip[jp][mu]=SdAVE[mu]; }

				// MAKE OPERATION WITH CENTER OF HEADS
				// AND CENTER OF TAILS (DEFINE NORMALS)
				for(mu=0;mu<3;mu++){ 
					fac[mu]=1;
					delta[mu]=SuAVE[mu]-SdAVE[mu];
					if(fabs(delta[mu])>box[mu][mu]/2){
						if(SuAVE[mu]>SdAVE[mu]) fac[mu]=-1.0;
						(*memb).Nlip[jp][mu]=delta[mu]+fac[mu]*box[mu][mu];
					} else {
						(*memb).Nlip[jp][mu]=delta[mu];
					}
				}
				dist=sqrtf(delta[0]*delta[0]+delta[1]*delta[1]+delta[2]*delta[2]);

				// CRITERIA FOR UP/DOWN membership
				// for now just 2D symmetry
				// For 3D version should change to dot product with normal
                                // so, we will have to save the internal normal vectors				
				(*memb).lUorD[jp]=1; // They are up by default
				if(delta[2]<0) (*memb).lUorD[jp]=-1;

				// printf("%s  %s %d %f %f %f %f \n",resnam, aname, i, sqrt(dxli*dxli+dyli*dyli+dzli*dzli), xp, yp, zp);
				//dist=sqrtf(delta[2]*delta[2]);
				//printf("%d %f %f\n",jp, dist, fabs(delta[2]));
			//	printf("%d %f %d \n", jp, delta[2],(*memb).lUorD[jp]);
			//}
        	}
	//}

}

