/*
 *
 *      Parser for Graft input
 *
 */

#include <stdio.h>
#include <stdlib.h>

#include <stddef.h>
#include <ctype.h>
#include <string.h>
#include <math.h>

#include "parser.h"

double costeta(rvec *v1, rvec *v2);
//
// The prototype comes from get_coord 
//
void calc_cluster(t_gopts *opts, t_ldat **ldat, t_memb *memb, t_atoms *atoms, rvec **x, matrix box)
{
        int j, k, lip;
        int np;
        int natoms;
        int mats;
        int slips;
        int njlips;
        char *jlname, *klname;
        char *jresnam, *kresnam;
        char *janame, *kaname;
  
        int jp, kp;
	int jresindx, kresindx;
	int njvats, nkvats;
	int jtype, ktype;
        int ih, it;
        int ic;
        int hval, tval;
        //double xp, yp, zp;
        //rvec fac;
        rvec rkj;
        //double dxli, dyli, dzli;
	rvec rj, rk;
	//rvec delta;
	int jtailpt, ktailpt;
	int jv, kv;
        int mu;
        double dist;

        slips = memb->slips;
	// ##############################################################
	//
	//	NEIGHBOR LIST REGARDLESS OF LEAFLET
	//
	// ##############################################################
	// Lipid j
	for(jp=0; jp<slips; jp++){

                // TOP SURFACES
                // =================================================================
		// Point to the head of lipid jp
		j=(*memb).lidx[jp];
		jresindx = atoms->atom[j].resind;
                jresnam = *(atoms->resinfo[jresindx].name);
                janame = *(atoms->atomname[j]);
                jtype=(*memb).ltype[jp]; // Lipid type
                jlname=(*ldat)[jtype].lname;
		// Iterate on lipid chains for j
		for(jv=0;jv<(*ldat)[lip].nvsites;jv++){
			jtailpt= j-1 +(*ldat)[lip].vsites[jv];
 			for(mu=0;mu<3;mu++) rj[mu]=(*x)[jtailpt][mu]; 

			// Lipid k 
			for(kp=0; kp<slips; kp++){
			// Point to the head of lipid kp
			j=(*memb).lidx[jp];
			jresindx = atoms->atom[j].resind;
                	jresnam = *(atoms->resinfo[jresindx].name);
                	janame = *(atoms->atomname[j]);
                	jtype=(*memb).ltype[jp]; // Lipid type
                	jlname=(*ldat)[jtype].lname;
		
   
		      	     for(kv=0;kv<(*ldat)[jtype].nvsites;kv++){			
				ktailpt= k-1 +(*ldat)[lip].vsites[kv];
				for(mu=0;mu<3;mu++){ rk[mu]=(*x)[ktailpt][mu];
						      rkj[mu]=rk[mu]-rj[mu];}  
				
				dist=sqrtf(pow(rkj[0],2)+pow(rkj[1],2)+pow(rkj[2],2));
				// 
				if(dist< opts->rcut_vll){
					printf("SOD dist=%d \n", dist);
				}

			     }
			}
		      	 
		}
			
	}



	// ##############################################################
	//
	//	TICKNESS CALCULATIONS
	//
	// ##############################################################

	// ##############################################################
	printf("\n");
}
