/*
 *
 *      Density Calculations by Frame
 *
 */

#include <stdio.h>
#include <stdlib.h>

#include <stddef.h>
#include <ctype.h>
#include <string.h>
#include <math.h>

#include "parser.h"

double costeta(rvec *v1, rvec *v2);
double filter(int type, int w, int mu, double shift);


void calc_3DGDframe(t_3Dsums *sums3DGD,t_memb *memb,t_ldat **ldat,t_pdat **pdat,t_atoms *atoms,rvec **x,t_gopts *opts,matrix box)
{
	int i, j, k, jp;	
	int jh, jt; // jhead, jtail counter	
	int slips;
	int Nlip;
	char *jlname, *atnam;

	int natxl;
        int jresindx;
        char *jresnam, *janame;
	char *jresnamn;
	rvec x_j; 
	rvec vecB;
	rvec vecZ;
	double ctheta;
	int jnhats, jntats;
	//int valhead, valtail;
	int jlip;

	rvec try;
	double boxX, boxY, boxZ;
	int dimX0, dimY0, dimZ0;
	//int jtindx, 
	int jhindx;
	int gpx, gpy, gpz;
	double delta;
	int gid;
 	t_3Dsml ***tmp3DGD;

	// Lipid Averages Varables

	int w;		// width of filter
	int mu, nu, ou; 	// Variables for filter function
	int iref, jref, kref; // Reference indices that match filter to tmpGD
	//double sumfZval_m, sumf_m; // Midplane sums factor*Zval and sum of factors
	int dimXmax, dimYmax, dimZmax;	

	double sum_WF, sum_W; 
	double sum_WaFa, sum_Wa;
	double sum_WpFp, sum_Wp;
	double fweight;
	double shift;
	int ftype;
	double property;	// Property
	double aveproperty;	// Averaged Property
	double propertyA;
	double avepropertyA;
	double Nbdxcell;	// Number of beads x cell
	double NbdAxcell;
	double volbox;		// Box Volume

	//printf("Setting Temporary Grid \n");
	// ##############################################################
	//
	//	TEMPORARY GRID	
	//	This grid contains raw data prior to averaging
	// ##############################################################
	dimX0=sums3DGD->dimX0;
	dimY0=sums3DGD->dimY0;
	dimZ0=sums3DGD->dimZ0;	

 	dimX0=opts->dimX0;
 	dimY0=opts->dimY0;
	dimZ0=opts->dimZ0;

	//printf("=> dimX0=%d dimY0=%d dimz0=%d\n", dimX0, dimY0, dimZ0);

	tmp3DGD=calloc(dimX0, sizeof(t_3Dsml **));
	for(j=0;j<dimX0;j++){
		tmp3DGD[j]=calloc(dimY0,sizeof(t_3Dsml *));
		for(k=0;k<dimY0;k++){
		   tmp3DGD[j][k]=calloc(dimZ0,sizeof(t_3Dsml));
		};
	} 

	for(i=0; i<dimX0; i++){
	   for(j=0; j<dimY0; j++){
		for(k=0; k<dimZ0; k++){
		     // Number of beads per cell, all lipids
			tmp3DGD[i][j][k].Nbdxcell=0;  
		     // Number of beads per cell, lipid group A
			tmp3DGD[i][j][k].NbdAxcell=0;
		     // Number of Protein beads 
		     	tmp3DGD[i][j][k].NbdPxcell=0;
		}
	   }
	}

	// ##############################################################
	//
	//	LIPID CALCULATIONS  	
	//
	// ##############################################################

	slips = memb->slips;
	Nlip = opts->nltypes; // Number of types
	delta = opts->delta;
	vecZ[0]=0.0; 	vecZ[1]=0.0;	vecZ[2]=1.0;
	boxX=box[0][0];	boxY=box[1][1]; boxZ=box[2][2];
	
	//printf("Nlip = %i\n", Nlip);

	for(jp=0;jp<slips;jp++){
			
                j=(*memb).lidx[jp];  // FIRST BEAD INDEX of LIPID jp
		jlip=(*memb).ltype[jp];
     		  jresindx = atoms->atom[j].resind;
     		  jresnam = *(atoms->resinfo[jresindx].name);
     		  janame = *(atoms->atomname[j]);
 		jresnam= (*memb).lipid[jp].lname;
 				
		//printf("j=%i, jlip=%i\n",j, jlip);
 	
		x_j[0]=(*x)[j][0]; 
		x_j[1]=(*x)[j][1]; 
		x_j[2]=(*x)[j][2];	
		vecB[0]=(*memb).Nlip[jp][0]; 
		vecB[1]=(*memb).Nlip[jp][1]; 
		vecB[2]=(*memb).Nlip[jp][2]; 
			
		// printf("\nindex=%d %s, res %d %s %s\n", j, janame ,jresindx, jresnam, jresnamn);
//		printf("\n\nlipid=%d, index=%d, resname=%s", jp, j, (*memb).lipid[jp].lname);				

		// TOP AND BOTTOM SURFACES
		// =================================================================
		natxl=(*ldat)[jlip].natxl;	// Number of atoms per lipid
		jnhats=(*ldat)[jlip].nsup;   	// Number of head atoms on lipid [jlip]	
		gid=(*ldat)[jlip].gid;		// Group ID
//		printf("\njnhats=%d \n", jnhats);
		//printf("Number of atoms per lipid %s = %i , lipid @gid=%i\n", jresnam, natxl, gid);
		for(jh=0; jh<natxl; jh++){
			jhindx = j + jh;
 	//		printf("head %d %s %s\n", jhindx, *(atoms->atomname[jhindx]), *(atoms->resinfo[atoms->atom[jhindx].resind].name));   			   
		   	// Candidate point	
			try[0]=(*x)[jhindx][0];
		   	try[1]=(*x)[jhindx][1];
			try[2]=(*x)[jhindx][2];

			gpx= (int) (floor(dimX0*try[0]/boxX));
			gpy= (int) (floor(dimY0*try[1]/boxY));
			gpz= (int) (floor(dimZ0*try[2]/boxZ));

			if(gpx>dimX0-1) gpx=0; 
			if(gpx<0) gpx=dimX0-1;

			if(gpy>dimY0-1) gpy=0; 
			if(gpy<0) gpy=dimY0-1;

			if(gpz>dimZ0-1) gpz=0;
			if(gpz<0) gpz=dimZ0-1;

			tmp3DGD[gpx][gpy][gpz].Nbdxcell= tmp3DGD[gpx][gpy][gpz].Nbdxcell + 1;

			if(gid==1){ // Stats for first group of lipids only
			   tmp3DGD[gpx][gpy][gpz].NbdAxcell= tmp3DGD[gpx][gpy][gpz].NbdAxcell + 1;
			}
 
		}

	}

	// ##############################################################
	//
	// 	GET AVERAGED DENSITIES/FRAME 
	//	Not sure if it is really needed
	//
	// ##############################################################

	w=opts->fw3D;
	// w=2 by default
	//printf("EDUARDO %i \n", w);
	ftype=opts->fty;
	shift=opts->ftyshift;

	dimXmax=dimX0-1;  dimYmax=dimY0-1; dimZmax=dimZ0-1;	

	volbox = delta*delta*delta;

	// Increase counter on frames
	sums3DGD->nframes = sums3DGD->nframes + 1;

	for(i=0; i<dimX0; i++){
	for(j=0; j<dimY0; j++){
	for(k=0; k<dimZ0; k++){

		sum_W=0.0;  sum_WF=0.0;   // Sum of Weights x Property
		sum_Wa=0.0; sum_WaFa=0.0; // Sum of Weights x Property Lipid Type 1
		
	//printf("EDUARDO dimXmax=%d, Ymax=%d \n", j, k);
		for(mu=0; mu<=2*w; mu++){	
		for(nu=0; nu<=2*w; nu++){
		for(ou=0; ou<=2*w; ou++){	
			//printf("EDUARDO mu=%d, nu=%d \n", mu, nu);
			iref = i + mu - w;
			if(iref<0) iref = iref + dimXmax; 
			if(iref>dimXmax) iref = iref - dimXmax;

			jref = j + nu - w; 
			if(jref<0) jref = jref + dimYmax;
			if(jref>dimYmax) jref = jref - dimYmax;

			kref = k + ou - w;
			if(kref<0) kref = kref + dimZmax;
			if(kref>dimZmax) kref = kref - dimZmax;
			
			// Value of filter function at kref, jref:
			fweight = filter(ftype,w,mu,shift)*filter(ftype,w,nu,shift)*filter(ftype,w,ou,shift);

		     	// 
		     	// ====================	
			if(tmp3DGD[iref][jref][kref].Nbdxcell >0){	// Compute things of there is data on the cell 
				Nbdxcell=tmp3DGD[iref][jref][kref].Nbdxcell;
				property=((double) Nbdxcell)/volbox;	
				sum_WF = sum_WF + fweight*property; 
				sum_W = sum_W + fweight;
			}
			//
		     	// ====================	
			if(tmp3DGD[iref][jref][kref].NbdAxcell >0){		     	
				NbdAxcell=tmp3DGD[iref][jref][kref].NbdAxcell;
				propertyA=((double) Nbdxcell)/volbox;
				sum_WaFa = sum_WaFa + fweight*propertyA;
                                sum_Wa = sum_Wa + fweight;
			}
		     	// ====================
		}
		}
		}

		// Commit point
		// ##################################
		// Nottice I DO NOT initialize the variable, I simple add to it.
 
		// Average Property
		if(sum_W > 0.0){
			// Number of times it is counted 		
			sums3DGD->gpt[i][j][k].N = sums3DGD->gpt[i][j][k].N + 1;
			// Averaged Property
			aveproperty= sum_WF/sum_W;
			sums3DGD->gpt[i][j][k].sumRho = sums3DGD->gpt[i][j][k].sumRho + aveproperty;
			// Square of Averaged Properties
			sums3DGD->gpt[i][j][k].sumRho2 = sums3DGD->gpt[i][j][k].sumRho2 + pow(aveproperty,2);
 		}
		// ==================================
		if(sum_Wa > 0.0){
			// Number of times it is counted                
			sums3DGD->gpt[i][j][k].NA = sums3DGD->gpt[i][j][k].NA + 1;
			// Averaged Property
			avepropertyA= sum_WaFa/sum_Wa;
			sums3DGD->gpt[i][j][k].sumRhoA = sums3DGD->gpt[i][j][k].sumRhoA + avepropertyA;
			// Square of Averaged Properties
			sums3DGD->gpt[i][j][k].sumRhoA2 = sums3DGD->gpt[i][j][k].sumRhoA2 + pow(avepropertyA,2);
		}
		// ##################################

		// Print the value of each sum
		// printf("ftype=%d, sumFt=%f sumFm=%f sumFd=%f \n", ftype, sumFt, sumFm, sumFd);
	}
	}
	}

	// ##############################################################
	//
	//	PROTEIN DATA TO TEMPORARY GRID
	//
	// ##############################################################
	int prot, sumprot;
	sumprot = opts->npro;
        for (prot=0;prot<sumprot;prot++){
             printf("prot= %d\n", prot);
             for(jp=0;jp<(*pdat)[prot].npts ;jp++){
                i=(*pdat)[prot].idx[jp];

                        try[0]=(*x)[i][0];
                        try[1]=(*x)[i][1];
                        try[2]=(*x)[i][2];

                        gpx= (int) (floor(dimX0*try[0]/boxX));
                        gpy= (int) (floor(dimY0*try[1]/boxY));
                        gpz= (int) (floor(dimZ0*try[2]/boxZ));

                        if(gpx>dimX0-1) gpx=0;
                        if(gpx<0) gpx=dimX0-1;

                        if(gpy>dimY0-1) gpy=0;
                        if(gpy<0) gpy=dimY0-1;

                        if(gpz>dimZ0-1) gpz=0;
                        if(gpz<0) gpz=dimZ0-1;

                        tmp3DGD[gpx][gpy][gpz].NbdPxcell= tmp3DGD[gpx][gpy][gpz].NbdPxcell + 1;

                	//printf(" p %f %f %f \n",try[0],try[1],try[2]);
			//printf(" p %i %i %i \n",gpx,gpy,gpz);
             }
             //printf("         \n");
        }

	// ##############################################################
	//
	//	AVERAGED PROTEIN DATA X FRAME
	//
	// ##############################################################
	w=opts->fw;
	w=2;
	ftype=opts->fty;
	shift=opts->ftyshift;
	int NbdPxcell;
	double propertyP, avepropertyP;
	for(i=0; i<dimX0; i++){
	for(j=0; j<dimY0; j++){
	for(k=0; k<dimZ0; k++){

		sum_Wp=0.0; sum_WpFp=0.0; // Sum of Weights x Property Lipid Type 1
		
	//printf("EDUARDO dimXmax=%d, Ymax=%d \n", j, k);
		for(mu=0; mu<=2*w; mu++){	
		for(nu=0; nu<=2*w; nu++){
		for(ou=0; ou<=2*w; ou++){	
			//printf("EDUARDO mu=%d, nu=%d \n", mu, nu);
			iref = i + mu - w;
			if(iref<0) iref = iref + dimXmax; 
			if(iref>dimXmax) iref = iref - dimXmax;

			jref = j + nu - w; 
			if(jref<0) jref = jref + dimYmax;
			if(jref>dimYmax) jref = jref - dimYmax;

			kref = k + ou - w;
			if(kref<0) kref = kref + dimZmax;
			if(kref>dimZmax) kref = kref - dimZmax;
			
			// Value of filter function at kref, jref:
			fweight = filter(ftype,w,mu,shift)*filter(ftype,w,nu,shift)*filter(ftype,w,ou,shift);

		     	// 
		     	// ====================	
			if(tmp3DGD[iref][jref][kref].NbdPxcell >0){	// Compute things of there is data on the cell 
				NbdPxcell=tmp3DGD[iref][jref][kref].NbdPxcell;
				propertyP=((double) NbdPxcell)/volbox;	
				sum_WpFp = sum_WpFp + fweight*propertyP; 
				sum_Wp = sum_Wp + fweight;
			}
			//
		}
		}
		}

		// Commit point
		// ##################################
		// ==================================
		if(sum_Wp > 0.0){
			// Number of times it is counted                
			sums3DGD->gpt[i][j][k].NP = sums3DGD->gpt[i][j][k].NP + 1;
			// Averaged Property
			avepropertyP= sum_WpFp/sum_Wp;
			sums3DGD->gpt[i][j][k].sumRhoP = sums3DGD->gpt[i][j][k].sumRhoP + avepropertyP;
			// Square of Averaged Properties
			sums3DGD->gpt[i][j][k].sumRhoP2 = sums3DGD->gpt[i][j][k].sumRhoP2 + pow(avepropertyP,2);
		}
		// ##################################

		// Print the value of each sum
		// printf("ftype=%d, sumFt=%f sumFm=%f sumFd=%f \n", ftype, sumFt, sumFm, sumFd);
	}
	}
	}




	free(tmp3DGD);
	// ##############################################################
	printf("\n");
}
