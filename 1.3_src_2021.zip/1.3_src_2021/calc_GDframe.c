/*
 *
 *      Parser for Graft input
 *
 */

#include <stdio.h>
#include <stdlib.h>

#include <stddef.h>
#include <ctype.h>
#include <string.h>
#include <math.h>

#include "parser.h"

double costeta(rvec *v1, rvec *v2);
double filter(int type, int w, int mu, double shift);


void calc_GDframe(t_2Dsums *sumsGD,  t_memb *memb, t_ldat **ldat, t_atoms *atoms, rvec **x, t_gopts *opts, matrix box)
{
	int j, k, jp;	
	int jh, jt; // jhead, jtail counter	
	int slips;
	int Nlip;
	char *jlname, *atnam;


        int jresindx;
        char *jresnam, *janame;
	char *jresnamn;
	rvec x_j; 
	rvec vecB;
	rvec vecZ;
	double ctheta;
	int jnhats, jntats;
	int valhead, valtail;
	int jlip;

	rvec try;
	double boxX, boxY;
	int dimX0, dimY0;
	int jtindx, jhindx;
	int gpx, gpy; double gpz;
	double delta;

 	t_gsml **tmpGD;

	// Variables for averaging
	// ==============================================================
	int w;		// width of filter
	int mu, nu; 	// Variables for filter function
	int jref, kref; // Reference indices that match filter to tmpGD
	double sumfZval_m, sumf_m; // Midplane sums factor*Zval and sum of factors
	int dimXmax, dimYmax;	
	int px, py;

	double sumFxZt, sumFt;
	double sumFxZm, sumFm;
	double sumFxZd, sumFd;
 
	double fval;
	double shift;
	int ftype;
	// ==============================================================

	//printf("Setting Temporary Grid \n");
	// ##############################################################
	//
	//	TEMPORARY GRID	
	//
	// ##############################################################
	dimX0=sumsGD->dimX0;
	dimY0=sumsGD->dimY0;
 	dimX0=opts->dimX0;
 	dimY0=opts->dimY0;

	//printf("=> dimX0=%d dimY0=%d \n", dimX0, dimY0);

	tmpGD=calloc(dimX0, sizeof(t_gsml *));
	for(j=0;j<dimX0;j++){
		tmpGD[j]=calloc(dimY0,sizeof(t_gsml));
	} 

	//printf("=>3 dimX0=%d dimY0=%d \n", dimX0, dimY0);
	
	for(j=0; j<dimX0; j++){
		for(k=0;k< dimY0; k++){
		     // Lipid Thickness
		        // Top, Midplane, and Down plane
			tmpGD[j][k].Nt=0;  
			tmpGD[j][k].Nm=0;
			tmpGD[j][k].Nd=0;
			tmpGD[j][k].t=0.0;
			tmpGD[j][k].m=0.0;
			tmpGD[j][k].d=0.0;
		     // Curvature
		     	// Main
                        tmpGD[j][k].K_Nt=0;
                        tmpGD[j][k].K_t=0.0;
                        tmpGD[j][k].K_Nm=0;
                        tmpGD[j][k].K_m=0.0;
                        tmpGD[j][k].K_Nd=0;
                        tmpGD[j][k].K_d=0.0;
			// Gaussian
                        tmpGD[j][k].G_Nt=0;
                        tmpGD[j][k].G_t=0.0;
                        tmpGD[j][k].G_Nm=0;
                        tmpGD[j][k].G_m=0.0;
                        tmpGD[j][k].G_Nd=0;
                        tmpGD[j][k].G_d=0.0;

		     // Lipid type-A density
		 	tmpGD[j][k].lA_t=0.0;
                        tmpGD[j][k].lA_d=0.0;
		     // Order Parameters    
		        // P2 
                        tmpGD[j][k].P2_Nt=0;
                        tmpGD[j][k].P2_t=0.0;
                        tmpGD[j][k].P2_Nd=0;
                        tmpGD[j][k].P2_d=0.0;
			// F6
                        tmpGD[j][k].F6_Nt=0;
                        tmpGD[j][k].F6_t=0.0;
                        tmpGD[j][k].F6_Nd=0;
                        tmpGD[j][k].F6_d=0.0;

		}
	}

 
	// ##############################################################
	//
	//	SELECT DATA FOR THICKNESS CALCULATIONS
	//
	// ##############################################################

	slips = memb->slips;
	Nlip = opts->nltypes; // Number of types
	delta = opts->delta;
	vecZ[0]=0.0; 	vecZ[1]=0.0;	vecZ[2]=1.0;
	boxX=box[0][0];	boxY=box[1][1];
	

	for(jp=0;jp<slips;jp++){
			
                j=(*memb).lidx[jp];  // FIRST BEAD INDEX of LIPID jp
		jlip=(*memb).ltype[jp];
     		  jresindx = atoms->atom[j].resind;
     		  jresnam = *(atoms->resinfo[jresindx].name);
     		  janame = *(atoms->atomname[j]);
 		jresnam= (*memb).lipid[jp].lname;
 		
		 	
		x_j[0]=(*x)[j][0]; 
		x_j[1]=(*x)[j][1]; 
		x_j[2]=(*x)[j][2];	
		vecB[0]=(*memb).Nlip[jp][0]; 
		vecB[1]=(*memb).Nlip[jp][1]; 
		vecB[2]=(*memb).Nlip[jp][2]; 
			
		// printf("\nindex=%d %s, res %d %s %s\n", j, janame ,jresindx, jresnam, jresnamn);
//		printf("\n\nlipid=%d, index=%d, resname=%s", jp, j, (*memb).lipid[jp].lname);				

		// TOP AND BOTTOM SURFACE DEFINITION
		// =================================================================
		jnhats=(*ldat)[jlip].nsup;   // Number of head atoms on lipid [jlip]	
//		printf("\njnhats=%d \n", jnhats);
		for(jh=0; jh<jnhats; jh++){
			jhindx= j + (*ldat)[jlip].lsup[jh] -1;

 	//		printf("head %d %s %s\n", jhindx, *(atoms->atomname[jhindx]), *(atoms->resinfo[atoms->atom[jhindx].resind].name));   			   
		   	// Candidate point	
			try[0]=(*x)[jhindx][0];
		   	try[1]=(*x)[jhindx][1];
			try[2]=(*x)[jhindx][2];

			gpx= (int) (floor(dimX0*try[0]/boxX));
			gpy= (int) (floor(dimY0*try[1]/boxY));
			gpz= try[2];

			if(gpx>dimX0-1) gpx=0; 
			if(gpx<0) gpx=dimX0-1;

			if(gpy>dimY0-1) gpy=0; 
			if(gpy<0) gpy=dimY0-1;

			// CONDITION TO DEFINE WETHER LIPID IS TOP OR BOTTOM
		   	// =================================================
			ctheta=costeta(&x_j,&vecB);  // precalculated intrinsic normal decides
			ctheta=costeta(&vecB,&vecZ);
		   	if(ctheta>0 ){
				// top plane
//				printf("ctheta=%f\n",ctheta);
				// Place point into temporary grid	
				tmpGD[gpx][gpy].Nt++;
				tmpGD[gpx][gpy].t = tmpGD[gpx][gpy].t + gpz;
				(*memb).lUorD[jp]=1;	// PLUS ONE IS UP
				//		
		   	} else { 
				// bottom plane			
				// Place point into temporary grid	
				tmpGD[gpx][gpy].Nd++;
				tmpGD[gpx][gpy].d = tmpGD[gpx][gpy].d + gpz;	
				(*memb).lUorD[jp]=-1;	// MINUS ONE IS DOWN			
				//			
		   	}

		}
		// MIDPLANE DEFINITION
		// =================================================================
		jntats=(*ldat)[jlip].nsdown; // Number of tail atoms on lipid [jlip]
//		printf("\njntats=%d \n", jntats);
		for(jt=0; jt<jntats; jt++){
			jtindx= j + (*ldat)[jlip].lsdown[jt]-1; // Index on ldat array
 		//	printf("tail %d %s %s\n", jtindx, *(atoms->atomname[jtindx]), *(atoms->resinfo[atoms->atom[jtindx].resind].name));   
 
			try[0]=(*x)[jtindx][0];
			try[1]=(*x)[jtindx][1];
			try[2]=(*x)[jtindx][2];

			gpx = (int) (floor(dimX0*try[0]/boxX));
			gpy = (int) (floor(dimY0*try[1]/boxY));
			gpz = try[2];

			if(gpx>=dimX0-1) gpx=0; 
			if(gpx<0) gpx=dimX0-1;

			if(gpy>=dimY0-1) gpy=0; 
			if(gpy<0) gpy=dimY0-1;

			// Place point into temporary grid
 			tmpGD[gpx][gpy].Nm = tmpGD[gpx][gpy].Nm + 1;
			tmpGD[gpx][gpy].m = tmpGD[gpx][gpy].m + gpz;

		}
		// ============================================

	}

	// ##############################################################
	//
	// 	GET SURFACE FRAME  TOP, MIDDLE AND BOTTOM SURFACE
	//
	// ##############################################################
	w=opts->fw;
	ftype=opts->fty;
	shift=opts->ftyshift;
	dimXmax=dimX0-1;  dimYmax=dimY0-1;	

	for(j=0; j<dimX0; j++){
	for(k=0; k<dimY0; k++){

		sumFxZt=0.0; sumFt=0.0; // Top
		sumFxZm=0.0; sumFm=0.0; // Mid
		sumFxZd=0.0; sumFd=0.0; // Down
	//printf("EDUARDO dimXmax=%d, Ymax=%d \n", j, k);
		for(mu=0; mu<=2*w; mu++){	
		for(nu=0; nu<=2*w; nu++){	
			//printf("EDUARDO mu=%d, nu=%d \n", mu, nu);

			jref = j + mu - w; 
			if(jref<0) jref=jref+dimXmax;
			if(jref>dimXmax) jref=jref-dimXmax;

			kref = k + nu - w;
			if(kref<0) kref=kref+dimYmax;
			if(kref>dimYmax) kref=kref-dimYmax;
			
			// Value of filter function at kref, jref:
			fval=1;			
			fval = filter(ftype,w,mu,shift)*filter(ftype,w,nu,shift);

		     // ====================	
		     // Top plane
		     // ====================	
			if(tmpGD[jref][kref].Nt >0){	// Add if there is data in the point		
				sumFxZt = sumFxZt + fval*tmpGD[jref][kref].t/tmpGD[jref][kref].Nt ;
				sumFt = sumFt + fval;
			}
		     // ====================	
		     // Mid plane
		     // ====================	
			if(tmpGD[jref][kref].Nm >0){			
				sumFxZm = sumFxZm + fval*tmpGD[jref][kref].m/((double) tmpGD[jref][kref].Nm) ;
				sumFm = sumFm + fval;
				//printf("sumFm = %f\n", sumFm); 
			}			
		     // ====================	
		     // Down plane
		     // ====================	
			if(tmpGD[jref][kref].Nd >0){			
				sumFxZd = sumFxZd + fval*tmpGD[jref][kref].d/tmpGD[jref][kref].Nd ;
				sumFd = sumFd + fval;
			}
		     // ====================	
		}
		}
		// Commit point
		// ##################################
		// Nottice I DO NOT initialize the variable, I simple add to it.
 
		// TOP PLANE SUMS 
		if(sumFt > 0.0){ 
			sumsGD->gpt[j][k].Nt = sumsGD->gpt[j][k].Nt + 1;
			sumsGD->gpt[j][k].ts = sumsGD->gpt[j][k].ts + sumFxZt/sumFt;
			sumsGD->gpt[j][k].ts2 = sumsGD->gpt[j][k].ts2 + pow(sumFxZt/sumFt,2);
		}
		// MIDPLANE SUMS 
		if(sumFm != 0){
			sumsGD->gpt[j][k].Nm = sumsGD->gpt[j][k].Nm + 1;
			sumsGD->gpt[j][k].ms = sumsGD->gpt[j][k].ms + sumFxZm/sumFm;
			sumsGD->gpt[j][k].ms2 = sumsGD->gpt[j][k].ms2 + pow(sumFxZm/sumFm,2);
 		}

		// DOWN PLANE SUMS 
		if(sumFd != 0){
			sumsGD->gpt[j][k].Nd = sumsGD->gpt[j][k].Nd + 1;
			sumsGD->gpt[j][k].ds = sumsGD->gpt[j][k].ds + sumFxZd/sumFd;
			sumsGD->gpt[j][k].ds2 = sumsGD->gpt[j][k].ds2 + pow(sumFxZd/sumFd,2);
		}
		// ##################################
 

		// Print the value of each sum
		// printf("ftype=%d, sumFt=%f sumFm=%f sumFd=%f \n", ftype, sumFt, sumFm, sumFd);
	}
	}

	// ##############################################################
	//
	//	DENSITY LIPID GROUP-1
	//
	// ##############################################################
	int gid;
	int nvsites, jv, jvindx;
	double sitefrtop;
	double sitefrdown; 

	double frametopNlip;
	double framedownNlip;

	frametopNlip=0.0;
	framedownNlip=0.0;
	for(jp=0;jp<slips;jp++){
			
                j=(*memb).lidx[jp];  // FIRST BEAD INDEX of LIPID jp
		jlip=(*memb).ltype[jp];
     		  jresindx = atoms->atom[j].resind;
     		  jresnam = *(atoms->resinfo[jresindx].name);
     		  janame = *(atoms->atomname[j]);
 		jresnam= (*memb).lipid[jp].lname;
 		gid=(*ldat)[jlip].gid;			// Group ID
		 	
		// TOP AND BOTTOM SURFACE DEFINITION
		// =================================================================
		nvsites=(*ldat)[jlip].nvsites;   // Number of voronoi atoms on lipid [jlip]	
		//	printf("\njnhats=%d \n", jnhats);
		for(jv=0; jv<nvsites; jv++){
			jvindx= j + (*ldat)[jlip].vsites[jv] - 1;

		   	// Candidate point	
			try[0]=(*x)[jvindx][0];
		   	try[1]=(*x)[jvindx][1];
			try[2]=(*x)[jvindx][2];

			gpx= (int) (floor(dimX0*try[0]/boxX));
			gpy= (int) (floor(dimY0*try[1]/boxY));
			// gpz= try[2];

			if(gpx>dimX0-1) gpx=0; 
			if(gpx<0) gpx=dimX0-1;

			if(gpy>dimY0-1) gpy=0; 
			if(gpy<0) gpy=dimY0-1;

			// Each point contributes (1.0/nvsites) lipids per cell, 
			// so final units is number of particles
			if(gid==1){ // Only type-1 particles
 			   if((*memb).lUorD[jp]>0){ // TOP
				sitefrtop = 1.0/((double) nvsites);
				frametopNlip+=sitefrtop;
			//	tmpGD[gpx][gpy].lA_t += sitefrtop;
				sumsGD->gpt[gpx][gpy].st_Alip += sitefrtop; // Add averaged val
				sumsGD->gpt[gpx][gpy].st2_Alip += pow(sitefrtop,2); 

			   }
			   if((*memb).lUorD[jp]<0){ // DOWN
				sitefrdown = 1.0/((double) nvsites);
 			//	tmpGD[gpx][gpy].lA_d += sitefrdown;
				 framedownNlip+=sitefrdown;
				 sumsGD->gpt[gpx][gpy].sd_Alip +=  sitefrdown;
				 sumsGD->gpt[gpx][gpy].sd2_Alip += pow(sitefrdown,2);
				 //printf("%f \n ", sumsGD->gpt[gpx][gpy].sd_Alip);
			   }
 			}
		}
	}

	printf("Number_lipids_Group_1  TOP= %f DOWN= %f SUM= %f\n", frametopNlip, framedownNlip, frametopNlip+framedownNlip); 
/* 
	// FILTER FRAME
	// =================================================================
	w=opts->fw3D;
	ftype=opts->fty;
	shift=opts->ftyshift;
	dimXmax=dimX0-1;  dimYmax=dimY0-1;	

	for(j=0; j<dimX0; j++){
	for(k=0; k<dimY0; k++){

		sumFxZt=0.0; sumFt=0.0; // Top
		sumFxZd=0.0; sumFd=0.0; // Down
		//printf("EDUARDO dimXmax=%d, Ymax=%d \n", j, k);
		for(mu=0; mu<=2*w; mu++){	
		for(nu=0; nu<=2*w; nu++){	
			//printf("EDUARDO mu=%d, nu=%d \n", mu, nu);

			jref = j + mu - w; 
			if(jref<0) jref=jref+dimXmax;
			if(jref>dimXmax) jref=jref-dimXmax;

			kref = k + nu - w;
			if(kref<0) kref=kref+dimYmax;
			if(kref>dimYmax) kref=kref-dimYmax;
			
			// Value of filter function at kref, jref:	 		
			fval = filter(ftype,w,mu,shift)*filter(ftype,w,nu,shift);

		     // ====================	
		     // Top plane
		     // ====================	
			if(tmpGD[jref][kref].lA_t>0){	// Add if there is data in the point		
				sumFxZt = sumFxZt + fval*tmpGD[jref][kref].lA_t;
				sumFt = sumFt + fval;
			}
		     // ====================	
		     // Down plane
		     // ====================	
			if(tmpGD[jref][kref].lA_d>0){			
				sumFxZd = sumFxZd + fval*tmpGD[jref][kref].lA_d;
				sumFd = sumFd + fval;
			}
		     // ====================	
		}
		}
		// Commit point
		// ##################################
		// Nottice I DO NOT initialize the variable, I simple add to it.
 
		// TOP PLANE SUMS 
		//if(sumFt > 0){ 
			//sumsGD->gpt[j][k].sNt_Alip = sumsGD->gpt[j][k].sNt_Alip + 1; // Num times we use grid pt.
			sumsGD->gpt[j][k].st_Alip = sumsGD->gpt[j][k].st_Alip + sumFxZt/sumFt; // Add averaged val
			sumsGD->gpt[j][k].st2_Alip = sumsGD->gpt[j][k].st2_Alip + pow(sumFxZt/sumFt,2); 
			//printf("sNt_Alip=%d, st_Alip=%f \n", sumsGD->gpt[j][k].sNt_Alip, sumsGD->gpt[j][k].st_Alip);
			//exit(12);
		//}
 
		// DOWN PLANE SUMS 
		//if(sumFd > 0){
			//sumsGD->gpt[j][k].sNd_Alip = sumsGD->gpt[j][k].sNd_Alip + 1;
			sumsGD->gpt[j][k].sd_Alip= sumsGD->gpt[j][k].sd_Alip + sumFxZd/sumFd;
			sumsGD->gpt[j][k].sd2_Alip = sumsGD->gpt[j][k].sd2_Alip + pow(sumFxZd/sumFd,2);

			//printf("sNd_Alip=%d, sd_Alip=%f \n", sumsGD->gpt[j][k].sNd_Alip, sumsGD->gpt[j][k].sd_Alip);
			 
		//}
		// ################################## 
		// Print the value of each sum
		//  printf("ftype=%d, sumFt=%f sumFm=%f sumFd=%f \n", ftype, sumFt, sumFm, sumFd);
	}
	}	
 


// ##############################################################
*/
	free(tmpGD);
	// ##############################################################
	printf("\n");
}
