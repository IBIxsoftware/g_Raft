/*
 *
 *      Parser for Graft input
 *
 */

#include <stdio.h>
#include <stdlib.h>

#include <stddef.h>
#include <ctype.h>
#include <string.h>
#include <math.h>

#include "parser.h"

double costeta(rvec *v1, rvec *v2); 
 
void calc_GDframeLPdist(t_2Dsums *sumsGD,  t_memb *memb, t_ldat **ldat,t_pdat **pdat, t_atoms *atoms, rvec **x, t_gopts *opts, matrix box)
{
	int j, k, jp;	
	int jh, jt; // jhead, jtail counter	
	int slips;
	int Nlip;
	char *jlname, *atnam;
 	t_gsml **tmpGD;

        int jresindx;
        char *jresnam, *janame;
	char *jresnamn;
	rvec x_j; 
	rvec vecB;
	rvec vecZ;
	double ctheta;
	int jnhats, jntats;
	int valhead, valtail;
	int jlip;

	rvec try;
	double boxX, boxY;
	int dimX0, dimY0;
	int jtindx, jhindx;
	int gpx, gpy; double gpz;
	double delta;


}
