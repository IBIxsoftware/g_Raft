/*
 *
 *      Parser for Graft input
 *
 */

#include <stdio.h>
#include <stdlib.h>

#include <stddef.h>
#include <ctype.h>
#include <string.h>

#include "parser.h"
#include "readinp.h"

#define arr_size 250 
#define smallsize 20
#define MAXLIP 65 
#define CHAINATS 60

//      t_gopts get_gopts(const char *mdparin, const char *mdparout, t_gopts *gopts,t_ldat *ldat, t_pdat *pdat)

//	###################################################################
//
//			    M A I N    F U N C T I O N
//
//	###################################################################

t_gopts get_gopts(const char *mdparin, const char *mdparout)
{
	t_gopts gopts;

	int j, k, mu, nu, maxi;
	int ch, number_of_lines = 0;
//	int *vecint;
//	real *vecreal;
	char gname[80]="";
	char tmp10b[80];
	int nelem;
	int getval;
	char *keyword;
	int nwant, nhave;

	// Toy variables
	//size_t arr_size = 128;
	char *p=NULL;
	char linein[ arr_size ];
	
	FILE *datain = fopen ( mdparin, "r" );
	FILE *dataout = fopen ( mdparout, "w" );

        char *words[40];

	// Input variables
	int tesse;
	int syste;
	int proce;
	int clust;

	// Curvature
	int curv;
	int geom;
	int filty;
	double fild;
	int filn;
	int filto;
	int cnt;
	// Lipids
	int nlgrps;
	int nlips;
	char lnames[MAXLIP*3][6];
	char *lnums;
	int *nltails;
	int sumlips;
	int sumchains;
	int kk=0;	
	int lip;
	int lg;

	int density; // 3D density
	// Chain Variables
	// space for MAXLIP*3 chains, 40 variables, size 5 each
	int nats;
	char cnames[MAXLIP*2][40][5];
	char anames[CHAINATS][6];
	char vnames[CHAINATS][6];
	int sumats;
	int sumvs;
	int sumtr;
	int lt; // lipid tail	
	int nexcl; 

        double rcut_h;
	double rcut_t;
        double rcut_vll;
        double rcut_vlp;
        double rcut_vpp;



	// Count number of lines
	number_of_lines++;
	do {
		ch=fgetc(datain);
		if(ch == '\n') number_of_lines++;
	} while (ch != EOF);
	
        // ==========================================================
	// ==========================================================

	gopts.tes=0;	// Tesselation
	gopts.sys=0;	// System
	gopts.pro=0;	// Procedure
	gopts.clu=0;	// Pz, m6, Pz&m6

	gopts.cur=0;	// Curvature
	gopts.delta=0.5; // Delta for grid (first frame)
	gopts.geo=0;	// geo;         // 1=Planar, 2=polar, 3=spherical
	gopts.fty=0;    // 1=Binomial (default), 2=MEX wavelet
 	gopts.fbn=0;    // number of bins
	gopts.fop=0;	// Optional flag

// ##################################################################
//
//  	S Y S T E M	 F L A G S
//
// ##################################################################
	// ==========================================================
	//
	fprintf(dataout,"; SYSTEM FLAGS \n");
	fprintf(dataout,"; ========================================== \n");
        // ==========================================================
        rewind(datain);
        keyword="tesselation";
	fprintf(dataout,"%s = ",keyword);
        while ( (fgets ( linein, sizeof linein, datain ) != NULL) | nelem>-1)
        {
           if( strlen(linein)>3){
                nelem=scantext(linein,keyword,words);
                if(nelem>0 & strcmp(keyword,words[0])==0){
                    if(strcmp(words[1],"yes")==0 | strcmp(words[1],"no")==0 ){
                        tesse=atoi(words[1]);
                        fprintf(dataout,"%s ", words[1]);
                    } else {
                        tesse=1;
                        printf("tesselation option set to default value yes \n");
                        fprintf(dataout,"yes ");
                    };
                };
            };
        };
        fprintf(dataout,"        ; yes(default)/no       \n");
	gopts.tes=tesse;

	// ==========================================================
        rewind(datain);
        keyword="system";
	syste=0;
	//fprintf(dataout,"%s  \n",keyword);
        while ( (fgets ( linein, sizeof linein, datain ) != NULL) | nelem>-1)
        {
           if( strlen(linein)>3){
                nelem=scantext(linein,keyword,words);
                if(nelem>0 & strcmp(keyword,words[0])==0){
                    fprintf(dataout,"%s = ",words[0]);
                    if(strcmp(words[1],"monolayer")==0){
			syste=1; //atoi(words[1]);
			fprintf(dataout,"monolayer "); }
		    else {
			fprintf(dataout,"bilayer ");
		    }
                };
            };
        };
	fprintf(dataout,"         ; monolayer(default)/bilayer \n");
	gopts.sys=syste;

        // ==========================================================
        rewind(datain);
        keyword="procedure";
	proce=2;
	fprintf(dataout,"%s = ",keyword);
        while ( (fgets ( linein, sizeof linein, datain ) != NULL) | nelem>-1)
        {
           if( strlen(linein)>3){
                nelem=scantext(linein,keyword,words);
                if(nelem>0 & strcmp(keyword,words[0])==0){
                    if(strcmp(words[1],"1")==0 | strcmp(words[1],"2") | strcmp(words[1],"3")==0 ){
                        proce=atoi(words[1]);
                    } else {
                        printf("system option set to default value monolayer \n");
                    };
                };
            };
        };
        fprintf(dataout,"%i ", proce);
        fprintf(dataout,"            ; 1=testing,  2=stats (default), 3=line-tension. \n");
	gopts.pro=proce;
	printf("INSIDE gopts.pro = %i \n",gopts.pro);
        // ==========================================================
        rewind(datain);
        keyword="clustering";
	clust=1;
	fprintf(dataout,"%s = ",keyword);
        while ( (fgets ( linein, sizeof linein, datain ) != NULL) | nelem>-1)
        {
           if( strlen(linein)>3){
                nelem=scantext(linein,keyword,words);
                if(nelem>0 & strcmp(keyword,words[0])==0){
                    if(strcmp(words[1],"1")==0 | strcmp(words[1],"2") | strcmp(words[1],"3")==0 ){
                        clust=atoi(words[1]);
                    } else {
                        printf("clustering option set to default value Pz \n");
                    };
                };
            };
        };
        fprintf(dataout,"%i ", clust);
        fprintf(dataout,"           ; 1=Pz (Default),  2=m6,  3=Pz & m6 \n");
	gopts.clu=clust;


	// ---------------------------------------------------------
	fprintf(dataout,"\n; CUTOFF PARAMETERS \n");
	fprintf(dataout,"; ==========================================\n");

        gopts.rcut_h;  			// cutoff raddi head
        gopts.rcut_vll = 0.66;  	// cutoff raddi voronoi
        gopts.rcut_vlp = gopts.rcut_vll;
        gopts.rcut_vpp = gopts.rcut_vll;
        gopts.rcut_t = gopts.rcut_h;  	// cutoff raddi tail

        rewind(datain);
        rcut_h=1.2;
        keyword="rcut_h";
        fprintf(dataout,"%s = ",keyword);
        while ( (fgets ( linein, sizeof linein, datain ) != NULL) | nelem>-1)
        {
           if( strlen(linein)>3){
                nelem=scantext(linein,keyword,words);
                if(nelem>0 & strcmp(keyword,words[0])==0){
                    if(atof(words[1])>0){
                        rcut_h=atof(words[1]);
                    } else {
                        printf("Lipid head-head cutoff defining the lipid surface.  \n");
                    };
                };
            };
        };
        fprintf(dataout,"%2.2f ; Lipid head-head cutoff raddi, default rcut_h= 1.2 \n", rcut_h);
        gopts.rcut_h=rcut_h;

	// ---------------------------------------------------------
        rewind(datain);
        rcut_t=rcut_h;
        keyword="rcut_t";
        fprintf(dataout,"%s = ",keyword);
        while ( (fgets ( linein, sizeof linein, datain ) != NULL) | nelem>-1)
        {
           if( strlen(linein)>3){
                nelem=scantext(linein,keyword,words);
                if(nelem>0 & strcmp(keyword,words[0])==0){
                    if(atof(words[1])>0){
                        rcut_t=atof(words[1]);
                    } else {
                        printf("Lipid tail-tail cutoff defining the membrane midplane surface.  \n");
                    };
                };
            };
        };
        fprintf(dataout,"%2.2f ", rcut_t);
        fprintf(dataout,"            ; Lipid tail-tail cutoff raddi, default rcut_t= rcut_h %f \n", rcut_h);
        gopts.rcut_h=rcut_t;

        // ---------------------------------------------------------
        rewind(datain);
        rcut_vll=0.66;
        keyword="rcut_vll";
        fprintf(dataout,"%s = ",keyword);
        while ( (fgets ( linein, sizeof linein, datain ) != NULL) | nelem>-1)
        {
           if( strlen(linein)>3){
                nelem=scantext(linein,keyword,words);
                if(nelem>0 & strcmp(keyword,words[0])==0){
                    if(atof(words[1])>0){
                        rcut_vll=atof(words[1]);
                    } else {
                        printf("Voronoi lipid-lipid cutoff. (First neighbor raddi on rdf) \n");
                    };
                };
            };
        };
        fprintf(dataout,"%2.2f ", rcut_vll);
        fprintf(dataout,"          ; Voronoi lipid lipid-lipid cutoff raddi, default rcut_v= 0.66 \n");
        gopts.rcut_vll=rcut_vll;
	// ---------------------------------------------------------
        rewind(datain);
        rcut_vlp=rcut_vll;
        keyword="rcut_vlp";
        fprintf(dataout,"%s = ",keyword);
        while ( (fgets ( linein, sizeof linein, datain ) != NULL) | nelem>-1)
        {
           if( strlen(linein)>3){
                nelem=scantext(linein,keyword,words);
                if(nelem>0 & strcmp(keyword,words[0])==0){
                    if(atoi(words[1])>0){
                        rcut_vlp=atof(words[1]);
                    } else {
                        printf("Voronoi lipid-protein cutoff. (First neighbor raddi on rdf) \n");
			printf("set to standard value %f\n", rcut_vlp);
                    };
                };
            };
        };
        fprintf(dataout,"%2.2f ", rcut_vlp);
        fprintf(dataout,"          ; Voronoi lipid protein cutoff raddi, default rcut_vlp= rcut_v \n");
        gopts.rcut_vlp=rcut_vlp;
 
        // ---------------------------------------------------------
        rewind(datain);
        rcut_vpp=rcut_vll;
        keyword="rcut_vpp";
        fprintf(dataout,"%s = ",keyword);
        while ( (fgets ( linein, sizeof linein, datain ) != NULL) | nelem>-1)
        {
           if( strlen(linein)>3){
                nelem=scantext(linein,keyword,words);
                if(nelem>0 & strcmp(keyword,words[0])==0){
                    if(atoi(words[1])>0){
                        rcut_vpp=atof(words[1]);
                    } else {
                        printf("Voronoi protein-protein cutoff. (First neighbor raddi on rdf) \n");
                        printf("set to standard value %f\n", rcut_vpp);
                    };
                };
            };
        };
        fprintf(dataout,"%2.2f ", rcut_vpp);
        fprintf(dataout,"          ; Voronoi protein-protein cutoff raddi, default rcut_vpp= rcut_v \n");
        gopts.rcut_vpp=rcut_vpp;



// ##################################################################
// 
// 	 2D  A N A L Y S E S      F L A G S 
//
// ##################################################################
        // ==========================================================
        // ==========================================================
        fprintf(dataout,"\n; 2D ANALYSES PARAMETERS \n");
        fprintf(dataout,"; ========================================== \n");
	
        rewind(datain);
        keyword="curvature";
	curv=2;
	fprintf(dataout,"%s = ",keyword);
        while ( (fgets ( linein, sizeof linein, datain ) != NULL) | nelem>-1)
        {
           if( strlen(linein)>3){
                nelem=scantext(linein,keyword,words);
                if(nelem>0 & strcmp(keyword,words[0])==0){
		  /*
                    if(strcmp(words[1],"yes")==0 | strcmp(words[1],"no")==0 ){
                        curv=atoi(words[1]);
                    } else {
                        printf("curvature option set to default value no \n");
                    };
		  */
		   curv=atoi(words[1]);
		   if(curv>3){ 
			    printf("option not valid for curvature parameter. Valid options are \n");
			    printf("0=nothing(default), 1=midplane, 2=monolayer, 3=midplane and leaflets\n");
			    exit(3);
			    };
                };
            };
        };
        fprintf(dataout,"%i ", curv);
        fprintf(dataout,"            ; 0=nothing(default), 1=midplane, 2=monolayer(s), 3=midplane and monolayer\n");
	gopts.cur=curv;
	// ---------------------------------------------------------
        rewind(datain);
        keyword="geometry";
	geom=1;
	fprintf(dataout,"%s = ",keyword);
        while ( (fgets ( linein, sizeof linein, datain ) != NULL) | nelem>-1)
        {
           if( strlen(linein)>3){
                nelem=scantext(linein,keyword,words);
                if(nelem>0 & strcmp(keyword,words[0])==0){
                    if(strcmp(words[1],"1")==0 | strcmp(words[1],"2") | strcmp(words[1],"3")==0 ){
                        geom=atoi(words[1]);
                    } else {
                        printf("clustering option set to default value Pz \n");
                    };
                };
            };
        };
        fprintf(dataout,"%i ", geom);
        fprintf(dataout,"             ; 1=Planar, 2=Polar, 3=spherical\n");
	gopts.geo=geom;
	// ---------------------------------------------------------
        rewind(datain);
        keyword="enrich";
	int enrich;
	enrich=0;
	fprintf(dataout,"%s = ",keyword);
        while ( (fgets ( linein, sizeof linein, datain ) != NULL) | nelem>-1)
        {
           if( strlen(linein)>3){
                nelem=scantext(linein,keyword,words);
                if(nelem>0 & strcmp(keyword,words[0])==0){

                    if(strcmp(words[1],"1") | strcmp(words[1],"2")){
                        enrich=atoi(words[1]);
			//printf("======b> enrich = %i \n", enrich);
                    } else {
                        printf("enrich: remap 2D density based on mean value. 0=nothing(default), 1=enrich  \n");
                    };
                };
            };
        };
        fprintf(dataout,"%i ", enrich);
        fprintf(dataout,"               ; 0=nothing(default), 1=enrich\n");
	gopts.enrich=enrich;
	// ---------------------------------------------------------
        rewind(datain);
        keyword="filter-type";
	filty=1;
	fprintf(dataout,"%s = ",keyword);
        while ( (fgets ( linein, sizeof linein, datain ) != NULL) | nelem>-1)
        {
           if( strlen(linein)>3){
                nelem=scantext(linein,keyword,words);
                if(nelem>0 & strcmp(keyword,words[0])==0){
                    if(strcmp(words[1],"1")==0 | strcmp(words[1],"2")==0 | strcmp(words[1],"3")==0){
                        filty=atoi(words[1]);
                    } else {
                        printf("filter-type option set to default Binomial \n");
                    };
                };
            };
        };
	fprintf(dataout,"%d ", filty);
        fprintf(dataout," ; 1=Binomial filter (default), 2=MEX wavelet, 3=MEX non weighted \n");
	gopts.fty=filty;
	printf("Value of filter type = %d \n", filty);

	// ---------------------------------------------------------
        rewind(datain);
        keyword="filter-width";
	int fw, fwtmp;

	if(filty==1) fw=9;
	if(filty==2) fw=13;
	if(filty==3) fw=13;

	fprintf(dataout,"%s = ",keyword);
        while ( (fgets ( linein, sizeof linein, datain ) != NULL) | nelem>-1)
        {
           if( strlen(linein)>3){
                nelem=scantext(linein,keyword,words);
                if(nelem>0 & strcmp(keyword,words[0])==0){
		    fwtmp=atoi(words[1]); 
                    if(filty==1 & ( fwtmp>0 && fwtmp<10)){
			   fw=atoi(words[1]);
		    } else if(filty==2 & atoi(words[1])==13){
			  fw=fwtmp;
		    } else if(filty==3 & atoi(words[1])==13){
			  fw=fwtmp;
                    } else {
                        printf("filter-width option set to default %d\n", fw);
                    };
                };
            };
        };
	fprintf(dataout,"%d ; filter width \n", fw);

	gopts.fw=fw;
	printf("Value of filter width = %d  %d \n", fw, fwtmp);
	  	 
	// ---------------------------------------------------------
        rewind(datain);
        keyword="filter-delta";
	fild=0.5;
	fprintf(dataout,"%s = ",keyword);
        while ( (fgets ( linein, sizeof linein, datain ) != NULL) | nelem>-1)
        {
           if( strlen(linein)>3){
                nelem=scantext(linein,keyword,words);
                if(nelem>0 & strcmp(keyword,words[0])==0){
                    if(atof(words[1])>0){
                        fild=atof(words[1]);
                    } else {
                        printf("filter-delta option set to default 0.5 \n");
                    };
                };
            };
        };
	fprintf(dataout,"%2.2f ; grid spacing for binomial filter, typically 0.5 \n", fild);
        printf(" %2.2f ; grid spacing for binomial filter, typically 0.5 \n", fild);
	
	//gopts.fde=fild;
	gopts.delta=fild;
	// ---------------------------------------------------------

        rewind(datain);
        keyword="filter-shift";
	double ftyshift;
	ftyshift=0.0;
	fprintf(dataout,"%s = ",keyword);
        while ( (fgets ( linein, sizeof linein, datain ) != NULL) | nelem>-1)
        {
           if( strlen(linein)>3){
                nelem=scantext(linein,keyword,words);
                if(nelem>0 & strcmp(keyword,words[0])==0){
                    if(atoi(words[1])>0){
                        ftyshift=atof(words[1]);
                    } else {
                        printf("filter-shift option \n");
                    };
                };
            };
        };
	fprintf(dataout,"%2.2f ", ftyshift);
        fprintf(dataout,"      ; filter-shift option, typically 0.0, change if you get infinities on surface \n");
	gopts.ftyshift=ftyshift;

	// ---------------------------------------------------------
        rewind(datain);
        keyword="filter-opt";
	fprintf(dataout,"%s = ",keyword);
        filto=0;
        while ( (fgets ( linein, sizeof linein, datain ) != NULL) | nelem>-1)
        {
           if( strlen(linein)>3){
                nelem=scantext(linein,keyword,words);
                if(nelem>0 & strcmp(keyword,words[0])==0){
                    if(atoi(words[1])>0){
                        filto=atoi(words[1]);
                    } else {
                        printf("filter option set to default 0 \n");
                    };

                };
            };
        };
        fprintf(dataout,"%i ", filto);
        fprintf(dataout,"           ; Extra optional flag\n");
	gopts.fop=filto;

// ##################################################################
        // ---------------------------------------------------------
        fprintf(dataout,"\n; 3D ANALYSES PARAMETERS \n");
        fprintf(dataout,"; ==========================================\n");

        rewind(datain);
        keyword="density";
        fprintf(dataout,"%s = ",keyword);
        density=0; // Defa
        while ( (fgets ( linein, sizeof linein, datain ) != NULL) | nelem>-1)
        {
           if( strlen(linein)>3){
                nelem=scantext(linein,keyword,words);
                if(nelem>0 & strcmp(keyword,words[0])==0){
                    if(atoi(words[1])>0){
                        density=atoi(words[1]);
                    } else {
                        printf("density variable set to default 0 \n");
                    };

                };
            };
        };
        fprintf(dataout,"%i ", density);
        fprintf(dataout,"           ; flag for 3D analyses\n");
        gopts.density=density;
        // ---------------------------------------------------------
        rewind(datain);
        keyword="filter-width3D";
        fprintf(dataout,"%s = ",keyword);
	int fw3D;
        fw3D=2; // Default
        while ( (fgets ( linein, sizeof linein, datain ) != NULL) | nelem>-1)
        {
           if( strlen(linein)>3){
                nelem=scantext(linein,keyword,words);
                if(nelem>0 & strcmp(keyword,words[0])==0){
                    if(atoi(words[1])>0){
                        fw3D=atoi(words[1]);
                    } else {
                        printf("filter option set to default 0 \n");
                    };

                };
            };
        };
        fprintf(dataout,"%i ", fw3D);
        fprintf(dataout,"           ; filter width 3D calculations\n");
        gopts.fw3D=fw3D;
        // ---------------------------------------------------------
	
// ##################################################################
// 
// 	TRAJECTORY ANALYSES 
//
// ##################################################################
	rewind(datain);
	int frminit, frmend, frmskip;
	frminit=10;
	frmend=100;
	frmskip=10;
        keyword="frames";
        fprintf(dataout,"%s = ",keyword);
        while ( (fgets ( linein, sizeof linein, datain ) != NULL) | nelem>-1)
        {
           if( strlen(linein)>3){
                nelem=scantext(linein,keyword,words);
                if(nelem>0 & strcmp(keyword,words[0])==0){
                   // if(atoi(words[1])>0){
                        frminit=atoi(words[1]);
			frmend=atoi(words[2]);
			frmskip=atoi(words[3]);
                  //  } else {
                        printf("frame analyzer \n");
                  //  };
		   printf(">>> %d %d %d ", frminit, frmend, frmskip);
                };
            };
        };
        fprintf(dataout,"%d %d %d ", frminit, frmend, frmskip);
        fprintf(dataout,"          ; frame analyser \n");
  	gopts.frminit=frminit;
	gopts.frmend=frmend;
	gopts.frmskip=frmskip;


	rewind(datain);
 

// ##################################################################
	fclose(datain);
	fclose(dataout);
	return gopts;	
}


