/*
 *
 *      Parser for Graft input
 *
 */

#include <stdio.h>
#include <stdlib.h>

#include <stddef.h>
#include <ctype.h>
#include <string.h>
#include <math.h>
#include "parser.h"
#include "readinp.h"

#define arr_size 80 
#define MAXLIP 10 
#define CHAINATS 40


// MAXLIP= Maximum number of lipids
FILE* debug;

// SPACE ALLOCATION
int *initvecint(int n)
{
	int i;
	int *v;
	v = calloc(n,sizeof(int));
}

char *initvecchar(int n)
{
        int i;
        char *v;
        v = calloc(n,sizeof(char));
}

int **mat_space_int(int m, int n)
{
	int i;
	int **a;

	a=calloc(m, sizeof(int *));
	for (i=0; i< m; ++i){
	    a[i]= calloc(n, sizeof(int));
	}
	return a;
}

real **mat_space_real(int m, int n)
{
        int i;
        real **a;

        a=calloc(m, sizeof(real *));
        for (i=0; i< m; ++i){
            a[i]= calloc(n, sizeof(real));
        }
        return a;
}

char **mat_space_char(int m, int n)
{
        int i;
        char **a;

        a=calloc(m, sizeof(char *));
        for (i=0; i< m; ++i){
            a[i]= calloc(n, sizeof(char));
        }
        return a;
}

char mat_free_char(char **a, int m)
{
        int i;
	
	for (i=0; i<m; ++i)
		free(++a[i]);
	free(++a);
}
////////////////////////////////

static int search_einp(int ninp, const t_inpfile *inp, const char *name)
{
  int i;

  if (inp==NULL)
    return -1;
  for(i=0; i<ninp; i++)
    if (gmx_strcasecmp_min(name,inp[i].name) == 0)
      return i;
  return -1;
}

static int get_einp(int *ninp,t_inpfile **inp,const char *name)
{
  int    i;
  int    notfound=FALSE;
  char   warn_buf[STRLEN];

/*  if (inp==NULL)
 *      return -1;
 *        for(i=0; (i<(*ninp)); i++)
 *            if (gmx_strcasecmp_min(name,(*inp)[i].name) == 0)
 *                  break;
 *                    if (i == (*ninp)) {*/
  i=search_einp(*ninp, *inp, name);
  if (i == -1)
  {
    notfound=TRUE;
    i=(*ninp)++;
    srenew(*inp,(*ninp));
    (*inp)[i].name=strdup(name);
    (*inp)[i].bSet=TRUE;
  }
  (*inp)[i].count = (*inp)[0].inp_count++;
  (*inp)[i].bSet  = TRUE;
  if (debug)
    fprintf(debug,"Inp %d = %s\n",(*inp)[i].count,(*inp)[i].name);

  /*if (i == (*ninp)-1)*/
  if (notfound)
    return -1;
  else
    return i;
}

int get_eint(int *ninp,t_inpfile **inp,const char *name,int def,
             warninp_t wi)
{
  char buf[32],*ptr,warn_buf[STRLEN];
  int  ii;
  int  ret;

  ii=get_einp(ninp,inp,name);

  if (ii == -1) {
    sprintf(buf,"%d",def);
    (*inp)[(*ninp)-1].value=strdup(buf);

    return def;
  }
  else {
    ret = strtol((*inp)[ii].value,&ptr,10);
    if (ptr == (*inp)[ii].value) {
      sprintf(warn_buf,"Right hand side '%s' for parameter '%s' in parameter file is not an integer value\n",(*inp)[ii].value,(*inp)[ii].name);
      warning_error(wi,warn_buf);
    }

    return ret;
  }
}

// This function parses a line for commands
void get_command(char *linein,char *lineout)
{
fputs ( linein, stdout ); /* write the line */
strcpy(lineout,linein);
printf("Size of line: %i\n", sizeof(linein));
printf("All %s\n",linein);
fputs ( lineout, stdout ); /* write the line */

}

size_t getlin(char **lineptr, size_t *n, FILE *stream) {
    char *bufptr = NULL;
    char *p = bufptr;
    size_t size;
    int c;

    if (lineptr == NULL) {
    	return -1;
    }
    if (stream == NULL) {
    	return -1;
    }
    if (n == NULL) {
    	return -1;
    }
    bufptr = *lineptr;
    size = *n;

    c = fgetc(stream);
    if (c == EOF) {
    	return -1;
    }
    if (bufptr == NULL) {
    	bufptr = malloc(128);
    	if (bufptr == NULL) {
    		return -1;
    	};
    	size = 128;
    }
    p = bufptr;
    while(c != EOF) {
    	if ((p - bufptr) > (size - 1)) {
    		size = size + 128;
    		bufptr = realloc(bufptr, size);
    		if (bufptr == NULL) {
    			return -1;
    		}
    	}
    	*p++ = c;
    	if (c == '\n') {
    		break;
    	}
    	c = fgetc(stream);
    }

    *p++ = '\0';
    *lineptr = bufptr;
    *n = size;

    return p - bufptr - 1;
}

void replaceChar(char *str, char garbage){
      int count;
//     for (count = 0; count < sizeof(str); count++)
      for (count = 0; count < strlen(str); count++)
	{
	  if (str[count] == garbage)
	{
	  str[count] = ' ';
	  break;
	}
	}
}

// Function gets rid of comments after ;
void delintrash(char *str){
	int count;
	int comment;
	comment=strlen(str)+1;
	// printf("\n Adentro papi %i \n",strlen(str));
	// printf("%s\n",str);
	for (count = strlen(str); count > 0 ; count--)
        {
             if (str[count] == ';'){
		// printf("symbol ; at pos=%i \n",count);
		comment=count;
	     }
        }
	// Spit all minus comments
	for (count = comment; count < strlen(str); count++){
	     str[count]=' '; 
	}
}

// Function gets rid of char return
int scanline(char *line, char *words[])
{
//char *line;
char *p;
int j;
char currentword= '\0';
int test;
int jline;
int nwords=0;
int scanval;
// Replace equals for spaces

// printf("Processing New Line\n");

//    p=line;
    replaceChar(line,'=');
//	printf("IN->\n %s\n",line);
    delintrash(line);
//	printf("OUT->\n %s\n",line);
    p=line;

    test=0; scanval=-1;
    while(test==0)
    {
	if(test==0){
           while(isspace(*p)) p++;
	
           if(*p == '\0') test=1;
	}
	if(test==0){
           words[nwords++] = p;
	
           while(!isspace(*p) && *p != '\0') p++;
	
           if(*p == '\0') test=1;
	}
	if(test==0){
           *p++ = '\0';
           //if(nwords >= maxwords) test=1;
	}
    }
    //  The value of the function is 0 by default
        scanval=-1;
//	printf("words[0]=%s, keyword=%s",words[0],keyword);
	//if(strcmp(words[0],keyword)==0){
	   // If success, nwords is size of the words vector
	    scanval=nwords;
	//}

     return scanval; // positive return with No of words if found keyword
}


// Scan a line from text
int scantext(char *line,char *keyword, char *words[])
{
//char *line;
char *p;
int j;
char currentword= '\0';
int test;
int jline;
int nwords=0;
int scanval;
// Replace equals for spaces

// printf("Processing New Line\n");

//    p=line;
    replaceChar(line,'=');
//	printf("IN->\n %s\n",line);
    delintrash(line);
//	printf("OUT->\n %s\n",line);
    p=line;

    test=0; scanval=-1;
    while(test==0)
    {
	if(test==0){
           while(isspace(*p)) p++;
	
           if(*p == '\0') test=1;
	}
	if(test==0){
           words[nwords++] = p;
	
           while(!isspace(*p) && *p != '\0') p++;
	
           if(*p == '\0') test=1;
	}
	if(test==0){
           *p++ = '\0';
           //if(nwords >= maxwords) test=1;
	}
    }
    //  The value of the function is 0 by default
        scanval=-1;
//	printf("words[0]=%s, keyword=%s",words[0],keyword);
	if(strcmp(words[0],keyword)==0){
	   // If success, nwords is size of the words vector
	    scanval=nwords;
	}

     return scanval; // positive return with No of words if found keyword
}

// This function gives back
reformz(double zref, double *zchange, double boxz)
{
        double ztry;
        ztry=*zchange;

        if(ztry > zref ){
           while(ztry-zref>boxz) ztry=ztry-boxz;
           if(fabs(ztry-zref)>boxz/2.0) ztry=ztry-boxz;
        } else {
           while(zref-ztry>boxz) ztry=ztry+boxz;
           if(fabs(zref-ztry)>boxz/2.0) ztry=ztry+boxz;
        }
	
/*
        if(ztry > zref ){
           if(fabs(ztry-zref)>boxz/2.0) ztry=ztry-boxz;
        } else {
           if(fabs(zref-ztry)>boxz/2.0) ztry=ztry+boxz;
        }
*/


        *zchange=ztry;

}



reformzb(double zref, double *zchange, double boxz)
{
	double ztry;
	ztry=*zchange;

	if(ztry > zref ){
	   while(fabs(ztry-zref)>boxz) ztry=ztry-boxz;
	   if(fabs(ztry-zref)>boxz/2) ztry=ztry-boxz;	
	} else { 
	   while(fabs(zref-ztry)>boxz) ztry=ztry+boxz;
	   if(fabs(zref-ztry)>boxz/2) ztry=ztry+boxz;
	}
	*zchange=ztry;

}

refrmvec(rvec *vref, rvec *vchange, matrix box)
{
	rvec vtry;
	int mu;
	double dist;
	vtry[0]=*vchange[0];
	vtry[1]=*vchange[1];
	vtry[2]=*vchange[2];

	// Z coordinate
	for(mu=0;mu<3;mu++){
	   if(vtry[mu] > (*vref)[mu]){
		while(vtry[mu]-(*vref)[mu]>box[mu][mu]) vtry[mu]=vtry[mu]-box[mu][mu];
		if(vtry[mu]-(*vref)[mu]>box[mu][mu]/2.0) vtry[mu]=vtry[mu]-box[mu][mu];
	   } else {
		while((*vref)[mu]-vtry[mu]>box[mu][mu]) vtry[mu]=vtry[mu]+box[mu][mu];
		if((*vref)[mu]-vtry[mu]>box[mu][mu]/2.0) vtry[mu]=vtry[mu]+box[mu][mu];
	   }
	   *vchange[mu]=vtry[mu];
	}
	//dist=sqrtf(pow(vtry[0]-vref[0],2)+ pow(vtry[1]-vref[1],2)+ pow(vtry[2]-vref[2],2));

	//return dist;
}

double distvec(rvec vref, rvec vtry, matrix box)
{
	int mu;
	double dist;
       for(mu=0;mu<3;mu++){
           if(vtry[mu] > vref[mu]){
                while(vtry[mu]-vref[mu]> box[mu][mu]) vtry[mu]=vtry[mu] - box[mu][mu];
                if(vtry[mu]-vref[mu]> box[mu][mu]/2.0) vtry[mu]=vtry[mu] - box[mu][mu];
           } else {
                while(vref[mu]-vtry[mu]> box[mu][mu]) vtry[mu]=vtry[mu]+box[mu][mu];
                if(vref[mu]-vtry[mu]> box[mu][mu]/2.0) vtry[mu]=vtry[mu]+box[mu][mu];
           }
        }
	dist=sqrtf(pow(vtry[0]-vref[0],2)+ pow(vtry[1]-vref[1],2)+ pow(vtry[2]-vref[2],2));
	return dist;
}


double distv(rvec *vref, rvec *vtry, matrix box)
{
        int mu;
        double dist;
       for(mu=0;mu<3;mu++){
           if((*vtry)[mu] > (*vref)[mu]){
                while((*vtry)[mu]-(*vref)[mu]> box[mu][mu]) (*vtry)[mu]=(*vtry)[mu] - box[mu][mu];
                if((*vtry)[mu]-(*vref)[mu]> box[mu][mu]/2.0) (*vtry)[mu]=(*vtry)[mu] - box[mu][mu];
           } else {
                while((*vref)[mu]-(*vtry)[mu]> box[mu][mu]) (*vtry)[mu]=(*vtry)[mu]+box[mu][mu];
                if((*vref)[mu]-(*vtry)[mu]> box[mu][mu]/2.0) (*vtry)[mu]=(*vtry)[mu]+box[mu][mu];
           }
        }
        dist=sqrtf(pow(vtry[0]-vref[0],2)+ pow(vtry[1]-vref[1],2)+ pow(vtry[2]-vref[2],2));
        return dist;
}



double costeta(rvec *v1, rvec *v2)
{
	double costet;
	double dotp;
	double v1bar, v2bar;
	
	
	dotp=(*v1)[0]*(*v2)[0]+(*v1)[1]*(*v2)[1]+(*v1)[2]*(*v2)[2];
	v1bar=sqrtf(pow((*v1)[0],2)+pow((*v1)[1],2)+pow((*v1)[2],2));
	v2bar=sqrtf(pow((*v2)[0],2)+pow((*v2)[1],2)+pow((*v2)[2],2));

	costet=dotp/(v1bar*v2bar);
	//printf("costet=%f\n", costet);
	//printf("v1 = [ %f, %f , %f]\n", (*v1)[0], (*v1)[1], (*v1)[2]);
	//printf("v2 = [ %f, %f , %f]\n", (*v2)[0], (*v2)[1], (*v2)[2]);
	return costet;
}

double dotp(rvec *v1, rvec *v2)
{
	double dot;
	
	dot =(*v1)[0]*(*v2)[0]+(*v1)[1]*(*v2)[1]+(*v1)[2]*(*v2)[2];
	
	return dot;
}

/*
// cross product
rvec *crossp(rvec *A, rvec *B)
{
        rvec *axb;
  
	// 0 = x, 1=y, 2=z
	// AyBz − AzBy
	(*axb)[0]=(*A)[1]*(*B)[2] - (*A)[2]*(*B)[1];
	// AzBx − AxBz
	(*axb)[1]=(*A)[2]*(*B)[0] - (*A)[0]*(*B)[2];
	// AxBy − AyBx
	(*axb)[2]=(*A)[0]*(*B)[1] - (*A)[1]*(*B)[0];

        return axb;
}

// normalized cross product
rvec *ncrossp(rvec *A, rvec *B)
{
        rvec *axb;
	double dotp;
 
	// 0 = x, 1=y, 2=z
	// AyBz − AzBy
	(*axb)[0]=(*A)[1]*(*B)[2] - (*A)[2]*(*B)[1];
	// AzBx − AxBz
	(*axb)[1]=(*A)[2]*(*B)[0] - (*A)[0]*(*B)[2];
	// AxBy − AyBx
	(*axb)[2]=(*A)[0]*(*B)[1] - (*A)[1]*(*B)[0];

	dotp =(*axb)[0]*(*axb)[0]+(*axb)[1]*(*axb)[1]+(*axb)[2]*(*axb)[2];

	(*axb)[0]=((*axb)[0])/sqrtf(dotp);
	(*axb)[1]=((*axb)[1])/sqrtf(dotp);
	(*axb)[2]=((*axb)[2])/sqrtf(dotp);

        return axb;
}
*/

//////////////////////////////////////////////////////////////////
//
//	FILTER FUNCTIONS
//
//////////////////////////////////////////////////////////////////

double filter(int type, int w, int k, double shift){

	double fval;
	
	fval=0;

	// GAUSSIAN (BINOMIAL FUNCTION )
	// ##########################################################
	if(type==1){
		// Gaussian filter created with matlab yG=binopdf(t,msize*2+2,0.5); 
		// w=1; 2*w+1=3 elements; msize=0;  yG=binopdf(t,2,0.5)
		if(w==1){ double g[3]={0.25,0.50,0.25};
			fval=g[k];}
		// w=2; 2*w+1=5 elements; msize=1;  yG=binopdf(t,4,0.5)	
		if(w==2){ double g[5]={0.0625,0.2500,0.3750,0.2500,0.0625};
			fval=g[k];}
		// w=3; 2*w+1=7 elements; msize=2;  yG=binopdf(t,6,0.5)
		//                           0      1      2      3      4      5      6
		if(w==3){ double g[7]={0.0156,0.0938,0.2344,0.3125,0.2344,0.0938,0.0156};
			fval=g[k];}
		// w=4; 2*w+1=9 elements; msize=3; yG=binopdf(t,8,0.5)
		// 			  0      1      2      3      4       5     6     7       8
		if(w==4){ double g[9]={0.0039,0.0312,0.1094,0.2187,0.2734,0.2187,0.1094,0.0312,0.0039};
			fval=g[k];}
		// w=5; 2*w+1 = 11 elements; msize=4; yG=binopdf(t,10,0.5)
		// 			      0      1      2      3      4      5      6      7      8       9     10
		if(w==5){ double g[11]={0.0010,0.0098,0.0439,0.1172,0.2051,0.2461,0.2051,0.1172,0.0439,0.0098,0.0010};
			fval=g[k];}
		// w=6; 2*w+1 = 13 elements
		// 			      0      1      2      3      4      5      6      7       8     9      19    11     12
		if(w==6){ double g[13]={0.0002,0.0029,0.0161,0.0537,0.1208,0.1934,0.2256,0.1934,0.1208,0.0537,0.0161,0.0029,0.0002};
			fval=g[k];}
		// w=7; 2*w+1 = 15 elements
		// 			     0       1      2      3      4      5       6     7      8      9      10     11    12     13     14
		if(w==7){ double g[15]={0.0001,0.0009,0.0056,0.0222,0.0611,0.1222,0.1833,0.2095,0.1833,0.1222,0.0611,0.0222,0.0056,0.0009,0.0001}; 
			fval=g[k];}
		// w=8; 2*w+1 = 17 elements
		//			   0      1      2       3     4      5      6     7        8     9     10    11      12      13     14     15   16
		if(w==8){ double g[17]={0.0001,0.0006,0.0031,0.0117,0.0327,0.0708,0.1214,0.1669,0.1855,0.1669,0.1214,0.0708,0.0327,0.0117,0.0031,0.0006,0.0001};
			fval=g[k];}
		// w=9; 2*w+1 = 19 elements
		// 			   0      1      2      3      4      5      6       7     8       9     10     11     12     13     14     15     16     17     18
		if(w==9){ double g[19]={0.0001,0.0004,0.0017,0.0063,0.0178,0.0407,0.0762,0.1186,0.1542,0.1682,0.1542,0.1186,0.0762,0.0407,0.0178,0.0063,0.0017,0.0004,0.0001};
			fval=g[k];}

		fval=fval*10; // Amplify weights 	
		//fval=0.1+fval;
	};


	// MEXICAN HAT
	// ##########################################################
	if(type==2){ // Mexican Hat
		// w=13, 2*w+1=27 elements  0       1       2       3       4       5       6       7       8       9   10    11     12
		if(w==13){double g[27]={-0.0013,-0.0044,-0.0130,-0.0339,-0.0771,-0.1514,-0.2534,-0.3521,-0.3845,-0.2773,0.0,0.3858,0.7293,    0.8673,0.7293,0.3858,0,-0.2773,-0.3845,-0.3521,-0.2534,-0.1514,-0.0771,-0.0339,-0.0130,-0.0044,-0.0013};
		fval=0.0013+g[k];};

	}

	// MEXICAN HAT NON WEIGHTED
	// ##########################################################
	if(type==3){ // Mexican Hat non weighted
		// w=13, 2*w+1=27 elements  0       1       2       3       4       5       6       7       8       9   10    11     12
		if(w==13){double g[27]={-0.0013,-0.0044,-0.0130,-0.0339,-0.0771,-0.1514,-0.2534,-0.3521,-0.3845,-0.2773,0.0,0.3858,0.7293,    0.8673,0.7293,0.3858,0,-0.2773,-0.3845,-0.3521,-0.2534,-0.1514,-0.0771,-0.0339,-0.0130,-0.0044,-0.0013};
		fval=0.0013+g[k];};

	}

	fval=fval+shift;

	return fval;
}
