/*
 *
 *	WRITING STUFF 
 *
 */

#include <stdio.h>
#include <stdlib.h>

#include <stddef.h>
#include <ctype.h>
#include <string.h>
#include <math.h>
#include "parser.h"
#include "readinp.h"

#define arr_size 80 
#define MAXLIP 10 
#define CHAINATS 40
 

////////////////////////////////////////////////////////////////////////////
void writejvx(char *dataout, t_2Dgrid *memGD, t_gopts *opts, t_ldat **ldat, t_pdat **pdat, t_memb *memb, rvec**x, matrix box)
{
        int i, jp, jat, lip, prot;
	int j, k;
	int nats;
	int slips;
	int sumprot;
	double xi, yi, zi;
	int uno, dos, tres, cuatro;
	FILE *out = fopen (dataout, "w" );

        nats = opts->np;
        //slips = opts->nlip;     
        slips = memb->slips;
	sumprot = opts->npro;
	// HEADER
	fprintf(out,"<?xml version=\"1.0\" encoding=\"ISO-8859-1\" standalone=\"no\"?>\n");
	fprintf(out,"<jvx-model>\n");
	fprintf(out,"   <title>frame</title>\n");
   	fprintf(out,"<description>\n");
      	fprintf(out,"<abstract>Very difficult 2.5 dimensional surface.</abstract>\n");
	fprintf(out,"       <software>Flux Modeling Package, version 2.0</software>\n");
	fprintf(out,"   </description>\n");
	fprintf(out,"	<geometries>\n");
	// PROTEIN
	/////////////////////////////////////////////////////////////////////////////
        for (prot=0;prot<sumprot;prot++){
             printf("prot= %d\n", prot);

	     fprintf(out,"      <geometry name=\"protein%d\">\n",prot);
	     fprintf(out,"         <pointSet dim=\"5\" point=\"show\">\n");
	     fprintf(out,"            <points>       \n");
             for(jp=0;jp<(*pdat)[prot].npts ;jp++){
                i=(*pdat)[prot].idx[jp];
                xi=(*x)[i][0];
                yi=(*x)[i][1];
                zi=(*x)[i][2];
		fprintf(out,"               <p> %f %f %f </p>\n",xi,yi,zi);
	     }
		fprintf(out,"               <thickness>5</thickness>\n");
	        fprintf(out,"               <color>%d %d  %d</color>\n",200+10*prot, 250-10*prot, prot);
             fprintf(out,"            </points>      \n");
             fprintf(out,"         </pointSet>       \n");
	     fprintf(out,"      </geometry>          \n");
	}
	// LIPID
	// /////////////////////////////////////////////////////////////////////////

	fprintf(out,"      <geometry name=\"lipid centers\">\n");
	fprintf(out,"         <pointSet dim=\"5\" point=\"show\">\n");
	fprintf(out,"            <points>       \n");
        for(jp=0; jp<slips; jp++){
                // i=(*memb).lidx[jp];
                // xi=(*x)[i][0];  yi=(*x)[i][1];  zi=(*x)[i][2];
                xi=(*memb).Tlip[jp][0]; 
		yi=(*memb).Tlip[jp][1]; 
		zi=(*memb).Tlip[jp][2];
		fprintf(out,"               <p> %f %f %f </p>\n", xi, yi, zi);
        }
	fprintf(out,"               <thickness>5</thickness>\n");
	fprintf(out,"            </points>      \n");
	fprintf(out,"         </pointSet>       \n");
	fprintf(out,"      </geometry>          \n");

	// GRID
        // /////////////////////////////////////////////////////////////////////////
     // Top plane
        
	double dimX0, dimY0,delta;
	dimX0=memGD->dimX0;
	dimY0=memGD->dimY0;
	delta=opts->delta;
        //
        fprintf(out,"      <geometry name=\"grid points top-plane\">\n");
        fprintf(out,"         <pointSet dim=\"3\" point=\"show\">\n");
        fprintf(out,"            <points>       \n");
	for (j=0;j<dimX0;j++){ 
	    for(k=0;k<dimY0;k++){
  		xi=j*delta;
                yi=k*delta;
                zi=memGD->gpt[j][k].tAVE;
		fprintf(out,"               <p> %f %f %f </p>\n", xi, yi, zi);
	    }
	}
        fprintf(out,"               <color>0 0 200</color>\n");
	fprintf(out,"               <thickness>1</thickness>\n");
        fprintf(out,"            </points>      \n");
        fprintf(out,"         </pointSet>       \n");
        fprintf(out,"          <faceSet face=\"show\" edge=\"show\">\n");
        fprintf(out,"           <faces>\n");
        for (j=0;j<=dimX0-2;j++){
            for(k=0;k<=dimY0-2;k++){
                uno=j+k*dimX0;
                dos=j+1+k*dimX0;
                tres=j+1+(k+1)*dimX0;
                cuatro=j+(k+1)*dimX0;
                fprintf(out,"               <f> %d %d %d %d </f>\n", uno ,dos, tres, cuatro);
            }
        }
 //       fprintf(out,"               <color>0 255 0</color>\n");
        fprintf(out,"           </faces>\n");
        fprintf(out,"           </faceSet>\n");
 	fprintf(out,"          <material>\n");
        fprintf(out,"         <specular> \n");
        fprintf(out,"             <color type=\"rgb\">255 255 255</color> \n");
        fprintf(out,"         </specular> \n");
 	fprintf(out,"     <transparency visible=\"show\">0.0</transparency>\n");
 	fprintf(out,"      </material> 		\n");
        fprintf(out,"      </geometry>          \n");
      // =========================================
      // Mid plane
      // =========================================
        fprintf(out,"      <geometry name=\"grid points mid-planne\">\n");
        fprintf(out,"         <pointSet dim=\"3\" point=\"show\">\n");
        fprintf(out,"            <points>       \n");
        for (j=0;j<dimX0;j++){
            for(k=0;k<dimY0;k++){
                xi=j*delta;
                yi=k*delta;
                zi=memGD->gpt[j][k].mAVE;
                fprintf(out,"               <p> %f %f %f </p>\n", xi, yi, zi);
            }
        }
        fprintf(out,"               <color>200 200 0</color>\n");
        fprintf(out,"               <thickness>1</thickness>\n");
        fprintf(out,"            </points>      \n");
	// JUST TO PLAY: NORMALS
  	fprintf(out,"			<normals num=\"7\">\n");
        fprintf(out,"                   <n>-0.01826015478832633 0.007992420187430307 -0.9988028227229608</n>\n");
        fprintf(out,"                   <n>-0.011064715659880765 0.004738471999328435 -0.9986841050590959</n>\n");
        fprintf(out,"                   <n>-0.014652189292586494 -5.4469552044274E-4 -0.9985053036976405</n>\n");
        fprintf(out,"                   <n>-0.01642968441557509 -0.006125977636071127 -0.9977723033971474</n>\n");
        fprintf(out,"                   <n>-0.01019231126731757 -0.003810173877382648 -0.9967721283165123</n>\n");
        fprintf(out,"                   <n>-0.01393025717972304 -0.008776747323506471 -0.9972247920001583</n>\n");
 	fprintf(out,"                   <n>-0.018610417188328594 -0.02772385661357008 -0.9978958897457594</n>\n");
        fprintf(out,"                   <thickness>0.8</thickness>\n");
        fprintf(out,"                   <length>1.0</length>\n");
        fprintf(out,"                   <color type=\"rgb\">0 0 255</color> \n");
        fprintf(out,"                   </normals>	\n");
	//
        fprintf(out,"         </pointSet>       \n");
	fprintf(out,"          <faceSet face=\"show\" edge=\"show\">\n");
 	fprintf(out,"           <faces>\n");
        for (j=0;j<=dimX0-2;j++){
            for(k=0;k<=dimY0-2;k++){
		uno=j+k*dimX0;
		dos=j+1+k*dimX0;
		tres=j+1+(k+1)*dimX0;
		cuatro=j+(k+1)*dimX0;
		fprintf(out,"               <f> %d %d %d %d </f>\n", uno ,dos, tres, cuatro);
	    }
	}
        fprintf(out,"               <color>255 0 0</color>\n");
        fprintf(out,"           </faces>\n");
        fprintf(out,"           </faceSet>\n");
        fprintf(out,"      </geometry>          \n");
     // =====================
     // Down plane
     // =====================
        fprintf(out,"      <geometry name=\"grid points down-plane\">\n");
        fprintf(out,"         <pointSet dim=\"3\" point=\"show\">\n");
        fprintf(out,"            <points>       \n");
        for (j=0;j<dimX0;j++){
            for(k=0;k<dimY0;k++){
                xi=j*delta;
                yi=k*delta;
                zi=memGD->gpt[j][k].dAVE;
                fprintf(out,"               <p> %f %f %f </p>\n", xi, yi, zi);
            }
        }
	fprintf(out,"		    <color>0 200 0</color>\n");
        fprintf(out,"               <thickness>1</thickness>\n");
        fprintf(out,"            </points>      \n");
        fprintf(out,"         </pointSet>       \n");
        fprintf(out,"          <faceSet face=\"show\" edge=\"show\">\n");
        fprintf(out,"           <faces>\n");
        for (j=0;j<=dimX0-2;j++){
            for(k=0;k<=dimY0-2;k++){
                uno=j+k*dimX0;
                dos=j+1+k*dimX0;
                tres=j+1+(k+1)*dimX0;
                cuatro=j+(k+1)*dimX0;
                fprintf(out,"               <f> %d %d %d %d </f>\n", uno ,dos, tres, cuatro);
            }
        }
//        fprintf(out,"               <color>0 255 0</color>\n");
        fprintf(out,"           </faces>\n");
        fprintf(out,"           </faceSet>\n");
	fprintf(out,"      <material>      	\n");
        fprintf(out,"         <specular> \n");
        fprintf(out,"            <color type=\"rgb\">255 255 255</color> \n");
        fprintf(out,"         </specular> \n");
        fprintf(out,"     <transparency visible=\"show\">0.0</transparency>\n");
        fprintf(out,"      </material>          \n");
        fprintf(out,"      </geometry>          \n");

	// BOX
	// //////////////////////////////////////////////////////////////////////////
        fprintf(out,"      <geometry name=\"case\">\n");
        fprintf(out,"         <pointSet dim=\"3\" point=\"hide\">\n");
	fprintf(out,"            <points>	\n");
	fprintf(out,"               <p> %f %f %f </p>\n", 0.0      , 0.0      , 0.0);
        fprintf(out,"               <p> %f %f %f </p>\n", box[0][0], 0.0      , 0.0);
        fprintf(out,"               <p> %f %f %f </p>\n", box[0][0], box[1][1], 0.0);
        fprintf(out,"               <p> %f %f %f </p>\n", 0.0      , box[1][1], 0.0);
        fprintf(out,"               <p> %f %f %f </p>\n", 0.0      , 0.0      , box[2][2]);
        fprintf(out,"               <p> %f %f %f </p>\n", box[0][0], 0.0      , box[2][2]);
        fprintf(out,"               <p> %f %f %f </p>\n", box[0][0], box[1][1], box[2][2]);
        fprintf(out,"               <p> %f %f %f </p>\n", 0.0      , box[1][1], box[2][2]);
	fprintf(out,"            </points>	\n");
        fprintf(out,"         </pointSet>	\n");
        fprintf(out,"         <lineSet line=\"show\">\n");
        fprintf(out,"            <lines> 	\n");
        fprintf(out,"               <l>0 1</l>	\n");
        fprintf(out,"               <l>1 2</l>	\n");
        fprintf(out,"               <l>2 3</l>	\n");
        fprintf(out,"               <l>3 0</l>	\n");
        fprintf(out,"               <l>0 4</l>	\n");
        fprintf(out,"               <l>1 5</l>	\n");
        fprintf(out,"               <l>2 6</l>	\n");
        fprintf(out,"               <l>3 7</l>	\n");
        fprintf(out,"               <l>4 5</l>	\n");
        fprintf(out,"               <l>5 6</l>	\n");
        fprintf(out,"               <l>6 7</l>	\n");
        fprintf(out,"               <l>7 4</l>	\n");
        fprintf(out,"               <color>0 0 0</color> \n");
        fprintf(out,"            </lines>	\n");
        fprintf(out,"         </lineSet>	\n");
        fprintf(out,"      </geometry>		\n");
	//
	fprintf(out,"   </geometries>\n");
	fprintf(out,"</jvx-model>\n");

	fclose(out);
 

}


////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

void writejvxtick(char *dataout, t_2Dgrid *memGD, t_gopts *opts, t_ldat **ldat, t_pdat **pdat, t_memb *memb, rvec**x, matrix box)
{
        int i, jp, jat, lip, prot;
	int j, k;
	int nats;
	int slips;
	int sumprot;
	double xi, yi, zi;
	int uno, dos, tres, cuatro;
	double dimX0, dimY0,delta;



        nats = opts->np;
        //slips = opts->nlip;     
        slips = memb->slips;
	sumprot = opts->npro;

	FILE *out_m1 = fopen ("t1.jvx","w");
	FILE *out_m2 = fopen ("t2.jvx","w");
	FILE *out_m2m1=fopen("t12.jvx","w");
 
	FILE *out_t1 = fopen ("t1.dat","w");
	FILE *out_t2 = fopen ("t2.dat","w");
	FILE *out_t21= fopen("t12.dat","w");
	


	// HEADER
	fprintf(out_m1,"<?xml version=\"1.0\" encoding=\"ISO-8859-1\" standalone=\"no\"?>\n");
	fprintf(out_m1,"<jvx-model>\n");
	fprintf(out_m1,"   <title>monotichness 1</title>\n");
   	fprintf(out_m1,"<description>\n");
      	fprintf(out_m1,"<abstract>Very difficult 2.5 dimensional surface.</abstract>\n");
	fprintf(out_m1,"       <software>Flux Modeling Package, version 2.0</software>\n");
	fprintf(out_m1,"   </description>\n");
	fprintf(out_m1,"	<geometries>\n");
	// PROTEIN
	/////////////////////////////////////////////////////////////////////////////
        for (prot=0;prot<sumprot;prot++){
             printf("prot= %d\n", prot);

	     fprintf(out_m1,"      <geometry name=\"protein%d\">\n",prot);
	     fprintf(out_m1,"         <pointSet dim=\"5\" point=\"show\">\n");
	     fprintf(out_m1,"            <points>       \n");
             for(jp=0;jp<(*pdat)[prot].npts ;jp++){
                i=(*pdat)[prot].idx[jp];
                xi=(*x)[i][0];
                yi=(*x)[i][1];
                zi=(*x)[i][2];
		fprintf(out_m1,"               <p> %f %f %f </p>\n",xi,yi,zi);
	     }
		fprintf(out_m1,"               <thickness>5</thickness>\n");
	        fprintf(out_m1,"               <color>%d %d  %d</color>\n",200+10*prot, 250-10*prot, prot);
             fprintf(out_m1,"            </points>      \n");
             fprintf(out_m1,"         </pointSet>       \n");
	     fprintf(out_m1,"      </geometry>          \n");
	}



	// GRID
        // /////////////////////////////////////////////////////////////////////////
	// Top plane tickness
        

	dimX0=memGD->dimX0;
	dimY0=memGD->dimY0;
	delta=opts->delta;
        //

	// ======================================================================
	// ======================================================================
	// 	TOP LEAFLET TICKNESS
	// ======================================================================
	// ======================================================================

        fprintf(out_m1,"      <geometry name=\"grid points top-plane tickness\">\n");
        fprintf(out_m1,"         <pointSet dim=\"3\" point=\"show\">\n");
        fprintf(out_m1,"            <points>       \n");
        for (j=0;j<dimX0;j++){
            for(k=0;k<dimY0;k++){
                xi=j*delta;
                yi=k*delta;
                //zi=memGD->gpt[j][k].dAVE;
		zi=memGD->gpt[j][k].m1tickAVE;
                fprintf(out_m1,"               <p> %f %f %f </p>\n", xi, yi, zi);
            }
        }
	fprintf(out_m1,"		    <color>0 200 0</color>\n");
        fprintf(out_m1,"               <thickness>1</thickness>\n");
        fprintf(out_m1,"            </points>      \n");
        fprintf(out_m1,"         </pointSet>       \n");
        fprintf(out_m1,"          <faceSet face=\"show\" edge=\"show\">\n");
        fprintf(out_m1,"           <faces>\n");
        for (j=0;j<=dimX0-2;j++){
            for(k=0;k<=dimY0-2;k++){
                uno=j+k*dimX0;
                dos=j+1+k*dimX0;
                tres=j+1+(k+1)*dimX0;
                cuatro=j+(k+1)*dimX0;
                fprintf(out_m1,"               <f> %d %d %d %d </f>\n", uno ,dos, tres, cuatro);
            }
        }
//        fprintf(out_m1,"               <color>0 255 0</color>\n");
        fprintf(out_m1,"           </faces>\n");
        fprintf(out_m1,"           </faceSet>\n");
	fprintf(out_m1,"      <material>      	\n");
        fprintf(out_m1,"         <specular> \n");
        fprintf(out_m1,"            <color type=\"rgb\">255 255 255</color> \n");
        fprintf(out_m1,"         </specular> \n");
   //     fprintf(out_m1,"     <transparency visible=\"show\">0.5</transparency>\n");
        fprintf(out_m1,"      </material>          \n");
        fprintf(out_m1,"      </geometry>          \n");

	// BOX
	// //////////////////////////////////////////////////////////////////////////
        fprintf(out_m1,"      <geometry name=\"case\">\n");
        fprintf(out_m1,"         <pointSet dim=\"3\" point=\"hide\">\n");
	fprintf(out_m1,"            <points>	\n");
	fprintf(out_m1,"               <p> %f %f %f </p>\n", 0.0      , 0.0      , 0.0);
        fprintf(out_m1,"               <p> %f %f %f </p>\n", box[0][0], 0.0      , 0.0);
        fprintf(out_m1,"               <p> %f %f %f </p>\n", box[0][0], box[1][1], 0.0);
        fprintf(out_m1,"               <p> %f %f %f </p>\n", 0.0      , box[1][1], 0.0);
        fprintf(out_m1,"               <p> %f %f %f </p>\n", 0.0      , 0.0      , box[2][2]);
        fprintf(out_m1,"               <p> %f %f %f </p>\n", box[0][0], 0.0      , box[2][2]);
        fprintf(out_m1,"               <p> %f %f %f </p>\n", box[0][0], box[1][1], box[2][2]);
        fprintf(out_m1,"               <p> %f %f %f </p>\n", 0.0      , box[1][1], box[2][2]);
	fprintf(out_m1,"            </points>	\n");
        fprintf(out_m1,"         </pointSet>	\n");
        fprintf(out_m1,"         <lineSet line=\"show\">\n");
        fprintf(out_m1,"            <lines> 	\n");
        fprintf(out_m1,"               <l>0 1</l>	\n");
        fprintf(out_m1,"               <l>1 2</l>	\n");
        fprintf(out_m1,"               <l>2 3</l>	\n");
        fprintf(out_m1,"               <l>3 0</l>	\n");
        fprintf(out_m1,"               <l>0 4</l>	\n");
        fprintf(out_m1,"               <l>1 5</l>	\n");
        fprintf(out_m1,"               <l>2 6</l>	\n");
        fprintf(out_m1,"               <l>3 7</l>	\n");
        fprintf(out_m1,"               <l>4 5</l>	\n");
        fprintf(out_m1,"               <l>5 6</l>	\n");
        fprintf(out_m1,"               <l>6 7</l>	\n");
        fprintf(out_m1,"               <l>7 4</l>	\n");
        fprintf(out_m1,"               <color>0 0 0</color> \n");
        fprintf(out_m1,"            </lines>	\n");
        fprintf(out_m1,"         </lineSet>	\n");
        fprintf(out_m1,"      </geometry>		\n");
	//
	fprintf(out_m1,"   </geometries>\n");
	fprintf(out_m1,"</jvx-model>\n");

	fclose(out_m1);

	// m1 dat changed name to:
	// t1 dat t for thickness
	// The idea is to create a .dat format file. First plot the row. Element 0,0 has value 0
	// first row is X axis. Column 0 is used for axis Y labels. 
	// Place first row
	fprintf(out_t1," 0.00");
	for (j=0;j<dimX0;j++){ xi=j*delta; fprintf(out_t1," %5.2f", xi); };
	fprintf(out_t1,"\n");

	int flag;
	flag=0;
	for(k=0;k<dimY0;k++){
	 
           for (j=0;j<dimX0;j++){ 	

                xi=j*delta;
                yi=k*delta;
		zi=memGD->gpt[j][k].m1tickAVE;
		if(flag==0) { fprintf(out_t1,"%5.2f ", yi); flag=1;}; // Only print Y value at beginning of row
		fprintf(out_t1," %6.3f",zi);
           }
	   flag=0;
	   fprintf(out_t1,"\n");
        }
	fclose(out_t1);
	// ======================================================================
	// ======================================================================
	// 	LOWER LEAFLET TICKNESS
	// ======================================================================
	// ======================================================================


	// HEADER
	fprintf(out_m2,"<?xml version=\"1.0\" encoding=\"ISO-8859-1\" standalone=\"no\"?>\n");
	fprintf(out_m2,"<jvx-model>\n");
	fprintf(out_m2,"   <title>monotichness 1</title>\n");
   	fprintf(out_m2,"<description>\n");
      	fprintf(out_m2,"<abstract>Very difficult 2.5 dimensional surface.</abstract>\n");
	fprintf(out_m2,"       <software>Flux Modeling Package, version 2.0</software>\n");
	fprintf(out_m2,"   </description>\n");
	fprintf(out_m2,"	<geometries>\n");
	// PROTEIN
	/////////////////////////////////////////////////////////////////////////////
        for (prot=0;prot<sumprot;prot++){
             printf("prot= %d\n", prot);

	     fprintf(out_m2,"      <geometry name=\"protein%d\">\n",prot);
	     fprintf(out_m2,"         <pointSet dim=\"5\" point=\"show\">\n");
	     fprintf(out_m2,"            <points>       \n");
             for(jp=0;jp<(*pdat)[prot].npts ;jp++){
                i=(*pdat)[prot].idx[jp];
                xi=(*x)[i][0];
                yi=(*x)[i][1];
                zi=(*x)[i][2];
		fprintf(out_m2,"               <p> %f %f %f </p>\n",xi,yi,zi);
	     }
		fprintf(out_m2,"               <thickness>5</thickness>\n");
	        fprintf(out_m2,"               <color>%d %d  %d</color>\n",200+10*prot, 250-10*prot, prot);
             fprintf(out_m2,"            </points>      \n");
             fprintf(out_m2,"         </pointSet>       \n");
	     fprintf(out_m2,"      </geometry>          \n");
	}

	// GRID
        // /////////////////////////////////////////////////////////////////////////
  
     // =====================
     // Down plane
     // =====================
        fprintf(out_m2,"      <geometry name=\"grid points down-plane\">\n");
        fprintf(out_m2,"         <pointSet dim=\"3\" point=\"show\">\n");
        fprintf(out_m2,"            <points>       \n");
        for (j=0;j<dimX0;j++){
            for(k=0;k<dimY0;k++){
                xi=j*delta;
                yi=k*delta;
                zi=memGD->gpt[j][k].m2tickAVE;
                fprintf(out_m2,"               <p> %f %f %f </p>\n", xi, yi, zi);
            }
        }
	fprintf(out_m2,"		    <color>0 200 0</color>\n");
        fprintf(out_m2,"               <thickness>1</thickness>\n");
        fprintf(out_m2,"            </points>      \n");
        fprintf(out_m2,"         </pointSet>       \n");
        fprintf(out_m2,"          <faceSet face=\"show\" edge=\"show\">\n");
        fprintf(out_m2,"           <faces>\n");
        for (j=0;j<=dimX0-2;j++){
            for(k=0;k<=dimY0-2;k++){
                uno=j+k*dimX0;
                dos=j+1+k*dimX0;
                tres=j+1+(k+1)*dimX0;
                cuatro=j+(k+1)*dimX0;
                fprintf(out_m2,"               <f> %d %d %d %d </f>\n", uno ,dos, tres, cuatro);
            }
        }
//        fprintf(out_m2,"               <color>0 255 0</color>\n");
        fprintf(out_m2,"           </faces>\n");
        fprintf(out_m2,"           </faceSet>\n");
	fprintf(out_m2,"      <material>      	\n");
        fprintf(out_m2,"         <specular> \n");
        fprintf(out_m2,"            <color type=\"rgb\">255 255 255</color> \n");
        fprintf(out_m2,"         </specular> \n");
    //    fprintf(out_m2,"     <transparency visible=\"show\">0.5</transparency>\n");
        fprintf(out_m2,"      </material>          \n");
        fprintf(out_m2,"      </geometry>          \n");

	// BOX
	// //////////////////////////////////////////////////////////////////////////
        fprintf(out_m2,"      <geometry name=\"case\">\n");
        fprintf(out_m2,"         <pointSet dim=\"3\" point=\"hide\">\n");
	fprintf(out_m2,"            <points>	\n");
	fprintf(out_m2,"               <p> %f %f %f </p>\n", 0.0      , 0.0      , 0.0);
        fprintf(out_m2,"               <p> %f %f %f </p>\n", box[0][0], 0.0      , 0.0);
        fprintf(out_m2,"               <p> %f %f %f </p>\n", box[0][0], box[1][1], 0.0);
        fprintf(out_m2,"               <p> %f %f %f </p>\n", 0.0      , box[1][1], 0.0);
        fprintf(out_m2,"               <p> %f %f %f </p>\n", 0.0      , 0.0      , box[2][2]);
        fprintf(out_m2,"               <p> %f %f %f </p>\n", box[0][0], 0.0      , box[2][2]);
        fprintf(out_m2,"               <p> %f %f %f </p>\n", box[0][0], box[1][1], box[2][2]);
        fprintf(out_m2,"               <p> %f %f %f </p>\n", 0.0      , box[1][1], box[2][2]);
	fprintf(out_m2,"            </points>	\n");
        fprintf(out_m2,"         </pointSet>	\n");
        fprintf(out_m2,"         <lineSet line=\"show\">\n");
        fprintf(out_m2,"            <lines> 	\n");
        fprintf(out_m2,"               <l>0 1</l>	\n");
        fprintf(out_m2,"               <l>1 2</l>	\n");
        fprintf(out_m2,"               <l>2 3</l>	\n");
        fprintf(out_m2,"               <l>3 0</l>	\n");
        fprintf(out_m2,"               <l>0 4</l>	\n");
        fprintf(out_m2,"               <l>1 5</l>	\n");
        fprintf(out_m2,"               <l>2 6</l>	\n");
        fprintf(out_m2,"               <l>3 7</l>	\n");
        fprintf(out_m2,"               <l>4 5</l>	\n");
        fprintf(out_m2,"               <l>5 6</l>	\n");
        fprintf(out_m2,"               <l>6 7</l>	\n");
        fprintf(out_m2,"               <l>7 4</l>	\n");
        fprintf(out_m2,"               <color>0 0 0</color> \n");
        fprintf(out_m2,"            </lines>	\n");
        fprintf(out_m2,"         </lineSet>	\n");
        fprintf(out_m2,"      </geometry>		\n");
	//
	fprintf(out_m2,"   </geometries>\n");
	fprintf(out_m2,"</jvx-model>\n");

	fclose(out_m2);

	// /////////////////////////////////////////////////////////////////////////////////
	// m1 dat changed name to:
	// t1 dat t for thickness
	// The idea is to create a .dat format file. First plot the row. Element 0,0 has value 0
	// first row is X axis. Column 0 is used for axis Y labels. 
	// Place first row
	fprintf(out_t2," 0.00");
	for (j=0;j<dimX0;j++){ xi=j*delta; fprintf(out_t2," %7.4f", xi); };
	fprintf(out_t2,"\n");

	flag=0;
	for(k=0;k<dimY0;k++){
	 
           for (j=0;j<dimX0;j++){ 	

                xi=j*delta;
                yi=k*delta;
		zi=memGD->gpt[j][k].m2tickAVE;
		if(flag==0) { fprintf(out_t2,"%7.4f ", yi); flag=1;}; // Only print Y value at beginning of row
		fprintf(out_t2," %7.4f",zi);
           }
	   flag=0;
	   fprintf(out_t2,"\n");
        }
	fclose(out_t2);

	//
	// /////////////////////////////////////////////////////////////////////////////////


	// HEADER
	fprintf(out_m2m1,"<?xml version=\"1.0\" encoding=\"ISO-8859-1\" standalone=\"no\"?>\n");
	fprintf(out_m2m1,"<jvx-model>\n");
	fprintf(out_m2m1,"   <title>monotichness 1</title>\n");
   	fprintf(out_m2m1,"<description>\n");
      	fprintf(out_m2m1,"<abstract>Very difficult 2.5 dimensional surface.</abstract>\n");
	fprintf(out_m2m1,"       <software>Flux Modeling Package, version 2.0</software>\n");
	fprintf(out_m2m1,"   </description>\n");
	fprintf(out_m2m1,"	<geometries>\n");
	// PROTEIN
	/////////////////////////////////////////////////////////////////////////////
        for (prot=0;prot<sumprot;prot++){
             printf("prot= %d\n", prot);

	     fprintf(out_m2m1,"      <geometry name=\"protein%d\">\n",prot);
	     fprintf(out_m2m1,"         <pointSet dim=\"5\" point=\"show\">\n");
	     fprintf(out_m2m1,"            <points>       \n");
             for(jp=0;jp<(*pdat)[prot].npts ;jp++){
                i=(*pdat)[prot].idx[jp];
                xi=(*x)[i][0];
                yi=(*x)[i][1];
                zi=(*x)[i][2];
		fprintf(out_m2m1,"               <p> %f %f %f </p>\n",xi,yi,zi);
	     }
		fprintf(out_m2m1,"               <thickness>5</thickness>\n");
	        fprintf(out_m2m1,"               <color>%d %d  %d</color>\n",200+10*prot, 250-10*prot, prot);
             fprintf(out_m2m1,"            </points>      \n");
             fprintf(out_m2m1,"         </pointSet>       \n");
	     fprintf(out_m2m1,"      </geometry>          \n");
	}
 

	// ======================================================================
	// ======================================================================
	// 	BILAYER TICKNESS
	// ======================================================================
	// ======================================================================

        fprintf(out_m2m1,"      <geometry name=\"grid points bilayer tickness\">\n");
        fprintf(out_m2m1,"         <pointSet dim=\"3\" point=\"show\">\n");
        fprintf(out_m2m1,"            <points>       \n");
        for (j=0;j<dimX0;j++){
            for(k=0;k<dimY0;k++){
                xi=j*delta;
                yi=k*delta;
		// Sum of thickness for top and bottom leaflets
		zi=memGD->gpt[j][k].m1tickAVE + memGD->gpt[j][k].m2tickAVE;
                fprintf(out_m2m1,"               <p> %f %f %f </p>\n", xi, yi, zi);
            }
        }
	fprintf(out_m2m1,"		    <color>0 200 0</color>\n");
        fprintf(out_m2m1,"               <thickness>1</thickness>\n");
        fprintf(out_m2m1,"            </points>      \n");
        fprintf(out_m2m1,"         </pointSet>       \n");
        fprintf(out_m2m1,"          <faceSet face=\"show\" edge=\"show\">\n");
        fprintf(out_m2m1,"           <faces>\n");
        for (j=0;j<=dimX0-2;j++){
            for(k=0;k<=dimY0-2;k++){
                uno=j+k*dimX0;
                dos=j+1+k*dimX0;
                tres=j+1+(k+1)*dimX0;
                cuatro=j+(k+1)*dimX0;
                fprintf(out_m2m1,"               <f> %d %d %d %d </f>\n", uno ,dos, tres, cuatro);
            }
        }
//        fprintf(out_m2m1,"               <color>0 255 0</color>\n");
        fprintf(out_m2m1,"           </faces>\n");
        fprintf(out_m2m1,"           </faceSet>\n");
	fprintf(out_m2m1,"      <material>      	\n");
        fprintf(out_m2m1,"         <specular> \n");
        fprintf(out_m2m1,"            <color type=\"rgb\">255 255 255</color> \n");
        fprintf(out_m2m1,"         </specular> \n");
  //      fprintf(out_m2m1,"     <transparency visible=\"show\">0.5</transparency>\n");
        fprintf(out_m2m1,"      </material>          \n");
        fprintf(out_m2m1,"      </geometry>          \n");

	// BOX
	// //////////////////////////////////////////////////////////////////////////
        fprintf(out_m2m1,"      <geometry name=\"case\">\n");
        fprintf(out_m2m1,"         <pointSet dim=\"3\" point=\"hide\">\n");
	fprintf(out_m2m1,"            <points>	\n");
	fprintf(out_m2m1,"               <p> %f %f %f </p>\n", 0.0      , 0.0      , 0.0);
        fprintf(out_m2m1,"               <p> %f %f %f </p>\n", box[0][0], 0.0      , 0.0);
        fprintf(out_m2m1,"               <p> %f %f %f </p>\n", box[0][0], box[1][1], 0.0);
        fprintf(out_m2m1,"               <p> %f %f %f </p>\n", 0.0      , box[1][1], 0.0);
        fprintf(out_m2m1,"               <p> %f %f %f </p>\n", 0.0      , 0.0      , box[2][2]);
        fprintf(out_m2m1,"               <p> %f %f %f </p>\n", box[0][0], 0.0      , box[2][2]);
        fprintf(out_m2m1,"               <p> %f %f %f </p>\n", box[0][0], box[1][1], box[2][2]);
        fprintf(out_m2m1,"               <p> %f %f %f </p>\n", 0.0      , box[1][1], box[2][2]);
	fprintf(out_m2m1,"            </points>	\n");
        fprintf(out_m2m1,"         </pointSet>	\n");
        fprintf(out_m2m1,"         <lineSet line=\"show\">\n");
        fprintf(out_m2m1,"            <lines> 	\n");
        fprintf(out_m2m1,"               <l>0 1</l>	\n");
        fprintf(out_m2m1,"               <l>1 2</l>	\n");
        fprintf(out_m2m1,"               <l>2 3</l>	\n");
        fprintf(out_m2m1,"               <l>3 0</l>	\n");
        fprintf(out_m2m1,"               <l>0 4</l>	\n");
        fprintf(out_m2m1,"               <l>1 5</l>	\n");
        fprintf(out_m2m1,"               <l>2 6</l>	\n");
        fprintf(out_m2m1,"               <l>3 7</l>	\n");
        fprintf(out_m2m1,"               <l>4 5</l>	\n");
        fprintf(out_m2m1,"               <l>5 6</l>	\n");
        fprintf(out_m2m1,"               <l>6 7</l>	\n");
        fprintf(out_m2m1,"               <l>7 4</l>	\n");
        fprintf(out_m2m1,"               <color>0 0 0</color> \n");
        fprintf(out_m2m1,"            </lines>	\n");
        fprintf(out_m2m1,"         </lineSet>	\n");
        fprintf(out_m2m1,"      </geometry>		\n");
	//
	fprintf(out_m2m1,"   </geometries>\n");
	fprintf(out_m2m1,"</jvx-model>\n");

	fclose(out_m2m1);

 

	// ###############################################################################################
	fprintf(out_t21," 0.00");
	for (j=0;j<dimX0;j++){ xi=j*delta; fprintf(out_t21," %5.2f", xi); };
	fprintf(out_t21,"\n");

	flag=0;
	for(k=0;k<dimY0;k++){
	 
           for (j=0;j<dimX0;j++){ 	

                xi = j*delta;
                yi = k*delta;
		zi = memGD->gpt[j][k].m1tickAVE + memGD->gpt[j][k].m2tickAVE;
		if(flag==0) { fprintf(out_t21,"%5.2f ", yi); flag=1;}; // Only print Y value at beginning of row
		fprintf(out_t21," %5.2f",zi);
           }
	   flag=0;
	   fprintf(out_t21,"\n");
        }
	fclose(out_t21);
	// ###############################################################################################




}

