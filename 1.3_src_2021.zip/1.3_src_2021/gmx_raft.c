/*
 * 
 *                This source code is part of
 * 
 *                 G   R   O   M   A   C   S
 * 
 *          GROningen MAchine for Chemical Simulations
 * 
 *                        VERSION 3.2.0
 * Written by David van der Spoel, Erik Lindahl, Berk Hess, and others.
 * Copyright (c) 1991-2000, University of Groningen, The Netherlands.
 * Copyright (c) 2001-2004, The GROMACS development team,
 * check out http://www.gromacs.org for more information.

 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * If you want to redistribute modifications, please consider that
 * scientific software is very special. Version control is crucial -
 * bugs must be traceable. We will be happy to consider code for
 * inclusion in the official distribution, but derived work must not
 * be called official GROMACS. Details are found in the README & COPYING
 * files - if they are missing, get the official version at www.gromacs.org.
 * 
 * To help us fund GROMACS development, we humbly ask that you cite
 * the papers on the package - you can find them in the top README file.
 * 
 * For more info, check our website at http://www.gromacs.org
 * 
 * And Hey:
 * Green Red Orange Magenta Azure Cyan Skyblue
 */
#ifdef HAVE_CONFIG_H
#include <config.h>
#endif
#include <typedefs.h>

//EDUX extra
/* #include "sysstuff.h"
#include "smalloc.h"
#include "macros.h"
#include "string2.h"
#include "Greadir.h"
#include "toputil.h"

#include "topio.h"
#include "confio.h"
#include "copyrite.h"
#include "Greadir.h"
//EDUX
*/
//#include "Greadir.h"

#include "xtcio.h"

#include "smalloc.h"
#include "macros.h"
#include "math.h"
#include "xvgr.h"
#include "copyrite.h"
#include "statutil.h"
#include "string2.h"
#include "vec.h"
#include "index.h"
//#include "Greadir.h"
#include "pbc.h"
#include "gmx_fatal.h"
#include "futil.h"
#include "gstat.h"
// #include "gmx_ana.h"
#ifndef _gmx_ana_h
#define _gmx_ana_h

#include "parser.h"

#ifdef __cplusplus
extern "C" {
#endif
 
extern t_gopts get_gopts(const char *mdparin,const char *mdparout);
extern t_ldat *get_ldat(const char *mdparin,const char *mdparout, t_gopts *opts);
extern t_pdat *get_pdat(const char *mdparin,const char *mdparout, t_gopts *opts);
extern t_2Dgrid def_2Dgrid(t_gopts *opts, matrix box);
extern t_2Dsums def_2DsumsGD(t_gopts *opts, matrix box);

extern t_memb def_memb(t_gopts *opts, t_ldat **ldat, t_atoms *atoms);
extern void calc_GDframe(t_2Dsums *sumsGD,t_memb *memb,t_ldat **ldat, t_atoms *atoms, rvec **x, t_gopts *opts,matrix box);
//extern void calc_GDsurf(t_2Dgrid *memGD, t_2Dsums *sumsGD,  t_memb *memb, t_ldat **ldat, t_pdat **pdat, t_atoms *atoms, rvec **x, t_gopts *opts, matrix box);
t_2Dgrid calc_GDstats(t_2Dsums *sumsGD,  t_memb *memb, t_ldat **ldat, t_pdat **pdat, t_atoms *atoms, rvec **x, t_gopts *opts, matrix box);
// DENSITY SUBROUTINES
extern t_3Dsums def_3DsumsGD(t_gopts *opts, matrix box);
extern t_3Dstats def_3DstatsGD(t_gopts *opts, matrix box);
extern void calc_3DGDframe(t_3Dsums *sums3DGD,t_memb *memb,t_ldat **ldat,t_pdat **pdat,t_atoms *atoms,rvec **x,t_gopts *opts,matrix box);
extern void calc_3DGDstats(t_3Dstats *stats3DGD,t_3Dsums *sums3DGD,t_memb *memb,t_ldat **ldat,t_pdat **pdat,t_atoms *atoms,rvec **x,t_gopts *opts, matrix box);
//
extern void ldatextra(t_gopts *opts,t_ldat **ldat, t_atoms *atoms);
extern void memspace(t_gopts *opts,t_ldat **ldat, t_atoms *atoms, t_memb *memb);
extern void protspace(t_gopts *opts,t_pdat **pdat, t_atoms *atoms);
extern double cost(rvec *v1, rvec *v2);
//extern void memRemoveZpbc(t_gopts *opts, t_ldat **ldat, t_memb *memb, t_atoms *atoms, rvec **x, matrix box);
extern void memRemoveZpbc(t_gopts *opts, t_ldat **ldat, t_memb *memb, rvec **x, matrix box);


int gmx_voro2D(int argc,char *argv[]);

#ifdef __cplusplus
}
#endif
#endif
/* _gmx_ana_h */


static void add_contact_time(int **ccount,int *ccount_nalloc,int t) {
  int i;

  if (t+2 >= *ccount_nalloc) {
    srenew(*ccount,t+2);
    for(i=*ccount_nalloc; i<t+2; i++)
      (*ccount)[i] = 0;
    *ccount_nalloc = t+2;
  }
  (*ccount)[t]++;
}

int gmx_raft(int argc,char *argv[])
{
  const char *desc[] = {
    "[TT]g_raft[tt] calculates the voronoi thingy",
    "and [TT]g_bond[tt]."
  };
  
  t_topology *top=NULL;
  int  ePBC;
  real t,t0,cut2,dist2;
  rvec *x=NULL,*v=NULL,dx;
  matrix box;
  t_trxstatus *status;
  int natoms;

  int g,d,i,j,k,res,teller=0;
  atom_id aid;
 
  int     ngrps;     /* the number of index groups */
  atom_id **index,max;   /* the index for the atom numbers */
  int     *isize;    /* the size of each group */
  char    **grpname; /* the name of each group */
  rvec    *com;
  real    *mass;
  FILE    *fp=NULL,*fplt=NULL;
  gmx_bool    bCutoff,bPrintDist,bLifeTime;
  t_pbc   *pbc;
  int     *contact_time=NULL,*ccount=NULL,ccount_nalloc=0,sum;
  char    buf[STRLEN];
  output_env_t oenv;
  gmx_rmpbc_t  gpbc=NULL;
 
	int frame1st, framelast, framestride;
	int frcount;
// EDUX Extra variables
  const char *mdparin, *mdparout;
  t_inputrec   *ir;
  t_ldat	*ldat;
  t_pdat	*pdat;
  t_gopts opts;
  t_memb memb;
  t_memb *membrane;	
 
  t_2Dsums sumsGD;
  t_2Dgrid  memGD;

  t_3Dsums sums3DGD;
  t_3Dstats stats3DGD;

// EDUX
  gmx_bool    bTRX;  
  char    title[STRLEN];
  int nres;

  t_fileio *xd;
  int indent;
  int    nframe,step;
  real   prec,time;
  gmx_bool   bOK;
  const char *fn;
  gmx_bool bXVG;
  char    *resnm,*atnm;
  t_atoms *atoms, *useatoms;
//  t_surf surf;
  int density;

  static     gmx_bool bVerbose=FALSE;
  static     gmx_bool bPROT=FALSE; 	// Do we have protein?

  const char *leg[4] = { "|d|","d\\sx\\N","d\\sy\\N","d\\sz\\N" };

  static real cut=0;
  
  static t_pargs pa[] = {
    { "-v", FALSE, etBOOL, {&bVerbose},
          "Be loud and noisy." },
    { "-dist",      FALSE, etREAL, {&cut},
      "Print all atoms in group 2 closer than dist to the center of mass of group 1" }
  };
#define NPA asize(pa)
  t_filenm fnm[] = {
    { efMDP, "-f", NULL, ffREAD },
    { efMDP, "-po", "mdout", ffWRITE },
    { efSTX, "-c", "conf", ffREAD  },
    { efTRX, "-tr",NULL,  ffOPTRD },
    { efXVG, "-lt", "lifetime", ffOPTWR },
    { efSTO, "-o", "out",  ffWRITE },
 };
#define NFILE asize(fnm)

  CopyRight(stderr,argv[0]);

// Parse common args
  parse_common_args(&argc,argv,PCA_CAN_TIME | PCA_BE_NICE,
		    NFILE,fnm,NPA,pa,asize(desc),desc,0,NULL,&oenv);
  bCutoff = opt2parg_bSet("-dist",NPA,pa);

  // EDUX Options printed now
  /* PARAMETER file processing */
  mdparin = opt2fn("-f",NFILE,fnm);
  mdparout = opt2fn("-po",NFILE,fnm);
  printf("Loading Input file %s \n",mdparin);
  printf("Check parameters used at output file %s \n",mdparout);

  printf("Parse input file\n");

 //get_input(mdparin,mdparout,&gopts,&ldat,&pdat);

  opts=get_gopts(mdparin,mdparout);
  
  ldat=get_ldat(mdparin,mdparout,&opts);

  pdat=get_pdat(mdparin,mdparout,&opts);

  if(opts.npro > 0) bPROT=TRUE ; // GNAT

  if (bVerbose) printf("Input file %s parsed\n",mdparin);

/*
  for(j=0;j<3;j++){
	printf("Lipid name %s \n", ldat[j].lname );
	printf("Number of elements %d \n", ldat[j].natxl);
  }
*/
  // PRINT IF YOU WANT
/*
  printf(" Number of prots %d\n ",opts.npro);
  for (j=0;j<opts.npro;j++){
	printf("Lipid %s; %s =[%d, %d]\n", pdat[j].pname, pdat[j].bn ,pdat[j].fa, pdat[j].la );
  }
*/
  
//  set_warning_line(0,mdparin,-1);
  //get_ir(mdparin,opt2fn("-po",NFILE,fnm),ir,opts,0);

  /*
  cut2 = cut*cut;
  bLifeTime = opt2bSet("-lt",NFILE,fnm);
  bPrintDist = (bCutoff && !bLifeTime);
  */  

  /* read top file */
  //top=read_top(ftp2fn(efTPX,NFILE,fnm),&ePBC);
 
  get_stx_coordnum(opt2fn("-c",NFILE,fnm),&natoms);

  opts.np = natoms;

  snew(atoms,1);

  init_t_atoms(atoms,natoms,FALSE);

 /* make space for all the atoms */
  snew(x,natoms);              /* get space for coordinates of all atoms */
  snew(v,natoms);              /* velocities. not really needed? */ 

  atnm=strdup("C");
  resnm=strdup("PRJ");
        
  /* set atoms->nr to the number in one box *
   * to avoid complaints in read_stx_conf   *
   */
  read_stx_conf(opt2fn("-c",NFILE,fnm),title,atoms,x,v,&ePBC,box);

  //printf("%s\n",title);
  //printf("number of ats %i\n", atoms->nr);
  opts.np = atoms->nr ;
  nres=atoms->nres; 

  // Does the tr file exist?
  bTRX = ftp2bSet(efTRX,NFILE,fnm);
  printf("bTRX %d \n", bTRX);

  // Define system
  ldatextra(&opts, &ldat, atoms);

  // Define membrane space
  memspace(&opts,&ldat,atoms,&memb);

  // Define protein space
  if(bPROT) protspace(&opts, &pdat, atoms);

  opts.dB = 0.5 ; // Delta Buffer
  int idelZpbc; // Flag to remove Zpbc
  idelZpbc=0;
  printf("I just defined idelZpbc inside program as condition \n");
	
  if(!bTRX) {
	printf("Analyzing single frame %s\n", opt2fn("-c",NFILE,fnm)); 

	write_sto_conf(opt2fn("-o",NFILE,fnm),title,atoms,x,v,ePBC,box);

	// Calc normals and split up vs down
	// lipNormals(&opts, &ldat, &memb, atoms, &x, box); 

	// Remove PBC artifacts from membrane
	//if(idelZpbc==1) memRemoveZpbc(&opts, &ldat, &memb, &x, box);
	//printf("EXIT\n "); exit(3);
	// Calculate order parameter P2(cos(tet))
	calc_P2(&opts, &ldat, &memb, atoms, &x, box);

	if(bPROT) { 
		//printf("bPROT %d \n", bPROT);
		printf("coordprot inside \n"); 
		coordprot(&opts, &pdat, &x); 
	}

	printf("Clustering Begins... \n");
	//calc_cluster(&opts, &ldat, &memb, atoms, &x, box);

	// Make grid for 2D 
	// by definition this is the first frame
 
	//opts.delta=0.25;
	// Define 2Dgrid structure

	sumsGD=def_2DsumsGD(&opts,box);

 	//memGD=def_2Dgrid(&opts,box);

	printf("calc_GDframe\n");
 	calc_GDframe(&sumsGD,&memb,&ldat,atoms,&x,&opts,box);

	// Average all the frames
	printf("calc_GDstats\n");
	memGD=calc_GDstats(&sumsGD,&memb,&ldat,&pdat,atoms,&x,&opts,box);

	// Density calculation (only one frame)
	// ===================================
	density=opts.density;
	if(density==1){
	  printf("Density Calculation \n");
	  sums3DGD=def_3DsumsGD(&opts, box);
	  stats3DGD=def_3DstatsGD(&opts, box);
	
	  calc_3DGDframe(&sums3DGD,&memb,&ldat,&pdat,atoms,&x,&opts,box);
	}

// ######################################################
	// Write jvx membrane

	// Write jvx output
	writejvx("outie.jvx", &memGD, &opts, &ldat, &pdat, &memb, &x, box);
	
	writedat(&memGD, &pdat, &x, &opts,box);
	// Now write data on individual monolayers
	//writejvxtick("outiemono.jvx", &memGD, &opts, &ldat, &pdat, &memb, &x, box);

	// Save output
	write_sto_conf(opt2fn("-o",NFILE,fnm),title,atoms,x,v,ePBC,box);

	printf("End of Single Frame analysis\n"); 
	 	

	if (bVerbose) printf("Verbose \n");
 
   } else { 
	// ////////////////////////////////////
	//
	//	READING TRAJECTORIES
	//
	// ////////////////////////////////////
	
	// Get xtc filename
	fn=opt2fn("-tr",NFILE,fnm);
	// Open file
	xd = open_xtc(fn,"r");
	read_first_xtc(xd,&natoms,&step,&time,box,&x,&prec,&bOK);
	if(atoms->nr != natoms) {
		printf("\nDifferent number of atoms, coordinate and xtc file do not match, \n");
		printf("make sure you have the right trajectory file \n\n");
		exit(3);
	}
	printf("Analyzing trj file %s \n", fn);

	// Write output
  //	write_sto_conf(opt2fn("-o",NFILE,fnm),title,atoms,x,v,ePBC,box);

	printf("%f %f %f\n\n",box[0][0], box[1][1], box[2][2]);

	frame1st=opts.frminit;
 	framelast=opts.frmend;
 	framestride=opts.frmskip;
	frcount=0;
	nframe=0;
	printf("Analyze trajectory: frame1st=%i, framelast=%i, framestride=%i  \n", frame1st, framelast, framestride);

	 
	// BEGIN PROCESS TRAJ
	// ==================
 	printf("Begin analysis of trajectory \n");

	do {
		if (bTRX) {
	        int i,d;
			if(nframe==frame1st){
///////////////////////////
// FIRST FRAME
	// Print box info
	printf("%f %f %f\n\n",box[0][0], box[1][1], box[2][2]);

	// bXVG=0;
   
	printf("Setting up matrices with initialization \n");
	sumsGD=def_2DsumsGD(&opts,box);

	// memGD=def_2Dgrid(&opts,box);

	// Density Calculation 

	density=opts.density;
	if(density==1){
	  printf("Density Calculation \n");
	  sums3DGD=def_3DsumsGD(&opts, box);
	  stats3DGD=def_3DstatsGD(&opts, box);
	}
 
  
	//int idelZpbc; // Flag to remove Zpbc
	//idelZpbc=0;
///////////////////////////
			}

			if(nframe>=frame1st && nframe<=framelast) {
			        fprintf(stdout,"Time=%g\n ",time);
				fprintf(stdout,"natoms=%10d  step=%10d  time=%12.7e  prec=%10g\n",
			            natoms,step,time,prec);
				// pr_rvecs(stdout,indent,"box",box,DIM);
				printf("%f %f %f\n\n",box[0][0], box[1][1], box[2][2]);
			 	frcount++;
			  	printf("Processing frame %d on trajectory, number %d on sample \n", nframe, frcount);	

				// BEGIN SPECIAL CODE

				// Calc normals and split up vs down
				lipNormals(&opts, &ldat, &memb, atoms, &x, box); 

				// Remove PBC artifacts from membrane
				//if(idelZpbc==1) memRemoveZpbc(&opts, &ldat, &memb, &x, box);

				// Protein coordinates
				if(bPROT) { 
					printf("coordprot inside \n"); 
					coordprot(&opts, &pdat, &x); 
				}

				// Calculate order parameter P2(cos(tet))
			 	calc_P2(&opts, &ldat, &memb, atoms, &x, box);

				calc_GDframe(&sumsGD,&memb,&ldat,atoms,&x,&opts,box);

				// Density Calculation for current frame
				if(density==1) calc_3DGDframe(&sums3DGD,&memb,&ldat,&pdat,atoms,&x,&opts,box);

				write_sto_conf(opt2fn("-o",NFILE,fnm),title,atoms,x,v,ePBC,box);
	 

			} else {
			   //printf("skipped frame %d \n", nframe);
			}


    		} else { // i.e. bXVG=0;
	      		sprintf(buf,"%s frame %d",fn,nframe);
	      		indent=0;
	      		indent=pr_title(stdout,indent,buf);
	      		pr_indent(stdout,indent);
	      		fprintf(stdout,"natoms=%10d  step=%10d  time=%12.7e  prec=%10g\n",
	        	    natoms,step,time,prec);
	      		pr_rvecs(stdout,indent,"box",box,DIM);
	 	 //     pr_rvecs(stdout,indent,"x:(",x,natoms);
    		}

        	nframe++;
		if(nframe>framelast & framelast>0) break;  // Breaks while loop when reaching framelast

	} while (read_next_xtc(xd,natoms,&step,&time,box,x,&prec,&bOK));

	// END PROCESS TRAJ
	// ==================


	//  REPORT AVERAGE STATS
	//  ===================================================================
	printf("%d frames read \n", frcount);

	sumsGD.nframes=frcount;

	// COMPUTE AVERAGES ON ALL FRAMES
	// May need to divide by frcount
	//calc_GDsurf(&memGD,&sumsGD,&memb,&ldat,&pdat,atoms,&x,&opts,box);

	memGD=calc_GDstats(&sumsGD,&memb,&ldat,&pdat,atoms,&x,&opts,box); 
 
	if(density==1){
		printf("Density Statistics\n");
		calc_3DGDstats(&stats3DGD,&sums3DGD,&memb,&ldat,&pdat,atoms,&x,&opts,box);
		writedens("dens", &stats3DGD, &pdat,  &x, &opts, box);
	}	

	writedat(&memGD, &pdat, &x, &opts,box);
	// Uses coordinates on last frame and plots memGD  
	writejvx("outie.jvx", &memGD, &opts, &ldat, &pdat, &memb, &x, box);
 

	// END REPORT STATS

	// Now write data on individual monolayers
	//  writejvxtick("outiemono.jvx", &memGD, &opts, &ldat, &pdat, &memb, &x, box);



	if (!bOK) fprintf(stderr,"\nWARNING: Incomplete frame at time %g\n",time);
	close_xtc(xd);
  }

free(x);

free(atoms);
}

